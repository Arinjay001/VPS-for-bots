"""Initial migration

Revision ID: 001
Revises: 
Create Date: 2024-01-01 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import sqlite

revision = '001'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('guild_configs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('guild_id', sa.BigInteger(), nullable=False),
        sa.Column('prefix', sa.String(length=10), nullable=True),
        sa.Column('language', sa.String(length=10), nullable=True),
        sa.Column('timezone', sa.String(length=50), nullable=True),
        sa.Column('ticket_category_id', sa.BigInteger(), nullable=True),
        sa.Column('ticket_log_channel_id', sa.BigInteger(), nullable=True),
        sa.Column('transcript_channel_id', sa.BigInteger(), nullable=True),
        sa.Column('vps_log_channel_id', sa.BigInteger(), nullable=True),
        sa.Column('guardian_log_channel_id', sa.BigInteger(), nullable=True),
        sa.Column('guardian_enabled', sa.Boolean(), nullable=True),
        sa.Column('anti_raid_enabled', sa.Boolean(), nullable=True),
        sa.Column('anti_spam_enabled', sa.Boolean(), nullable=True),
        sa.Column('anti_bot_enabled', sa.Boolean(), nullable=True),
        sa.Column('anti_webhook_enabled', sa.Boolean(), nullable=True),
        sa.Column('anti_nuke_enabled', sa.Boolean(), nullable=True),
        sa.Column('whitelist_role_ids', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('guild_id')
    )
    op.create_index(op.f('ix_guild_configs_guild_id'), 'guild_configs', ['guild_id'], unique=False)

    op.create_table('users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('discord_id', sa.BigInteger(), nullable=False),
        sa.Column('username', sa.String(length=100), nullable=False),
        sa.Column('discriminator', sa.String(length=10), nullable=True),
        sa.Column('avatar_hash', sa.String(length=100), nullable=True),
        sa.Column('is_bot', sa.Boolean(), nullable=True),
        sa.Column('is_owner', sa.Boolean(), nullable=True),
        sa.Column('is_admin', sa.Boolean(), nullable=True),
        sa.Column('is_staff', sa.Boolean(), nullable=True),
        sa.Column('is_premium', sa.Boolean(), nullable=True),
        sa.Column('is_banned', sa.Boolean(), nullable=True),
        sa.Column('ban_reason', sa.Text(), nullable=True),
        sa.Column('total_vps', sa.Integer(), nullable=True),
        sa.Column('total_tickets', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('discord_id')
    )
    op.create_index(op.f('ix_users_discord_id'), 'users', ['discord_id'], unique=False)

    op.create_table('nodes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('host', sa.String(length=255), nullable=False),
        sa.Column('port', sa.Integer(), nullable=True),
        sa.Column('api_key', sa.String(length=255), nullable=False),
        sa.Column('location', sa.String(length=100), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_local', sa.Boolean(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('status', sa.Enum('online', 'offline', 'maintenance', 'error', name='nodestatus'), nullable=True),
        sa.Column('virtualization_support', sa.Text(), nullable=True),
        sa.Column('max_ram', sa.Integer(), nullable=True),
        sa.Column('max_cpu', sa.Integer(), nullable=True),
        sa.Column('max_disk', sa.Integer(), nullable=True),
        sa.Column('max_vps', sa.Integer(), nullable=True),
        sa.Column('current_ram', sa.Integer(), nullable=True),
        sa.Column('current_cpu', sa.Integer(), nullable=True),
        sa.Column('current_disk', sa.Integer(), nullable=True),
        sa.Column('current_vps', sa.Integer(), nullable=True),
        sa.Column('latency', sa.Integer(), nullable=True),
        sa.Column('last_heartbeat', sa.DateTime(), nullable=True),
        sa.Column('last_stats', sa.DateTime(), nullable=True),
        sa.Column('network_rx', sa.BigInteger(), nullable=True),
        sa.Column('network_tx', sa.BigInteger(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    op.create_table('vps_servers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', sa.String(length=36), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('hostname', sa.String(length=100), nullable=False),
        sa.Column('owner_id', sa.BigInteger(), nullable=False),
        sa.Column('node_id', sa.Integer(), nullable=False),
        sa.Column('status', sa.Enum('creating', 'running', 'stopped', 'starting', 'stopping', 'restarting', 'reinstalling', 'deleting', 'error', 'suspended', name='vpsstatus'), nullable=True),
        sa.Column('virtualization', sa.Enum('kvm', 'lxc_lxd_supported', 'lxc_lxd_unsupported', 'docker', name='virtualizationtype'), nullable=True),
        sa.Column('os_template', sa.String(length=100), nullable=True),
        sa.Column('ram', sa.Integer(), nullable=True),
        sa.Column('cpu', sa.Integer(), nullable=True),
        sa.Column('disk', sa.Integer(), nullable=True),
        sa.Column('bandwidth', sa.Integer(), nullable=True),
        sa.Column('ipv4_address', sa.String(length=45), nullable=True),
        sa.Column('ipv6_address', sa.String(length=45), nullable=True),
        sa.Column('root_password', sa.String(length=255), nullable=True),
        sa.Column('ssh_port', sa.Integer(), nullable=True),
        sa.Column('vnc_port', sa.Integer(), nullable=True),
        sa.Column('pterodactyl_server_id', sa.Integer(), nullable=True),
        sa.Column('pterodactyl_node_id', sa.Integer(), nullable=True),
        sa.Column('backup_enabled', sa.Boolean(), nullable=True),
        sa.Column('backup_schedule', sa.String(length=50), nullable=True),
        sa.Column('last_backup', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['node_id'], ['nodes.id'], ),
        sa.ForeignKeyConstraint(['owner_id'], ['users.discord_id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid')
    )
    op.create_index(op.f('ix_vps_servers_owner_id'), 'vps_servers', ['owner_id'], unique=False)
    op.create_index(op.f('ix_vps_servers_uuid'), 'vps_servers', ['uuid'], unique=False)

    op.create_table('port_allocations',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('port', sa.Integer(), nullable=False),
        sa.Column('protocol', sa.String(length=10), nullable=True),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('node_id', sa.Integer(), nullable=False),
        sa.Column('vps_id', sa.Integer(), nullable=True),
        sa.Column('description', sa.String(length=255), nullable=True),
        sa.Column('is_reserved', sa.Boolean(), nullable=True),
        sa.Column('reserved_until', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('released_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['node_id'], ['nodes.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.discord_id'], ),
        sa.ForeignKeyConstraint(['vps_id'], ['vps_servers.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('node_id', 'port', 'protocol', name='uq_node_port_protocol')
    )

    op.create_table('tickets',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('ticket_number', sa.Integer(), nullable=False),
        sa.Column('guild_id', sa.BigInteger(), nullable=False),
        sa.Column('channel_id', sa.BigInteger(), nullable=False),
        sa.Column('creator_id', sa.BigInteger(), nullable=False),
        sa.Column('claimant_id', sa.BigInteger(), nullable=True),
        sa.Column('category', sa.Enum('general', 'support', 'billing', 'technical', 'vps', 'minecraft', 'abuse', 'other', name='ticketcategory'), nullable=True),
        sa.Column('subject', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('status', sa.Enum('open', 'claimed', 'closed', 'deleted', name='ticketstatus'), nullable=True),
        sa.Column('priority', sa.Integer(), nullable=True),
        sa.Column('tags', sa.Text(), nullable=True),
        sa.Column('transcript', sa.Text(), nullable=True),
        sa.Column('closed_at', sa.DateTime(), nullable=True),
        sa.Column('deleted_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['claimant_id'], ['users.discord_id'], ),
        sa.ForeignKeyConstraint(['creator_id'], ['users.discord_id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('channel_id'),
        sa.UniqueConstraint('guild_id', 'ticket_number', name='uq_guild_ticket_number')
    )

    op.create_table('ticket_messages',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('ticket_id', sa.Integer(), nullable=False),
        sa.Column('author_id', sa.BigInteger(), nullable=False),
        sa.Column('author_name', sa.String(length=100), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('attachments', sa.Text(), nullable=True),
        sa.Column('is_system', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['ticket_id'], ['tickets.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table('ticket_participants',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('ticket_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('user_name', sa.String(length=100), nullable=False),
        sa.Column('added_by', sa.BigInteger(), nullable=False),
        sa.Column('added_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['ticket_id'], ['tickets.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('ticket_id', 'user_id', name='uq_ticket_participant')
    )

    op.create_table('backups',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', sa.String(length=36), nullable=False),
        sa.Column('vps_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('status', sa.Enum('pending', 'running', 'completed', 'failed', name='backupstatus'), nullable=True),
        sa.Column('size', sa.BigInteger(), nullable=True),
        sa.Column('file_path', sa.String(length=500), nullable=True),
        sa.Column('is_automatic', sa.Boolean(), nullable=True),
        sa.Column('scheduled_at', sa.DateTime(), nullable=True),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['vps_id'], ['vps_servers.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid')
    )
    op.create_index(op.f('ix_backups_uuid'), 'backups', ['uuid'], unique=False)

    op.create_table('guardian_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('guild_id', sa.BigInteger(), nullable=False),
        sa.Column('action', sa.String(length=50), nullable=False),
        sa.Column('target_id', sa.BigInteger(), nullable=True),
        sa.Column('target_name', sa.String(length=100), nullable=True),
        sa.Column('moderator_id', sa.BigInteger(), nullable=True),
        sa.Column('moderator_name', sa.String(length=100), nullable=True),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('details', sa.Text(), nullable=True),
        sa.Column('punishment', sa.String(length=50), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table('audit_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('guild_id', sa.BigInteger(), nullable=False),
        sa.Column('user_id', sa.BigInteger(), nullable=False),
        sa.Column('action', sa.String(length=100), nullable=False),
        sa.Column('target_type', sa.String(length=50), nullable=True),
        sa.Column('target_id', sa.BigInteger(), nullable=True),
        sa.Column('changes', sa.Text(), nullable=True),
        sa.Column('ip_address', sa.String(length=45), nullable=True),
        sa.Column('user_agent', sa.String(length=255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table('minecraft_servers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', sa.String(length=36), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('owner_id', sa.BigInteger(), nullable=False),
        sa.Column('node_id', sa.Integer(), nullable=False),
        sa.Column('pterodactyl_server_id', sa.Integer(), nullable=True),
        sa.Column('pterodactyl_node_id', sa.Integer(), nullable=True),
        sa.Column('software', sa.String(length=50), nullable=False),
        sa.Column('version', sa.String(length=50), nullable=False),
        sa.Column('ram', sa.Integer(), nullable=True),
        sa.Column('cpu', sa.Integer(), nullable=True),
        sa.Column('disk', sa.Integer(), nullable=True),
        sa.Column('port', sa.Integer(), nullable=True),
        sa.Column('ip_allocation_id', sa.Integer(), nullable=True),
        sa.Column('egg_id', sa.Integer(), nullable=True),
        sa.Column('docker_image', sa.String(length=255), nullable=True),
        sa.Column('startup_command', sa.Text(), nullable=True),
        sa.Column('status', sa.String(length=50), nullable=True),
        sa.Column('is_suspended', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['node_id'], ['nodes.id'], ),
        sa.ForeignKeyConstraint(['owner_id'], ['users.discord_id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid'),
        sa.UniqueConstraint('pterodactyl_server_id')
    )

    op.create_table('node_agent_config',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('node_id', sa.Integer(), nullable=False),
        sa.Column('docker_enabled', sa.Boolean(), nullable=True),
        sa.Column('lxc_enabled', sa.Boolean(), nullable=True),
        sa.Column('lxd_enabled', sa.Boolean(), nullable=True),
        sa.Column('kvm_enabled', sa.Boolean(), nullable=True),
        sa.Column('max_containers', sa.Integer(), nullable=True),
        sa.Column('max_vms', sa.Integer(), nullable=True),
        sa.Column('network_bridge', sa.String(length=50), nullable=True),
        sa.Column('storage_pool', sa.String(length=100), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['node_id'], ['nodes.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('node_id')
    )

def downgrade():
    op.drop_table('node_agent_config')
    op.drop_table('minecraft_servers')
    op.drop_table('audit_logs')
    op.drop_table('guardian_logs')
    op.drop_index(op.f('ix_backups_uuid'), table_name='backups')
    op.drop_table('backups')
    op.drop_table('ticket_participants')
    op.drop_table('ticket_messages')
    op.drop_table('tickets')
    op.drop_table('port_allocations')
    op.drop_index(op.f('ix_vps_servers_uuid'), table_name='vps_servers')
    op.drop_index(op.f('ix_vps_servers_owner_id'), table_name='vps_servers')
    op.drop_table('vps_servers')
    op.drop_table('nodes')
    op.drop_index(op.f('ix_users_discord_id'), table_name='users')
    op.drop_table('users')
    op.drop_index(op.f('ix_guild_configs_guild_id'), table_name='guild_configs')
    op.drop_table('guild_configs')