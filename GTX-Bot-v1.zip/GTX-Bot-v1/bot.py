import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
import signal
import sys
from pathlib import Path

import config
from config import settings
from database import init_db, close_db, async_session_maker, GuildConfig
from utils import setup_logging, get_logger, bot_logger
from utils.embeds import success_embed, error_embed, info_embed

setup_logging()
logger = get_logger("bot")

class GTXBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.all()
        intents.message_content = True
        intents.members = True
        intents.presences = True
        
        super().__init__(
            command_prefix=settings.BOT_PREFIX,
            intents=intents,
            help_command=None,
            case_insensitive=True,
            strip_after_prefix=True,
            activity=discord.Activity(
                type=getattr(discord.ActivityType, settings.BOT_ACTIVITY_TYPE.lower()),
                name=settings.BOT_STATUS
            ),
            status=discord.Status.online,
            allowed_mentions=discord.AllowedMentions(
                everyone=False,
                users=True,
                roles=True,
                replied_user=False
            )
        )
        
        self.initial_extensions = [
            "cogs.tickets",
            "cogs.guardian",
            "cogs.vps",
            "cogs.minecraft",
            "cogs.nodes",
            "cogs.monitoring",
            "cogs.backups",
            "cogs.admin",
            "cogs.users",
            "cogs.ports",
            "cogs.firewall",
            "cogs.dashboard",
            "cogs.logs",
            "cogs.utils",
            "cogs.pterodactyl",
            "cogs.billing"
        ]
        
        self.guild_configs_cache = {}
        self.node_agent_process = None
    
    async def setup_hook(self):
        logger.info("Setting up bot...")
        
        await init_db()
        logger.info("Database initialized")
        
        await self.load_extensions()
        
        await self.tree.sync()
        logger.info("Slash commands synced")
        
        self.status_task.start()
        self.node_heartbeat.start()
        self.backup_task.start()
        self.monitoring_task.start()
        
        logger.info("Bot setup complete")
    
    async def load_extensions(self):
        for ext in self.initial_extensions:
            try:
                await self.load_extension(ext)
                logger.info(f"Loaded extension: {ext}")
            except Exception as e:
                logger.error(f"Failed to load extension {ext}: {e}")
    
    async def on_ready(self):
        logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Connected to {len(self.guilds)} guilds")
        
        for guild in self.guilds:
            await self.ensure_guild_config(guild.id)
    
    async def on_guild_join(self, guild: discord.Guild):
        await self.ensure_guild_config(guild.id)
        logger.info(f"Joined guild: {guild.name} (ID: {guild.id})")
    
    async def on_guild_remove(self, guild: discord.Guild):
        if guild.id in self.guild_configs_cache:
            del self.guild_configs_cache[guild.id]
        logger.info(f"Left guild: {guild.name} (ID: {guild.id})")
    
    async def ensure_guild_config(self, guild_id: int):
        async with async_session_maker() as session:
            from sqlalchemy import select
            result = await session.execute(
                select(GuildConfig).where(GuildConfig.guild_id == guild_id)
            )
            config_obj = result.scalar_one_or_none()
            
            if not config_obj:
                config_obj = GuildConfig(guild_id=guild_id)
                session.add(config_obj)
                await session.commit()
            
            self.guild_configs_cache[guild_id] = config_obj
    
    def get_guild_config(self, guild_id: int):
        return self.guild_configs_cache.get(guild_id)
    
    @tasks.loop(minutes=5)
    async def status_task(self):
        try:
            await self.change_presence(
                activity=discord.Activity(
                    type=getattr(discord.ActivityType, settings.BOT_ACTIVITY_TYPE.lower()),
                    name=settings.BOT_STATUS
                )
            )
        except Exception as e:
            logger.error(f"Status task error: {e}")
    
    @tasks.loop(seconds=30)
    async def node_heartbeat(self):
        from database import Node, NodeStatus
        from sqlalchemy import select
        
        try:
            async with async_session_maker() as session:
                result = await session.execute(
                    select(Node).where(Node.is_active == True)
                )
                nodes = result.scalars().all()
                
                for node in nodes:
                    pass
        except Exception as e:
            logger.error(f"Node heartbeat error: {e}")
    
    @tasks.loop(hours=1)
    async def backup_task(self):
        if not settings.BACKUP_ENABLED:
            return
        
        try:
            from cogs.backups import run_scheduled_backups
            await run_scheduled_backups(self)
        except Exception as e:
            logger.error(f"Backup task error: {e}")
    
    @tasks.loop(minutes=1)
    async def monitoring_task(self):
        try:
            from cogs.monitoring import check_node_alerts
            await check_node_alerts(self)
        except Exception as e:
            logger.error(f"Monitoring task error: {e}")
    
    async def on_command_error(self, ctx: commands.Context, error: Exception):
        if isinstance(error, commands.CommandNotFound):
            return
        
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(embed=error_embed(
                "Missing Argument",
                f"Missing required argument: `{error.param.name}`"
            ))
            return
        
        if isinstance(error, commands.BadArgument):
            await ctx.send(embed=error_embed(
                "Invalid Argument",
                str(error)
            ))
            return
        
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(embed=error_embed(
                "Command on Cooldown",
                f"Try again in {error.retry_after:.1f} seconds."
            ))
            return
        
        if isinstance(error, commands.CheckFailure):
            return
        
        logger.error(f"Command error in {ctx.command}: {error}", exc_info=True)
        
        await ctx.send(embed=error_embed(
            "Command Error",
            "An error occurred while executing this command. Please try again later."
        ))
    
    async def on_error(self, event: str, *args, **kwargs):
        logger.error(f"Error in event {event}", exc_info=True)
    
    async def close(self):
        logger.info("Shutting down bot...")
        
        self.status_task.cancel()
        self.node_heartbeat.cancel()
        self.backup_task.cancel()
        self.monitoring_task.cancel()
        
        await close_db()
        
        await super().close()
        logger.info("Bot shutdown complete")

bot = GTXBot()

def run_bot():
    try:
        bot.run(settings.DISCORD_TOKEN, log_handler=None)
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    run_bot()