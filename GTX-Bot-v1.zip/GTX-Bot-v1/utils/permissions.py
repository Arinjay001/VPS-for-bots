from enum import IntEnum
from typing import Optional, List, Union, Callable, Awaitable
import discord
from discord.ext import commands
from config import settings

class PermissionLevel(IntEnum):
    USER = 0
    CUSTOMER = 1
    VPS_USER = 2
    PREMIUM = 3
    STAFF = 4
    ADMIN = 5
    OWNER = 6

ROLE_LEVEL_MAP = {
    "owner": PermissionLevel.OWNER,
    "admin": PermissionLevel.ADMIN,
    "staff": PermissionLevel.STAFF,
    "premium": PermissionLevel.PREMIUM,
    "vps_user": PermissionLevel.VPS_USER,
    "customer": PermissionLevel.CUSTOMER,
}

def get_user_permission_level(member: discord.Member) -> PermissionLevel:
    if member.id in settings.OWNER_IDS:
        return PermissionLevel.OWNER
    
    role_ids = [r.id for r in member.roles]
    
    if any(rid in settings.ADMIN_ROLE_IDS for rid in role_ids):
        return PermissionLevel.ADMIN
    if any(rid in settings.STAFF_ROLE_IDS for rid in role_ids):
        return PermissionLevel.STAFF
    if any(rid in settings.PREMIUM_ROLE_IDS for rid in role_ids):
        return PermissionLevel.PREMIUM
    if any(rid in settings.VPS_USER_ROLE_IDS for rid in role_ids):
        return PermissionLevel.VPS_USER
    if any(rid in settings.CUSTOMER_ROLE_IDS for rid in role_ids):
        return PermissionLevel.CUSTOMER
    
    return PermissionLevel.USER

def has_permission(member: discord.Member, required: PermissionLevel) -> bool:
    return get_user_permission_level(member) >= required

def is_owner(member: discord.Member) -> bool:
    return member.id in settings.OWNER_IDS

def is_admin(member: discord.Member) -> bool:
    return has_permission(member, PermissionLevel.ADMIN)

def is_staff(member: discord.Member) -> bool:
    return has_permission(member, PermissionLevel.STAFF)

def is_premium(member: discord.Member) -> bool:
    return has_permission(member, PermissionLevel.PREMIUM)

def is_vps_user(member: discord.Member) -> bool:
    return has_permission(member, PermissionLevel.VPS_USER)

def is_customer(member: discord.Member) -> bool:
    return has_permission(member, PermissionLevel.CUSTOMER)

def owner_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_owner(ctx.author):
            raise commands.CheckFailure("Owner only command")
        return True
    return commands.check(predicate)

def admin_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_admin(ctx.author):
            raise commands.CheckFailure("Admin only command")
        return True
    return commands.check(predicate)

def staff_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_staff(ctx.author):
            raise commands.CheckFailure("Staff only command")
        return True
    return commands.check(predicate)

def premium_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_premium(ctx.author):
            raise commands.CheckFailure("Premium only command")
        return True
    return commands.check(predicate)

def vps_user_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_vps_user(ctx.author):
            raise commands.CheckFailure("VPS User only command")
        return True
    return commands.check(predicate)

def customer_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not is_customer(ctx.author):
            raise commands.CheckFailure("Customer only command")
        return True
    return commands.check(predicate)

def require_permission(level: PermissionLevel):
    async def predicate(ctx: commands.Context) -> bool:
        if not has_permission(ctx.author, level):
            raise commands.CheckFailure(f"Requires {level.name} permission")
        return True
    return commands.check(predicate)

def guild_only():
    async def predicate(ctx: commands.Context) -> bool:
        if not ctx.guild:
            raise commands.NoPrivateMessage("This command cannot be used in DMs")
        return True
    return commands.check(predicate)

def dm_only():
    async def predicate(ctx: commands.Context) -> bool:
        if ctx.guild:
            raise commands.CheckFailure("This command can only be used in DMs")
        return True
    return commands.check(predicate)

def check_guild_permissions(*perms: str):
    async def predicate(ctx: commands.Context) -> bool:
        if not ctx.guild:
            return True
        member_perms = ctx.author.guild_permissions
        missing = [p for p in perms if not getattr(member_perms, p, False)]
        if missing:
            raise commands.MissingPermissions(missing)
        return True
    return commands.check(predicate)

def check_bot_permissions(*perms: str):
    async def predicate(ctx: commands.Context) -> bool:
        if not ctx.guild:
            return True
        bot_perms = ctx.guild.me.guild_permissions
        missing = [p for p in perms if not getattr(bot_perms, p, False)]
        if missing:
            raise commands.BotMissingPermissions(missing)
        return True
    return commands.check(predicate)

class PermissionView(discord.ui.View):
    def __init__(self, required_level: PermissionLevel, timeout: float = 60):
        super().__init__(timeout=timeout)
        self.required_level = required_level
        self.result: Optional[bool] = None
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not has_permission(interaction.user, self.required_level):
            await interaction.response.send_message(
                embed=error_embed("Permission Denied", f"Requires {self.required_level.name} permission"),
                ephemeral=True
            )
            return False
        return True