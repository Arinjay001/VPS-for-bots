import sys
from pathlib import Path
from loguru import logger
import config

def setup_logging():
    log_path = Path(config.settings.LOG_FILE)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    logger.remove()
    
    logger.add(
        sys.stdout,
        level=config.settings.LOG_LEVEL,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        colorize=True
    )
    
    logger.add(
        config.settings.LOG_FILE,
        level=config.settings.LOG_LEVEL,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        rotation=config.settings.LOG_ROTATION,
        retention=config.settings.LOG_RETENTION,
        compression="zip"
    )
    
    return logger

def get_logger(name: str = None):
    return logger.bind(name=name or "GTXBot")

bot_logger = setup_logging()