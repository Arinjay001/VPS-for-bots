import asyncio
import subprocess
import re
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

class VirtualizationType(str, Enum):
    KVM = "kvm"
    LXC_LXD_SUPPORTED = "lxc_lxd_supported"
    LXC_LXD_UNSUPPORTED = "lxc_lxd_unsupported"
    DOCKER = "docker"

VIRTUALIZATION_LABELS = {
    VirtualizationType.KVM: "KVM (Full Virtualization)",
    VirtualizationType.LXC_LXD_SUPPORTED: "LXC (LXD Supported)",
    VirtualizationType.LXC_LXD_UNSUPPORTED: "LXC (LXD Unsupported)",
    VirtualizationType.DOCKER: "Docker (Containers)",
}

VIRTUALIZATION_DESCRIPTIONS = {
    VirtualizationType.KVM: "Full hardware virtualization with dedicated kernel. Best isolation and Windows support.",
    VirtualizationType.LXC_LXD_SUPPORTED: "System containers with LXD management. Good performance, Linux only.",
    VirtualizationType.LXC_LXD_UNSUPPORTED: "Basic LXC containers without LXD. Lightweight but limited features.",
    VirtualizationType.DOCKER: "Application containers. Best for microservices and predefined images.",
}

DEFAULT_VIRTUALIZATION = VirtualizationType.LXC_LXD_UNSUPPORTED

@dataclass
class VirtualizationInfo:
    kvm: bool = False
    lxc: bool = False
    lxd: bool = False
    docker: bool = False
    nested: bool = False

async def run_command(cmd: List[str]) -> Tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    return proc.returncode, stdout.decode(), stderr.decode()

async def check_kvm_support() -> bool:
    code, _, _ = await run_command(["kvm-ok"])
    if code == 0:
        return True
    code, stdout, _ = await run_command(["grep", "-E", "(vmx|svm)", "/proc/cpuinfo"])
    return code == 0 and bool(stdout.strip())

async def check_lxc_support() -> bool:
    code, _, _ = await run_command(["lxc-version"])
    return code == 0

async def check_lxd_support() -> bool:
    code, _, _ = await run_command(["lxc", "version"])
    return code == 0

async def check_docker_support() -> bool:
    code, _, _ = await run_command(["docker", "version"])
    return code == 0

async def check_nested_virtualization() -> bool:
    code, stdout, _ = await run_command(["cat", "/sys/module/kvm_intel/parameters/nested"])
    if code == 0 and "Y" in stdout:
        return True
    code, stdout, _ = await run_command(["cat", "/sys/module/kvm_amd/parameters/nested"])
    return code == 0 and "1" in stdout

async def detect_virtualization_support() -> VirtualizationInfo:
    info = VirtualizationInfo()
    info.kvm = await check_kvm_support()
    info.lxc = await check_lxc_support()
    info.lxd = await check_lxd_support()
    info.docker = await check_docker_support()
    info.nested = await check_nested_virtualization()
    return info

def get_system_virtualization_info() -> Dict[str, Any]:
    import psutil
    info = {
        "cpu_count": psutil.cpu_count(),
        "memory_total": psutil.virtual_memory().total,
        "disk_total": psutil.disk_usage('/').total,
        "virtualization": {}
    }
    return info

def get_virtualization_label(virt: VirtualizationType) -> str:
    return VIRTUALIZATION_LABELS.get(virt, virt.value)

def get_virtualization_description(virt: VirtualizationType) -> str:
    return VIRTUALIZATION_DESCRIPTIONS.get(virt, "")

def get_supported_virtualizations(info: VirtualizationInfo) -> List[VirtualizationType]:
    supported = []
    if info.kvm and info.nested:
        supported.append(VirtualizationType.KVM)
    if info.lxd:
        supported.append(VirtualizationType.LXC_LXD_SUPPORTED)
    if info.lxc:
        supported.append(VirtualizationType.LXC_LXD_UNSUPPORTED)
    if info.docker:
        supported.append(VirtualizationType.DOCKER)
    if not supported:
        supported.append(VirtualizationType.LXC_LXD_UNSUPPORTED)
    return supported

def is_virtualization_compatible(requested: VirtualizationType, info: VirtualizationInfo) -> bool:
    supported = get_supported_virtualizations(info)
    return requested in supported

def get_recommended_virtualization(info: VirtualizationInfo) -> VirtualizationType:
    supported = get_supported_virtualizations(info)
    priority = [
        VirtualizationType.KVM,
        VirtualizationType.LXC_LXD_SUPPORTED,
        VirtualizationType.LXC_LXD_UNSUPPORTED,
        VirtualizationType.DOCKER
    ]
    for virt in priority:
        if virt in supported:
            return virt
    return DEFAULT_VIRTUALIZATION

def validate_virtualization_requirements(virt: VirtualizationType, ram: int, cpu: int, disk: int) -> Tuple[bool, str]:
    requirements = {
        VirtualizationType.KVM: {"min_ram": 1024, "min_cpu": 1, "min_disk": 10},
        VirtualizationType.LXC_LXD_SUPPORTED: {"min_ram": 256, "min_cpu": 1, "min_disk": 2},
        VirtualizationType.LXC_LXD_UNSUPPORTED: {"min_ram": 128, "min_cpu": 1, "min_disk": 1},
        VirtualizationType.DOCKER: {"min_ram": 256, "min_cpu": 1, "min_disk": 2},
    }
    req = requirements.get(virt, requirements[DEFAULT_VIRTUALIZATION])
    if ram < req["min_ram"]:
        return False, f"KVM requires at least {req['min_ram']}MB RAM"
    if cpu < req["min_cpu"]:
        return False, f"Requires at least {req['min_cpu']} CPU core(s)"
    if disk < req["min_disk"]:
        return False, f"Requires at least {req['min_disk']}GB disk"
    return True, ""