import asyncio
import aiohttp
from typing import Optional, List, Dict, Any
from dataclasses import dataclass
from enum import Enum
from config import settings

class PterodactylAPIError(Exception):
    def __init__(self, message: str, status_code: int = 0, response: Dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

@dataclass
class PterodactylNode:
    id: int
    uuid: str
    name: str
    fqdn: str
    scheme: str
    behind_proxy: bool
    maintenance_mode: bool
    memory: int
    memory_overallocate: int
    disk: int
    disk_overallocate: int
    upload_size: int
    daemon_listen: int
    daemon_sftp: int
    daemon_base: str
    created_at: str
    updated_at: str
    allocated_resources: Dict

@dataclass
class PterodactylEgg:
    id: int
    uuid: str
    name: str
    description: str
    docker_images: List[str]
    startup: str
    script: Dict
    config: Dict

@dataclass
class PterodactylServer:
    id: int
    uuid: str
    name: str
    node: int
    owner_id: int
    limits: Dict
    feature_limits: Dict
    allocation: int
    nest: int
    egg: int
    docker_image: str
    startup: str
    environment: Dict
    created_at: str
    updated_at: str

class PterodactylAPI:
    def __init__(self, url: str, api_key: str):
        self.url = url.rstrip('/')
        self.api_key = api_key
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            timeout=aiohttp.ClientTimeout(total=30)
        )
        return self
    
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
    
    async def _request(self, method: str, endpoint: str, **kwargs) -> Dict:
        if not self.session:
            raise PterodactylAPIError("Session not initialized")
        
        url = f"{self.url}/api/application{endpoint}"
        async with self.session.request(method, url, **kwargs) as resp:
            data = await resp.json()
            if resp.status >= 400:
                raise PterodactylAPIError(
                    data.get("errors", [{"detail": "Unknown error"}])[0]["detail"],
                    resp.status,
                    data
                )
            return data
    
    async def get_nodes(self) -> List[PterodactylNode]:
        data = await self._request("GET", "/nodes")
        nodes = []
        for item in data.get("data", []):
            attrs = item["attributes"]
            nodes.append(PterodactylNode(
                id=attrs["id"],
                uuid=attrs["uuid"],
                name=attrs["name"],
                fqdn=attrs["fqdn"],
                scheme=attrs["scheme"],
                behind_proxy=attrs["behind_proxy"],
                maintenance_mode=attrs["maintenance_mode"],
                memory=attrs["memory"],
                memory_overallocate=attrs["memory_overallocate"],
                disk=attrs["disk"],
                disk_overallocate=attrs["disk_overallocate"],
                upload_size=attrs["upload_size"],
                daemon_listen=attrs["daemon_listen"],
                daemon_sftp=attrs["daemon_sftp"],
                daemon_base=attrs["daemon_base"],
                created_at=attrs["created_at"],
                updated_at=attrs["updated_at"],
                allocated_resources=attrs.get("allocated_resources", {})
            ))
        return nodes
    
    async def get_node(self, node_id: int) -> Optional[PterodactylNode]:
        try:
            data = await self._request("GET", f"/nodes/{node_id}")
            attrs = data["attributes"]
            return PterodactylNode(
                id=attrs["id"],
                uuid=attrs["uuid"],
                name=attrs["name"],
                fqdn=attrs["fqdn"],
                scheme=attrs["scheme"],
                behind_proxy=attrs["behind_proxy"],
                maintenance_mode=attrs["maintenance_mode"],
                memory=attrs["memory"],
                memory_overallocate=attrs["memory_overallocate"],
                disk=attrs["disk"],
                disk_overallocate=attrs["disk_overallocate"],
                upload_size=attrs["upload_size"],
                daemon_listen=attrs["daemon_listen"],
                daemon_sftp=attrs["daemon_sftp"],
                daemon_base=attrs["daemon_base"],
                created_at=attrs["created_at"],
                updated_at=attrs["updated_at"],
                allocated_resources=attrs.get("allocated_resources", {})
            )
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return None
            raise
    
    async def get_nests(self) -> List[Dict]:
        data = await self._request("GET", "/nests")
        return data.get("data", [])
    
    async def get_eggs(self, nest_id: int) -> List[PterodactylEgg]:
        data = await self._request("GET", f"/nests/{nest_id}/eggs")
        eggs = []
        for item in data.get("data", []):
            attrs = item["attributes"]
            eggs.append(PterodactylEgg(
                id=attrs["id"],
                uuid=attrs["uuid"],
                name=attrs["name"],
                description=attrs["description"],
                docker_images=attrs["docker_images"],
                startup=attrs["startup"],
                script=attrs["script"],
                config=attrs["config"]
            ))
        return eggs
    
    async def get_egg(self, nest_id: int, egg_id: int) -> Optional[PterodactylEgg]:
        try:
            data = await self._request("GET", f"/nests/{nest_id}/eggs/{egg_id}")
            attrs = data["attributes"]
            return PterodactylEgg(
                id=attrs["id"],
                uuid=attrs["uuid"],
                name=attrs["name"],
                description=attrs["description"],
                docker_images=attrs["docker_images"],
                startup=attrs["startup"],
                script=attrs["script"],
                config=attrs["config"]
            )
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return None
            raise
    
    async def create_user(self, email: str, username: str, first_name: str, last_name: str, password: str = None) -> Dict:
        data = {
            "email": email,
            "username": username,
            "first_name": first_name,
            "last_name": last_name,
        }
        if password:
            data["password"] = password
        return await self._request("POST", "/users", json=data)
    
    async def get_user(self, user_id: int) -> Optional[Dict]:
        try:
            return await self._request("GET", f"/users/{user_id}")
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return None
            raise
    
    async def create_server(self, data: Dict) -> Dict:
        return await self._request("POST", "/servers", json=data)
    
    async def get_server(self, server_id: int) -> Optional[PterodactylServer]:
        try:
            data = await self._request("GET", f"/servers/{server_id}")
            attrs = data["attributes"]
            return PterodactylServer(
                id=attrs["id"],
                uuid=attrs["uuid"],
                name=attrs["name"],
                node=attrs["node"],
                owner_id=attrs["user"],
                limits=attrs["limits"],
                feature_limits=attrs["feature_limits"],
                allocation=attrs["allocation"],
                nest=attrs["nest"],
                egg=attrs["egg"],
                docker_image=attrs["docker_image"],
                startup=attrs["startup"],
                environment=attrs["environment"],
                created_at=attrs["created_at"],
                updated_at=attrs["updated_at"]
            )
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return None
            raise
    
    async def delete_server(self, server_id: int) -> bool:
        try:
            await self._request("DELETE", f"/servers/{server_id}")
            return True
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return False
            raise
    
    async def power_action(self, server_id: int, action: str) -> bool:
        try:
            await self._request("POST", f"/servers/{server_id}/power", json={"signal": action})
            return True
        except PterodactylAPIError:
            return False
    
    async def send_command(self, server_id: int, command: str) -> bool:
        try:
            await self._request("POST", f"/servers/{server_id}/command", json={"command": command})
            return True
        except PterodactylAPIError:
            return False
    
    async def get_server_resources(self, server_id: int) -> Optional[Dict]:
        try:
            return await self._request("GET", f"/servers/{server_id}/resources")
        except PterodactylAPIError as e:
            if e.status_code == 404:
                return None
            raise
    
    async def create_allocation(self, node_id: int, ip: str, port: int) -> Dict:
        return await self._request("POST", f"/nodes/{node_id}/allocations", json={"ip": ip, "port": port})
    
    async def get_allocations(self, node_id: int) -> List[Dict]:
        data = await self._request("GET", f"/nodes/{node_id}/allocations")
        return data.get("data", [])
    
    async def create_backup(self, server_id: int) -> Dict:
        return await self._request("POST", f"/servers/{server_id}/backups")
    
    async def get_backups(self, server_id: int) -> List[Dict]:
        data = await self._request("GET", f"/servers/{server_id}/backups")
        return data.get("data", [])

MC_EGG_CONFIGS = {
    "paper": {"nest": 5, "egg": 9, "software": "Paper"},
    "purpur": {"nest": 5, "egg": 10, "software": "Purpur"},
    "fabric": {"nest": 5, "egg": 11, "software": "Fabric"},
    "forge": {"nest": 5, "egg": 12, "software": "Forge"},
    "neoforge": {"nest": 5, "egg": 13, "software": "NeoForge"},
    "spigot": {"nest": 5, "egg": 14, "software": "Spigot"},
    "vanilla": {"nest": 5, "egg": 15, "software": "Vanilla"},
}

async def get_pterodactyl_api() -> PterodactylAPI:
    if not settings.PTERODACTYL_URL or not settings.PTERODACTYL_API_KEY:
        raise PterodactylAPIError("Pterodactyl not configured")
    return PterodactylAPI(settings.PTERODACTYL_URL, settings.PTERODACTYL_API_KEY)

async def find_minecraft_egg(software: str) -> Optional[Dict]:
    software = software.lower()
    if software in MC_EGG_CONFIGS:
        return MC_EGG_CONFIGS[software]
    return None