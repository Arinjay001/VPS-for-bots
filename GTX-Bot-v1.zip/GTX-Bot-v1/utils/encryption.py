import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import config

class Encryption:
    _fernet: Fernet = None
    
    @classmethod
    def _get_fernet(cls) -> Fernet:
        if cls._fernet is None:
            key = config.settings.ENCRYPTION_KEY.encode()
            if len(key) != 32:
                kdf = PBKDF2HMAC(
                    algorithm=hashes.SHA256(),
                    length=32,
                    salt=b'gtxbot_salt',
                    iterations=100000,
                )
                key = base64.urlsafe_b64encode(kdf.derive(key))
            cls._fernet = Fernet(key)
        return cls._fernet
    
    @classmethod
    def encrypt(cls, data: str) -> str:
        fernet = cls._get_fernet()
        return fernet.encrypt(data.encode()).decode()
    
    @classmethod
    def decrypt(cls, encrypted_data: str) -> str:
        fernet = cls._get_fernet()
        return fernet.decrypt(encrypted_data.encode()).decode()
    
    @classmethod
    def encrypt_bytes(cls, data: bytes) -> bytes:
        fernet = cls._get_fernet()
        return fernet.encrypt(data)
    
    @classmethod
    def decrypt_bytes(cls, encrypted_data: bytes) -> bytes:
        fernet = cls._get_fernet()
        return fernet.decrypt(encrypted_data)

def generate_api_key(length: int = 32) -> str:
    return base64.urlsafe_b64encode(os.urandom(length)).decode().rstrip('=')

def hash_api_key(key: str) -> str:
    import hashlib
    return hashlib.sha256(key.encode()).hexdigest()

def verify_api_key(key: str, key_hash: str) -> bool:
    return hash_api_key(key) == key_hash

def generate_secure_token(length: int = 32) -> str:
    return base64.urlsafe_b64encode(os.urandom(length)).decode().rstrip('=')

def generate_ssh_key_pair() -> tuple:
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    
    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH
    )
    
    return private_pem.decode(), public_pem.decode()