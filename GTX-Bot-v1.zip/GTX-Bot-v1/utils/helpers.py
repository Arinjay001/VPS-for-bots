import uuid
import secrets
import string
import hashlib
import asyncio
import re
import json
from typing import Any, Callable, TypeVar, Optional, List, Dict, AsyncGenerator, Union
from datetime import timedelta
from functools import wraps
from pathlib import Path
import aiohttp
import psutil

T = TypeVar('T')

def generate_uuid() -> str:
    return str(uuid.uuid4())

def generate_short_id(length: int = 8) -> str:
    return secrets.token_urlsafe(length)[:length]

def generate_password(length: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def generate_api_key(prefix: str = "gtx") -> str:
    return f"{prefix}_{secrets.token_urlsafe(32)}"

def hash_password(password: str) -> str:
    return hashlib.pbkdf2_hmac('sha256', password.encode(), secrets.token_bytes(16), 100000).hex()

def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed

def sanitize_input(text: str, max_length: int = 2000) -> str:
    text = re.sub(r'[@#`]', '', text)
    return text[:max_length]

def parse_time_string(time_str: str) -> Optional[int]:
    time_str = time_str.lower().strip()
    multipliers = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400, 'w': 604800}
    total = 0
    current = ''
    for char in time_str:
        if char.isdigit():
            current += char
        elif char in multipliers:
            if current:
                total += int(current) * multipliers[char]
                current = ''
    return total if total > 0 else None

def format_timedelta(td: timedelta) -> str:
    total = int(td.total_seconds())
    days = total // 86400
    hours = (total % 86400) // 3600
    minutes = (total % 3600) // 60
    seconds = total % 60
    parts = []
    if days: parts.append(f"{days}d")
    if hours: parts.append(f"{hours}h")
    if minutes: parts.append(f"{minutes}m")
    if seconds: parts.append(f"{seconds}s")
    return " ".join(parts) if parts else "0s"

def truncate(text: str, length: int = 100, suffix: str = "...") -> str:
    if len(text) <= length:
        return text
    return text[:length - len(suffix)] + suffix

def chunk_list(lst: List[T], chunk_size: int) -> List[List[T]]:
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

async def run_in_executor(func: Callable[..., T], *args, **kwargs) -> T:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: func(*args, **kwargs))

def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0, exceptions: tuple = (Exception,)):
    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            current_delay = delay
            for attempt in range(max_attempts):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts - 1:
                        raise
                    await asyncio.sleep(current_delay)
                    current_delay *= backoff
            return await func(*args, **kwargs)
        return wrapper
    return decorator

class RateLimiter:
    def __init__(self, max_calls: int, period: float):
        self.max_calls = max_calls
        self.period = period
        self.calls: List[float] = []
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> None:
        async with self._lock:
            now = asyncio.get_event_loop().time()
            self.calls = [t for t in self.calls if now - t < self.period]
            if len(self.calls) >= self.max_calls:
                sleep_time = self.period - (now - self.calls[0])
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
            self.calls.append(now)

def paginate(items: List[T], page: int, per_page: int = 10) -> List[T]:
    start = (page - 1) * per_page
    end = start + per_page
    return items[start:end]

async def fetch_json(session: aiohttp.ClientSession, url: str, **kwargs) -> Dict:
    async with session.get(url, **kwargs) as resp:
        resp.raise_for_status()
        return await resp.json()

async def post_json(session: aiohttp.ClientSession, url: str, data: Dict = None, **kwargs) -> Dict:
    async with session.post(url, json=data, **kwargs) as resp:
        resp.raise_for_status()
        return await resp.json()

def get_system_info() -> Dict[str, Any]:
    return {
        "cpu_count": psutil.cpu_count(),
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "memory": dict(psutil.virtual_memory()._asdict()),
        "disk": dict(psutil.disk_usage('/')._asdict()),
        "network": dict(psutil.net_io_counters()._asdict()),
        "boot_time": psutil.boot_time(),
    }

def is_valid_hostname(hostname: str) -> bool:
    if len(hostname) > 255:
        return False
    if hostname[-1] == ".":
        hostname = hostname[:-1]
    allowed = re.compile(r"^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

def is_valid_ip(ip: str) -> bool:
    ipv4 = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')
    ipv6 = re.compile(r'^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$')
    if ipv4.match(ip):
        return all(0 <= int(octet) <= 255 for octet in ip.split('.'))
    return bool(ipv6.match(ip))

def parse_size(size_str: str) -> Optional[int]:
    size_str = size_str.upper().strip()
    multipliers = {'K': 1024, 'M': 1024**2, 'G': 1024**3, 'T': 1024**4}
    if size_str[-1] in multipliers:
        try:
            return int(size_str[:-1]) * multipliers[size_str[-1]]
        except ValueError:
            return None
    try:
        return int(size_str)
    except ValueError:
        return None

def format_dict_for_display(data: Dict, indent: int = 2) -> str:
    return json.dumps(data, indent=indent, default=str)