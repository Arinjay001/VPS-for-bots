import re
import ipaddress
from typing import Optional, List, Tuple
from uuid import UUID
from datetime import datetime

class ValidationError(Exception):
    pass

def validate_and_raise(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)

def validate_discord_id(value: str) -> bool:
    try:
        id_int = int(value)
        return 17 <= len(value) <= 20 and id_int > 0
    except ValueError:
        return False

def validate_uuid(value: str) -> bool:
    try:
        UUID(value)
        return True
    except ValueError:
        return False

def validate_hostname(hostname: str) -> bool:
    if len(hostname) > 255:
        return False
    if hostname[-1] == ".":
        hostname = hostname[:-1]
    allowed = re.compile(r"^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

def validate_email(email: str) -> bool:
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_url(url: str) -> bool:
    pattern = r'^https?://[^\s/$.?#].[^\s]*$'
    return bool(re.match(pattern, url))

def validate_ip_address(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

def validate_port(port: int) -> bool:
    return 1 <= port <= 65535

def validate_ram(ram: int) -> bool:
    return 128 <= ram <= 1048576 and ram % 128 == 0

def validate_cpu(cpu: int) -> bool:
    return 1 <= cpu <= 128

def validate_disk(disk: int) -> bool:
    return 1 <= disk <= 10240

def validate_virtualization(virt: str) -> bool:
    valid = ["kvm", "lxc_lxd_supported", "lxc_lxd_unsupported", "docker"]
    return virt in valid

def validate_os_template(template: str) -> bool:
    valid_templates = [
        "ubuntu-20.04", "ubuntu-22.04", "ubuntu-24.04",
        "debian-11", "debian-12",
        "centos-7", "centos-8", "centos-9",
        "almalinux-8", "almalinux-9",
        "rocky-8", "rocky-9",
        "fedora-38", "fedora-39",
        "archlinux",
        "alpine-3.18", "alpine-3.19"
    ]
    return template in valid_templates

def validate_vps_name(name: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9\-]{1,64}$', name))

def validate_vps_hostname(hostname: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$', hostname))

def validate_ticket_subject(subject: str) -> bool:
    return 1 <= len(subject) <= 100

def validate_ticket_description(description: str) -> bool:
    return len(description) <= 4000

def validate_node_name(name: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9\-_]{1,64}$', name))

def validate_node_host(host: str) -> bool:
    return validate_hostname(host) or validate_ip_address(host)

def validate_api_key(key: str) -> bool:
    return len(key) >= 32

def sanitize_string(text: str, max_length: int = 2000, allow_newlines: bool = True) -> str:
    if not allow_newlines:
        text = text.replace('\n', ' ').replace('\r', ' ')
    text = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]', '', text)
    return text[:max_length]

def validate_command_args(args: List[str], min_args: int = 0, max_args: int = 10) -> Tuple[bool, str]:
    if len(args) < min_args:
        return False, f"Too few arguments (minimum {min_args})"
    if len(args) > max_args:
        return False, f"Too many arguments (maximum {max_args})"
    return True, ""

def validate_datetime(dt_str: str, format: str = "%Y-%m-%d %H:%M:%S") -> Optional[datetime]:
    try:
        return datetime.strptime(dt_str, format)
    except ValueError:
        return None

def validate_cron_expression(cron: str) -> bool:
    parts = cron.split()
    if len(parts) != 5:
        return False
    minute, hour, day, month, weekday = parts
    ranges = {
        'minute': (0, 59),
        'hour': (0, 23),
        'day': (1, 31),
        'month': (1, 12),
        'weekday': (0, 7)
    }
    for i, (part, (min_v, max_v)) in enumerate(zip(parts, ranges.values())):
        if part == '*':
            continue
        if ',' in part:
            for p in part.split(','):
                if not validate_cron_part(p, min_v, max_v):
                    return False
        elif '/' in part:
            base, step = part.split('/')
            if base != '*' and not validate_cron_part(base, min_v, max_v):
                return False
            if not step.isdigit() or int(step) < 1:
                return False
        elif '-' in part:
            start, end = part.split('-')
            if not (validate_cron_part(start, min_v, max_v) and validate_cron_part(end, min_v, max_v)):
                return False
        else:
            if not validate_cron_part(part, min_v, max_v):
                return False
    return True

def validate_cron_part(part: str, min_v: int, max_v: int) -> bool:
    if not part.isdigit():
        return False
    val = int(part)
    return min_v <= val <= max_v