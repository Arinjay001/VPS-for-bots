import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Optional
from contextvars import ContextVar
from config import settings

_log_context: ContextVar[dict] = ContextVar('log_context', default={})

def setup_logging() -> None:
    log_path = Path(settings.LOG_FILE)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO))
    
    root_logger.handlers.clear()
    
    file_handler = logging.handlers.RotatingFileHandler(
        log_path,
        maxBytes=settings.LOG_MAX_BYTES,
        backupCount=settings.LOG_BACKUP_COUNT,
        encoding='utf-8'
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    root_logger.addHandler(file_handler)
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    root_logger.addHandler(console_handler)
    
    for logger_name in ['discord', 'discord.http', 'discord.gateway', 'websockets', 'asyncio']:
        logging.getLogger(logger_name).setLevel(logging.WARNING)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)

class ContextLogger:
    def __init__(self, logger: logging.Logger):
        self.logger = logger
    
    def _log(self, level: int, msg: str, *args, **kwargs):
        context = _log_context.get()
        if context:
            ctx_str = " | ".join(f"{k}={v}" for k, v in context.items())
            msg = f"[{ctx_str}] {msg}"
        self.logger.log(level, msg, *args, **kwargs)
    
    def debug(self, msg: str, *args, **kwargs): self._log(logging.DEBUG, msg, *args, **kwargs)
    def info(self, msg: str, *args, **kwargs): self._log(logging.INFO, msg, *args, **kwargs)
    def warning(self, msg: str, *args, **kwargs): self._log(logging.WARNING, msg, *args, **kwargs)
    def error(self, msg: str, *args, **kwargs): self._log(logging.ERROR, msg, *args, **kwargs)
    def critical(self, msg: str, *args, **kwargs): self._log(logging.CRITICAL, msg, *args, **kwargs)
    def exception(self, msg: str, *args, **kwargs): self._log(logging.ERROR, msg, *args, exc_info=True, **kwargs)

bot_logger = ContextLogger(get_logger("bot"))
guardian_logger = ContextLogger(get_logger("guardian"))
tickets_logger = ContextLogger(get_logger("tickets"))
node_logger = ContextLogger(get_logger("nodes"))
ptero_logger = ContextLogger(get_logger("pterodactyl"))
errors_logger = ContextLogger(get_logger("errors"))
database_logger = ContextLogger(get_logger("database"))
backup_logger = ContextLogger(get_logger("backups"))
monitoring_logger = ContextLogger(get_logger("monitoring"))
vps_logger = ContextLogger(get_logger("vps"))
minecraft_logger = ContextLogger(get_logger("minecraft"))

def add_context(**kwargs) -> None:
    context = _log_context.get().copy()
    context.update(kwargs)
    _log_context.set(context)

def remove_context(*keys) -> None:
    context = _log_context.get().copy()
    for key in keys:
        context.pop(key, None)
    _log_context.set(context)

def log_command(ctx, command: str, success: bool = True, error: str = None):
    user = f"{ctx.author} ({ctx.author.id})"
    guild = f"{ctx.guild} ({ctx.guild.id})" if ctx.guild else "DM"
    status = "SUCCESS" if success else "FAILED"
    msg = f"Command: {command} | User: {user} | Guild: {guild} | Status: {status}"
    if error:
        msg += f" | Error: {error}"
    if success:
        bot_logger.info(msg)
    else:
        bot_logger.warning(msg)

def log_guild_action(guild_id: int, action: str, moderator_id: int, target_id: int = None, reason: str = None):
    msg = f"Guild Action: {action} | Guild: {guild_id} | Moderator: {moderator_id}"
    if target_id:
        msg += f" | Target: {target_id}"
    if reason:
        msg += f" | Reason: {reason}"
    guardian_logger.info(msg)

def log_security_event(event_type: str, guild_id: int, user_id: int, details: str = None, action_taken: str = None):
    msg = f"Security Event: {event_type} | Guild: {guild_id} | User: {user_id}"
    if details:
        msg += f" | Details: {details}"
    if action_taken:
        msg += f" | Action: {action_taken}"
    guardian_logger.warning(msg)

def log_vps_action(action: str, vps_id: int, user_id: int, node_id: int = None, success: bool = True, error: str = None):
    status = "SUCCESS" if success else "FAILED"
    msg = f"VPS Action: {action} | VPS: {vps_id} | User: {user_id} | Status: {status}"
    if node_id:
        msg += f" | Node: {node_id}"
    if error:
        msg += f" | Error: {error}"
    if success:
        vps_logger.info(msg)
    else:
        vps_logger.error(msg)

def log_ticket_action(action: str, ticket_id: int, user_id: int, guild_id: int, details: str = None):
    msg = f"Ticket Action: {action} | Ticket: {ticket_id} | User: {user_id} | Guild: {guild_id}"
    if details:
        msg += f" | Details: {details}"
    tickets_logger.info(msg)

def log_node_event(event: str, node_id: int, details: str = None):
    msg = f"Node Event: {event} | Node: {node_id}"
    if details:
        msg += f" | Details: {details}"
    node_logger.info(msg)

def log_pterodactyl_action(action: str, server_id: int = None, user_id: int = None, success: bool = True, error: str = None):
    status = "SUCCESS" if success else "FAILED"
    msg = f"Pterodactyl Action: {action} | Status: {status}"
    if server_id:
        msg += f" | Server: {server_id}"
    if user_id:
        msg += f" | User: {user_id}"
    if error:
        msg += f" | Error: {error}"
    if success:
        ptero_logger.info(msg)
    else:
        ptero_logger.error(msg)

def log_backup_action(action: str, backup_id: int = None, vps_id: int = None, success: bool = True, error: str = None):
    status = "SUCCESS" if success else "FAILED"
    msg = f"Backup Action: {action} | Status: {status}"
    if backup_id:
        msg += f" | Backup: {backup_id}"
    if vps_id:
        msg += f" | VPS: {vps_id}"
    if error:
        msg += f" | Error: {error}"
    if success:
        backup_logger.info(msg)
    else:
        backup_logger.error(msg)