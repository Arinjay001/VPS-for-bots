from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from functools import wraps
import jwt
import datetime
import requests
import os
from pathlib import Path

app = Flask(__name__)
app.secret_key = os.getenv("DASHBOARD_SECRET", "gtx-dashboard-secret")

DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "0.0.0.0")
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", "5000"))
BOT_API_URL = os.getenv("BOT_API_URL", "http://localhost:8080")
JWT_SECRET = os.getenv("JWT_SECRET", "gtx-jwt-secret")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = session.get('token')
        if not token:
            return redirect(url_for('login'))
        try:
            data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            request.user_id = data['user_id']
        except:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/')
def index():
    if 'token' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # In production, verify against database
        # For now, create demo token
        token = jwt.encode({
            'user_id': 123456789,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, JWT_SECRET, algorithm=JWT_ALGORITHM)
        
        session['token'] = token
        return redirect(url_for('dashboard'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@token_required
def dashboard():
    # Fetch stats from bot API
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        stats = requests.get(f'{BOT_API_URL}/api/stats', headers=headers, timeout=5).json()
    except:
        stats = {}
    
    return render_template('dashboard.html', stats=stats)

@app.route('/vps')
@token_required
def vps_list():
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        vps_list = requests.get(f'{BOT_API_URL}/api/vps', headers=headers, timeout=5).json()
    except:
        vps_list = []
    
    return render_template('vps.html', vps_list=vps_list)

@app.route('/vps/create', methods=['GET', 'POST'])
@token_required
def vps_create():
    if request.method == 'POST':
        data = {
            'name': request.form.get('name'),
            'hostname': request.form.get('hostname'),
            'virtualization': request.form.get('virtualization'),
            'os_template': request.form.get('os_template'),
            'ram': int(request.form.get('ram')),
            'cpu': int(request.form.get('cpu')),
            'disk': int(request.form.get('disk')),
            'ssh_port': int(request.form.get('ssh_port')),
            'root_password': request.form.get('root_password')
        }
        try:
            headers = {'Authorization': f'Bearer {session["token"]}'}
            requests.post(f'{BOT_API_URL}/api/vps', json=data, headers=headers, timeout=10)
            return redirect(url_for('vps_list'))
        except Exception as e:
            return render_template('vps_create.html', error=str(e))
    
    return render_template('vps_create.html')

@app.route('/vps/<vps_id>')
@token_required
def vps_detail(vps_id):
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        vps = requests.get(f'{BOT_API_URL}/api/vps/{vps_id}', headers=headers, timeout=5).json()
    except:
        vps = None
    
    return render_template('vps_detail.html', vps=vps)

@app.route('/nodes')
@token_required
def nodes():
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        nodes_list = requests.get(f'{BOT_API_URL}/api/nodes', headers=headers, timeout=5).json()
    except:
        nodes_list = []
    
    return render_template('nodes.html', nodes=nodes_list)

@app.route('/tickets')
@token_required
def tickets():
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        tickets_list = requests.get(f'{BOT_API_URL}/api/tickets', headers=headers, timeout=5).json()
    except:
        tickets_list = []
    
    return render_template('tickets.html', tickets=tickets_list)

@app.route('/monitoring')
@token_required
def monitoring():
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        monitoring_data = requests.get(f'{BOT_API_URL}/api/monitoring', headers=headers, timeout=5).json()
    except:
        monitoring_data = {}
    
    return render_template('monitoring.html', data=monitoring_data)

@app.route('/billing')
@token_required
def billing():
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        billing_data = requests.get(f'{BOT_API_URL}/api/billing', headers=headers, timeout=5).json()
    except:
        billing_data = {}
    
    return render_template('billing.html', billing=billing_data)

@app.route('/settings')
@token_required
def settings_page():
    return render_template('settings.html')

# API endpoints for AJAX
@app.route('/api/vps/<vps_id>/action', methods=['POST'])
@token_required
def vps_action(vps_id):
    action = request.json.get('action')
    try:
        headers = {'Authorization': f'Bearer {session["token"]}'}
        requests.post(f'{BOT_API_URL}/api/vps/{vps_id}/{action}', headers=headers, timeout=10)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT, debug=True)