from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import jwt
import datetime
import asyncio
from contextlib import asynccontextmanager

from database import async_session_maker, VPSServer, VPSStatus, Node, NodeStatus, User, Ticket, TicketStatus, Wallet, Transaction, TransactionType, TransactionStatus, Invoice, InvoiceStatus, Plan
from config import settings
from sqlalchemy import select, func, desc
from utils import get_logger

logger = get_logger("api")

security = HTTPBearer(auto_error=False)

def create_jwt_token(user_id: int) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)

def decode_jwt_token(token: str) -> dict:
    return jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Missing token")
    try:
        payload = decode_jwt_token(credentials.credentials)
        return payload['user_id']
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting GTX API Server...")
    yield
    logger.info("Shutting down GTX API Server...")

app = FastAPI(
    title="GTX Bot API",
    description="REST API for GTX Bot Dashboard",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Auth endpoints
class LoginRequest(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

@app.post("/auth/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    # In production, verify against database
    # For demo, accept any credentials
    user_id = 123456789  # Would look up by email
    token = create_jwt_token(user_id)
    return {"access_token": token, "token_type": "bearer"}

# Stats endpoint
@app.get("/stats")
async def get_stats(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        total_vps = await session.execute(select(func.count(VPSServer.id)).where(VPSServer.owner_id == user_id, VPSServer.status != VPSStatus.DELETING))
        running_vps = await session.execute(select(func.count(VPSServer.id)).where(VPSServer.owner_id == user_id, VPSServer.status == VPSStatus.RUNNING))
        
        wallet = await session.execute(select(Wallet).where(Wallet.user_id == user_id))
        wallet = wallet.scalar_one_or_none()
        
        open_tickets = await session.execute(select(func.count(Ticket.id)).where(Ticket.creator_id == user_id, Ticket.status == TicketStatus.OPEN))
        
        recent_vps = await session.execute(
            select(VPSServer, Node.name.label('node_name'))
            .join(Node, VPSServer.node_id == Node.id)
            .where(VPSServer.owner_id == user_id, VPSServer.status != VPSStatus.DELETING)
            .order_by(desc(VPSServer.created_at))
            .limit(5)
        )
        recent_vps = recent_vps.all()
    
    return {
        "total_vps": total_vps.scalar() or 0,
        "running_vps": running_vps.scalar() or 0,
        "wallet_balance": wallet.balance if wallet else 0,
        "open_tickets": open_tickets.scalar() or 0,
        "recent_vps": [
            {
                "uuid": vps.uuid,
                "name": vps.name,
                "status": vps.status.value,
                "ram": vps.ram,
                "cpu": vps.cpu,
                "disk": vps.disk,
                "node_name": node_name
            }
            for vps, node_name in recent_vps
        ]
    }

# VPS endpoints
class VPSCreateRequest(BaseModel):
    name: str
    hostname: str
    virtualization: str
    os_template: str
    ram: int
    cpu: int
    disk: int
    ssh_port: int
    root_password: str

@app.get("/vps")
async def list_vps(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        result = await session.execute(
            select(VPSServer, Node.name.label('node_name'))
            .join(Node, VPSServer.node_id == Node.id)
            .where(VPSServer.owner_id == user_id, VPSServer.status != VPSStatus.DELETING)
            .order_by(desc(VPSServer.created_at))
        )
        vps_list = result.all()
    
    return [
        {
            "uuid": vps.uuid,
            "name": vps.name,
            "hostname": vps.hostname,
            "status": vps.status.value,
            "virtualization": vps.virtualization.value,
            "ram": vps.ram,
            "cpu": vps.cpu,
            "disk": vps.disk,
            "ipv4": vps.ipv4_address,
            "ssh_port": vps.ssh_port,
            "node_name": node_name,
            "created_at": vps.created_at.isoformat()
        }
        for vps, node_name in vps_list
    ]

@app.post("/vps")
async def create_vps(request: VPSCreateRequest, user_id: int = Depends(get_current_user)):
    # This would trigger the node agent to create VPS
    # For now, return success
    return {"status": "creating", "message": "VPS creation queued"}

@app.get("/vps/{vps_id}")
async def get_vps(vps_id: str, user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        result = await session.execute(
            select(VPSServer, Node.name.label('node_name'))
            .join(Node, VPSServer.node_id == Node.id)
            .where(VPSServer.uuid.like(f"{vps_id}%"), VPSServer.owner_id == user_id)
        )
        row = result.first()
    
    if not row:
        raise HTTPException(404, "VPS not found")
    
    vps, node_name = row
    return {
        "uuid": vps.uuid,
        "name": vps.name,
        "hostname": vps.hostname,
        "status": vps.status.value,
        "virtualization": vps.virtualization.value,
        "ram": vps.ram,
        "cpu": vps.cpu,
        "disk": vps.disk,
        "ipv4": vps.ipv4_address,
        "ssh_port": vps.ssh_port,
        "root_password": vps.root_password,
        "node_name": node_name,
        "created_at": vps.created_at.isoformat()
    }

@app.post("/vps/{vps_id}/{action}")
async def vps_action(vps_id: str, action: str, user_id: int = Depends(get_current_user)):
    valid_actions = ['start', 'stop', 'restart', 'reinstall']
    if action not in valid_actions:
        raise HTTPException(400, "Invalid action")
    
    async with async_session_maker() as session:
        vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%"), VPSServer.owner_id == user_id))
        vps = vps.scalar_one_or_none()
    
    if not vps:
        raise HTTPException(404, "VPS not found")
    
    # Would call node agent here
    return {"status": action, "message": f"VPS {action} initiated"}

# Nodes endpoint
@app.get("/nodes")
async def list_nodes(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        nodes = await session.execute(select(Node).where(Node.is_active == True).order_by(Node.name))
        nodes = nodes.scalars().all()
    
    return [
        {
            "id": node.id,
            "name": node.name,
            "location": node.location,
            "host": node.host,
            "status": node.status.value,
            "cpu_percent": node.current_cpu,
            "memory_used": node.current_ram,
            "memory_total": node.max_ram,
            "disk_used": node.current_disk,
            "disk_total": node.max_disk,
            "vps_count": node.current_vps,
            "max_vps": node.max_vps
        }
        for node in nodes
    ]

# Tickets endpoint
@app.get("/tickets")
async def list_tickets(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        tickets = await session.execute(
            select(Ticket)
            .where(Ticket.creator_id == user_id)
            .order_by(desc(Ticket.created_at))
        )
        tickets = tickets.scalars().all()
    
    return [
        {
            "id": ticket.id,
            "ticket_number": ticket.ticket_number,
            "subject": ticket.subject,
            "category": ticket.category.value,
            "status": ticket.status.value,
            "created_at": ticket.created_at.isoformat()
        }
        for ticket in tickets
    ]

# Monitoring endpoint
@app.get("/monitoring")
async def get_monitoring(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        nodes = await session.execute(select(Node).where(Node.is_active == True))
        nodes = nodes.scalars().all()
    
    return {
        "nodes": [
            {
                "name": node.name,
                "status": node.status.value,
                "cpu_percent": node.current_cpu,
                "memory_percent": (node.current_ram / node.max_ram * 100) if node.max_ram else 0,
                "disk_percent": (node.current_disk / node.max_disk * 100) if node.max_disk else 0,
                "vps_count": node.current_vps,
                "latency": node.latency
            }
            for node in nodes
        ]
    }

# Billing endpoints
@app.get("/billing")
async def get_billing(user_id: int = Depends(get_current_user)):
    async with async_session_maker() as session:
        wallet = await session.execute(select(Wallet).where(Wallet.user_id == user_id))
        wallet = wallet.scalar_one_or_none()
        
        transactions = await session.execute(
            select(Transaction)
            .where(Transaction.user_id == user_id)
            .order_by(desc(Transaction.created_at))
            .limit(20)
        )
        transactions = transactions.scalars().all()
        
        invoices = await session.execute(
            select(Invoice)
            .where(Invoice.user_id == user_id)
            .order_by(desc(Invoice.created_at))
            .limit(10)
        )
        invoices = invoices.scalars().all()
        
        plans = await session.execute(select(Plan).where(Plan.is_active == True).order_by(Plan.price))
        plans = plans.scalars().all()
    
    return {
        "wallet": {
            "balance": wallet.balance if wallet else 0,
            "currency": wallet.currency if wallet else "USD"
        },
        "transactions": [
            {
                "uuid": txn.uuid,
                "type": txn.type.value,
                "amount": txn.amount,
                "status": txn.status.value,
                "description": txn.description,
                "created_at": txn.created_at.isoformat()
            }
            for txn in transactions
        ],
        "invoices": [
            {
                "uuid": inv.uuid,
                "amount": inv.amount,
                "status": inv.status.value,
                "description": inv.description,
                "due_date": inv.due_date.isoformat()
            }
            for inv in invoices
        ],
        "plans": [
            {
                "id": plan.id,
                "name": plan.name,
                "description": plan.description,
                "price": plan.price,
                "interval": plan.interval,
                "ram": plan.ram,
                "cpu": plan.cpu,
                "disk": plan.disk
            }
            for plan in plans
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)