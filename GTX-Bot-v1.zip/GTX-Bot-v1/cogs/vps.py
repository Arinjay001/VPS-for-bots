import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button, Select, Modal, TextInput
from typing import Optional, List
import asyncio
from datetime import datetime, timezone

from utils import (
    vps_embed, success_embed, error_embed, info_embed, warning_embed,
    has_permission, is_vps_user, PermissionLevel,
    log_vps_action, get_logger, validate_vps_name, validate_vps_hostname,
    validate_ram, validate_cpu, validate_disk, validate_virtualization,
    validate_os_template, generate_uuid, generate_password
)
from database import async_session_maker, VPSServer, VPSStatus, VirtualizationType, User, Node, PortAllocation
from config import settings
from sqlalchemy import select, func, and_

logger = get_logger("vps")

class VPSCreateWizard(View):
    def __init__(self, author_id: int):
        super().__init__(timeout=300)
        self.author_id = author_id
        self.data = {}
        self.step = 0
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Not your wizard", ephemeral=True)
            return False
        return True
    
    @discord.ui.select(
        placeholder="Select Virtualization",
        options=[
            discord.SelectOption(label="KVM (Full Virtualization)", value="kvm", emoji="����"),
            discord.SelectOption(label="LXC (LXD Supported)", value="lxc_lxd_supported", emoji="������"),
            discord.SelectOption(label="LXC (LXD Unsupported)", value="lxc_lxd_unsupported", emoji="������"),
            discord.SelectOption(label="Docker (Containers)", value="docker", emoji="����"),
        ],
        custom_id="vps_virt_select"
    )
    async def virt_select(self, interaction: discord.Interaction, select: Select):
        self.data['virtualization'] = select.values[0]
        await interaction.response.send_modal(VPSNameModal(self))

class VPSNameModal(Modal, title="VPS Name & Hostname"):
    def __init__(self, wizard: VPSCreateWizard):
        super().__init__()
        self.wizard = wizard
        self.name = TextInput(label="VPS Name", placeholder="my-vps", required=True, max_length=64)
        self.hostname = TextInput(label="Hostname", placeholder="vps.example.com", required=True, max_length=64)
        self.add_item(self.name)
        self.add_item(self.hostname)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not validate_vps_name(self.name.value):
            await interaction.response.send_message(embed=error_embed("Invalid Name", "Use alphanumeric and hyphens only"), ephemeral=True)
            return
        if not validate_vps_hostname(self.hostname.value):
            await interaction.response.send_message(embed=error_embed("Invalid Hostname", "Invalid hostname format"), ephemeral=True)
            return
        
        self.wizard.data['name'] = self.name.value
        self.wizard.data['hostname'] = self.hostname.value
        
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).where(Node.is_active == True, Node.status == "online"))
            nodes = nodes.scalars().all()
        
        if not nodes:
            await interaction.response.send_message(embed=error_embed("No Nodes", "No active nodes available"), ephemeral=True)
            return
        
        options = [discord.SelectOption(label=f"{n.name} ({n.location}) - {n.current_ram}/{n.max_ram}MB RAM", value=str(n.id)) for n in nodes]
        select = Select(placeholder="Select Node", options=options, custom_id="vps_node_select")
        
        async def node_callback(interaction: discord.Interaction):
            self.wizard.data['node_id'] = int(select.values[0])
            await interaction.response.send_modal(VPSResourcesModal(self.wizard))
        
        select.callback = node_callback
        view = View()
        view.add_item(select)
        await interaction.response.send_message(embed=info_embed("Select Node", "Choose a node for your VPS"), view=view, ephemeral=True)

class VPSResourcesModal(Modal, title="VPS Resources"):
    def __init__(self, wizard: VPSCreateWizard):
        super().__init__()
        self.wizard = wizard
        self.ram = TextInput(label="RAM (MB)", placeholder="1024", required=True, max_length=6)
        self.cpu = TextInput(label="CPU Cores", placeholder="1", required=True, max_length=3)
        self.disk = TextInput(label="Disk (GB)", placeholder="10", required=True, max_length=4)
        self.add_item(self.ram)
        self.add_item(self.cpu)
        self.add_item(self.disk)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            ram = int(self.ram.value)
            cpu = int(self.cpu.value)
            disk = int(self.disk.value)
        except ValueError:
            await interaction.response.send_message(embed=error_embed("Invalid Input", "Resources must be numbers"), ephemeral=True)
            return
        
        if not validate_ram(ram) or not validate_cpu(cpu) or not validate_disk(disk):
            await interaction.response.send_message(embed=error_embed("Invalid Resources", "Check limits: RAM 128-1048576, CPU 1-128, Disk 1-10240"), ephemeral=True)
            return
        
        self.wizard.data['ram'] = ram
        self.wizard.data['cpu'] = cpu
        self.wizard.data['disk'] = disk
        
        async with async_session_maker() as session:
            node = await session.get(Node, self.wizard.data['node_id'])
            if node:
                os_options = [discord.SelectOption(label=t, value=t) for t in ["ubuntu-22.04", "ubuntu-24.04", "debian-12", "almalinux-9", "rocky-9"]]
            else:
                os_options = [discord.SelectOption(label="ubuntu-22.04", value="ubuntu-22.04")]
        
        select = Select(placeholder="Select OS Template", options=os_options, custom_id="vps_os_select")
        
        async def os_callback(interaction: discord.Interaction):
            self.wizard.data['os_template'] = select.values[0]
            await self.confirm_creation(interaction)
        
        select.callback = os_callback
        view = View()
        view.add_item(select)
        await interaction.response.send_message(embed=info_embed("Select OS", "Choose operating system"), view=view, ephemeral=True)
    
    async def confirm_creation(self, interaction: discord.Interaction):
        d = self.wizard.data
        embed = vps_embed("Confirm VPS Creation", "Review your configuration:")
        embed.add_field(name="Name", value=d['name'], inline=True)
        embed.add_field(name="Hostname", value=d['hostname'], inline=True)
        embed.add_field(name="Virtualization", value=d['virtualization'], inline=True)
        embed.add_field(name="RAM", value=f"{d['ram']} MB", inline=True)
        embed.add_field(name="CPU", value=f"{d['cpu']} cores", inline=True)
        embed.add_field(name="Disk", value=f"{d['disk']} GB", inline=True)
        embed.add_field(name="OS", value=d['os_template'], inline=True)
        
        view = ConfirmView(self.wizard)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class ConfirmView(View):
    def __init__(self, wizard: VPSCreateWizard):
        super().__init__(timeout=60)
        self.wizard = wizard
    
    @discord.ui.button(label="Create", style=discord.ButtonStyle.success, emoji="���")
    async def confirm(self, interaction: discord.Interaction, button: Button):
        await self.create_vps(interaction)
    
    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger, emoji="���")
    async def cancel(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=error_embed("Cancelled", "VPS creation cancelled"), view=None)
    
    async def create_vps(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        d = self.wizard.data
        
        async with async_session_maker() as session:
            user_result = await session.execute(select(User).where(User.discord_id == interaction.user.id))
            user = user_result.scalar_one_or_none()
            if not user:
                user = User(discord_id=interaction.user.id, username=str(interaction.user))
                session.add(user)
                await session.flush()
            
            vps_count = await session.execute(select(func.count(VPSServer.id)).where(VPSServer.owner_id == user.discord_id, VPSServer.status != VPSStatus.DELETING))
            if vps_count.scalar() >= settings.VPS_MAX_PER_USER:
                await interaction.followup.send(embed=error_embed("Limit Reached", f"Max {settings.VPS_MAX_PER_USER} VPS per user"), ephemeral=True)
                return
            
            node = await session.get(Node, d['node_id'])
            if not node or node.current_ram + d['ram'] > node.max_ram or node.current_cpu + d['cpu'] > node.max_cpu or node.current_disk + d['disk'] > node.max_disk:
                await interaction.followup.send(embed=error_embed("Insufficient Resources", "Node doesn't have enough resources"), ephemeral=True)
                return
            
            port_result = await session.execute(
                select(PortAllocation).where(PortAllocation.node_id == node.id, PortAllocation.is_reserved == False)
                .order_by(PortAllocation.port).limit(1)
            )
            port_alloc = port_result.scalar_one_or_none()
            if not port_alloc:
                await interaction.followup.send(embed=error_embed("No Ports", "No free ports on node"), ephemeral=True)
                return
            
            port_alloc.is_reserved = True
            port_alloc.user_id = user.discord_id
            port_alloc.reserved_until = datetime.now(timezone.utc)
            
            vps = VPSServer(
                uuid=generate_uuid(),
                name=d['name'],
                hostname=d['hostname'],
                owner_id=user.discord_id,
                node_id=node.id,
                status=VPSStatus.CREATING,
                virtualization=VirtualizationType(d['virtualization']),
                os_template=d['os_template'],
                ram=d['ram'],
                cpu=d['cpu'],
                disk=d['disk'],
                ssh_port=port_alloc.port,
                root_password=generate_password(16)
            )
            session.add(vps)
            
            node.current_ram += d['ram']
            node.current_cpu += d['cpu']
            node.current_disk += d['disk']
            node.current_vps += 1
            
            await session.commit()
            await session.refresh(vps)
        
        log_vps_action("CREATE", vps.id, interaction.user.id, node.id, True)
        
        embed = success_embed("VPS Created", f"Your VPS is being provisioned")
        embed.add_field(name="Name", value=vps.name, inline=True)
        embed.add_field(name="Hostname", value=vps.hostname, inline=True)
        embed.add_field(name="IP", value=vps.ipv4_address or "Assigning...", inline=True)
        embed.add_field(name="SSH Port", value=str(vps.ssh_port), inline=True)
        embed.add_field(name="Root Password", value=f"||{vps.root_password}||", inline=True)
        embed.add_field(name="Status", value=vps.status.value, inline=True)
        
        await interaction.followup.send(embed=embed, ephemeral=True)

class VPSActionView(View):
    def __init__(self, vps_id: int):
        super().__init__(timeout=None)
        self.vps_id = vps_id
    
    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, emoji="�����", custom_id="vps_start")
    async def start_btn(self, interaction: discord.Interaction, button: Button):
        await self.action(interaction, "start")
    
    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger, emoji="������", custom_id="vps_stop")
    async def stop_btn(self, interaction: discord.Interaction, button: Button):
        await self.action(interaction, "stop")
    
    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, emoji="����", custom_id="vps_restart")
    async def restart_btn(self, interaction: discord.Interaction, button: Button):
        await self.action(interaction, "restart")
    
    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.secondary, emoji="����", custom_id="vps_reinstall")
    async def reinstall_btn(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(ReinstallModal(self.vps_id))
    
    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="�������", custom_id="vps_delete")
    async def delete_btn(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(DeleteVPSModal(self.vps_id))
    
    async def action(self, interaction: discord.Interaction, action: str):
        if not has_permission(interaction.user, PermissionLevel.VPS_USER):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            if not vps or vps.owner_id != interaction.user.id:
                await interaction.followup.send(embed=error_embed("Not Found", "VPS not found or not yours"), ephemeral=True)
                return
            
            status_map = {
                "start": (VPSStatus.STARTING, VPSStatus.RUNNING),
                "stop": (VPSStatus.STOPPING, VPSStatus.STOPPED),
                "restart": (VPSStatus.RESTARTING, VPSStatus.RUNNING)
            }
            interim, final = status_map[action]
            vps.status = interim
            await session.commit()
        
        log_vps_action(action.upper(), vps.id, interaction.user.id, vps.node_id, True)
        
        await asyncio.sleep(2)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            vps.status = final
            await session.commit()
        
        await interaction.followup.send(embed=success_embed(f"VPS {action.capitalize()}ed", f"VPS {vps.name} is now {final.value}"), ephemeral=True)

class ReinstallModal(Modal, title="Reinstall VPS"):
    def __init__(self, vps_id: int):
        super().__init__()
        self.vps_id = vps_id
        self.os_template = TextInput(label="OS Template", placeholder="ubuntu-22.04", required=True, max_length=50)
        self.add_item(self.os_template)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not validate_os_template(self.os_template.value):
            await interaction.response.send_message(embed=error_embed("Invalid OS", "Invalid template"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            if not vps or vps.owner_id != interaction.user.id:
                await interaction.followup.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
                return
            
            vps.status = VPSStatus.REINSTALLING
            vps.os_template = self.os_template.value
            vps.root_password = generate_password(16)
            await session.commit()
        
        log_vps_action("REINSTALL", vps.id, interaction.user.id, vps.node_id, True)
        
        await asyncio.sleep(3)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            vps.status = VPSStatus.RUNNING
            await session.commit()
        
        embed = success_embed("Reinstalled", f"VPS reinstalled with {self.os_template.value}")
        embed.add_field(name="New Root Password", value=f"||{vps.root_password}||", inline=True)
        await interaction.followup.send(embed=embed, ephemeral=True)

class DeleteVPSModal(Modal, title="Delete VPS - Confirm"):
    def __init__(self, vps_id: int):
        super().__init__()
        self.vps_id = vps_id
        self.confirm = TextInput(label="Type DELETE to confirm", placeholder="DELETE", required=True, max_length=6)
        self.add_item(self.confirm)
    
    async def on_submit(self, interaction: discord.Interaction):
        if self.confirm.value != "DELETE":
            await interaction.response.send_message(embed=error_embed("Cancelled", "Deletion cancelled"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            if not vps or vps.owner_id != interaction.user.id:
                await interaction.followup.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
                return
            
            vps.status = VPSStatus.DELETING
            await session.commit()
        
        log_vps_action("DELETE", vps.id, interaction.user.id, vps.node_id, True)
        
        await asyncio.sleep(2)
        
        async with async_session_maker() as session:
            vps = await session.get(VPSServer, self.vps_id)
            node = await session.get(Node, vps.node_id)
            if node:
                node.current_ram -= vps.ram
                node.current_cpu -= vps.cpu
                node.current_disk -= vps.disk
                node.current_vps -= 1
            
            port = await session.execute(select(PortAllocation).where(PortAllocation.port == vps.ssh_port, PortAllocation.node_id == vps.node_id))
            port = port.scalar_one_or_none()
            if port:
                port.is_reserved = False
                port.user_id = None
                port.vps_id = None
            
            vps.status = VPSStatus.DELETING
            vps.deleted_at = datetime.now(timezone.utc)
            await session.commit()
        
        await interaction.followup.send(embed=success_embed("Deleted", "VPS has been deleted"), ephemeral=True)

class VPSCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="create", description="Create a new VPS (interactive wizard)")
    @commands.guild_only()
    async def create_vps(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            user_vps = await session.execute(select(func.count(VPSServer.id)).where(VPSServer.owner_id == ctx.author.id, VPSServer.status != VPSStatus.DELETING))
            if user_vps.scalar() >= settings.VPS_MAX_PER_USER:
                await ctx.send(embed=error_embed("Limit Reached", f"Max {settings.VPS_MAX_PER_USER} VPS per user"), ephemeral=True)
                return
            
            nodes = await session.execute(select(Node).where(Node.is_active == True))
            if not nodes.scalars().first():
                await ctx.send(embed=error_embed("No Nodes", "No nodes configured"), ephemeral=True)
                return
        
        embed = vps_embed("VPS Creation Wizard", "Let's create your VPS step by step")
        embed.add_field(name="Step 1", value="Select Virtualization", inline=False)
        embed.add_field(name="Step 2", value="Name & Hostname", inline=False)
        embed.add_field(name="Step 3", value="Select Node", inline=False)
        embed.add_field(name="Step 4", value="Resources (RAM/CPU/Disk)", inline=False)
        embed.add_field(name="Step 5", value="OS Template", inline=False)
        embed.add_field(name="Step 6", value="Confirm & Create", inline=False)
        
        view = VPSCreateWizard(ctx.author.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="myvps", description="List your VPS instances")
    @commands.guild_only()
    async def myvps(self, ctx: commands.Context):
        async with async_session_maker() as session:
            vps_list = await session.execute(
                select(VPSServer)
                .where(VPSServer.owner_id == ctx.author.id, VPSServer.status != VPSStatus.DELETING)
                .order_by(VPSServer.created_at.desc())
            )
            vps_list = vps_list.scalars().all()
        
        if not vps_list:
            await ctx.send(embed=info_embed("No VPS", "You don't have any VPS instances. Use `!create` to make one"), ephemeral=True)
            return
        
        embed = vps_embed("Your VPS Instances", f"Total: {len(vps_list)}")
        for vps in vps_list:
            status_emoji = {"creating": "���", "running": "����", "stopped": "����", "starting": "����", "stopping": "����", "restarting": "����", "reinstalling": "����", "deleting": "�������", "error": "���", "suspended": "������"}.get(vps.status.value, "���")
            node = await self.get_node_name(vps.node_id)
            embed.add_field(
                name=f"{status_emoji} {vps.name} ({vps.hostname})",
                value=f"ID: `{vps.uuid[:8]}` | Node: {node} | {vps.ram}MB RAM | {vps.cpu} CPU | {vps.disk}GB | {vps.status.value}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="vps", description="Manage a specific VPS")
    @commands.guild_only()
    async def vps_manage(self, ctx: commands.Context, vps_id: str):
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        embed = vps_embed(f"VPS: {vps.name}", f"Hostname: {vps.hostname}")
        embed.add_field(name="UUID", value=vps.uuid, inline=True)
        embed.add_field(name="Status", value=vps.status.value, inline=True)
        embed.add_field(name="Virtualization", value=vps.virtualization.value, inline=True)
        embed.add_field(name="RAM", value=f"{vps.ram} MB", inline=True)
        embed.add_field(name="CPU", value=f"{vps.cpu} cores", inline=True)
        embed.add_field(name="Disk", value=f"{vps.disk} GB", inline=True)
        embed.add_field(name="OS", value=vps.os_template, inline=True)
        embed.add_field(name="IPv4", value=vps.ipv4_address or "N/A", inline=True)
        embed.add_field(name="SSH Port", value=str(vps.ssh_port), inline=True)
        embed.add_field(name="Root Password", value=f"||{vps.root_password}||", inline=True)
        embed.add_field(name="Node", value=await self.get_node_name(vps.node_id), inline=True)
        embed.add_field(name="Created", value=vps.created_at.strftime("%Y-%m-%d %H:%M"), inline=True)
        
        view = VPSActionView(vps.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="listvps", description="List all VPS (Admin)")
    @commands.guild_only()
    async def listvps(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            vps_list = await session.execute(select(VPSServer).where(VPSServer.status != VPSStatus.DELETING).order_by(VPSServer.created_at.desc()).limit(50))
            vps_list = vps_list.scalars().all()
        
        embed = vps_embed("All VPS Instances", f"Total: {len(vps_list)}")
        for vps in vps_list:
            owner = self.bot.get_user(vps.owner_id)
            embed.add_field(
                name=f"{vps.name} ({vps.hostname})",
                value=f"Owner: {owner.mention if owner else vps.owner_id} | Node: {await self.get_node_name(vps.node_id)} | {vps.status.value}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    async def get_node_name(self, node_id: int) -> str:
        async with async_session_maker() as session:
            node = await session.get(Node, node_id)
            return node.name if node else "Unknown"

async def setup(bot):
    bot.add_view(VPSActionView(0))
    await bot.add_cog(VPSCog(bot))