import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import asyncio

from utils import (
    error_embed, success_embed, info_embed,
    has_permission, PermissionLevel, get_logger,
    get_pterodactyl_api, log_pterodactyl_action
)
from database import async_session_maker, MinecraftServer
from config import settings
from sqlalchemy import select
from utils.ptero_api import PterodactylAPIError

logger = get_logger("pterodactyl")

class PterodactylCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="ptero-server", description="Manage Pterodactyl server")
    @commands.guild_only()
    async def ptero_server(self, ctx: commands.Context, action: str, server_id: int):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        if not settings.PTERODACTYL_URL or not settings.PTERODACTYL_API_KEY:
            await ctx.send(embed=error_embed("Not Configured", "Pterodactyl not configured"), ephemeral=True)
            return
        
        await ctx.response.defer(ephemeral=True) if hasattr(ctx, 'response') else ctx.defer(ephemeral=True)
        
        try:
            async with get_pterodactyl_api() as api:
                if action == "restart":
                    await api.power_action(server_id, "restart")
                    await ctx.followup.send(embed=success_embed("Restarted", f"Server {server_id} restarted"))
                    log_pterodactyl_action("RESTART", server_id, ctx.author.id, True)
                
                elif action == "stop":
                    await api.power_action(server_id, "stop")
                    await ctx.followup.send(embed=success_embed("Stopped", f"Server {server_id} stopped"))
                    log_pterodactyl_action("STOP", server_id, ctx.author.id, True)
                
                elif action == "start":
                    await api.power_action(server_id, "start")
                    await ctx.followup.send(embed=success_embed("Started", f"Server {server_id} started"))
                    log_pterodactyl_action("START", server_id, ctx.author.id, True)
                
                elif action == "kill":
                    await api.power_action(server_id, "kill")
                    await ctx.followup.send(embed=success_embed("Killed", f"Server {server_id} killed"))
                    log_pterodactyl_action("KILL", server_id, ctx.author.id, True)
                
                elif action == "reinstall":
                    await api.power_action(server_id, "reinstall")
                    await ctx.followup.send(embed=success_embed("Reinstalling", f"Server {server_id} reinstalling"))
                    log_pterodactyl_action("REINSTALL", server_id, ctx.author.id, True)
                
                elif action == "backup":
                    result = await api.create_backup(server_id)
                    await ctx.followup.send(embed=success_embed("Backup Created", f"Backup: {result}"))
                    log_pterodactyl_action("BACKUP", server_id, ctx.author.id, True)
                
                elif action == "suspend":
                    await api.power_action(server_id, "suspend")
                    await ctx.followup.send(embed=success_embed("Suspended", f"Server {server_id} suspended"))
                    log_pterodactyl_action("SUSPEND", server_id, ctx.author.id, True)
                
                elif action == "unsuspend":
                    await api.power_action(server_id, "unsuspend")
                    await ctx.followup.send(embed=success_embed("Unsuspended", f"Server {server_id} unsuspended"))
                    log_pterodactyl_action("UNSUSPEND", server_id, ctx.author.id, True)
                
                elif action == "delete":
                    await api.delete_server(server_id)
                    await ctx.followup.send(embed=success_embed("Deleted", f"Server {server_id} deleted"))
                    log_pterodactyl_action("DELETE", server_id, ctx.author.id, True)
                
                elif action == "info":
                    server = await api.get_server(server_id)
                    if not server:
                        await ctx.followup.send(embed=error_embed("Not Found", "Server not found"))
                        return
                    embed = info_embed(f"Server {server.name}", f"UUID: {server.uuid}")
                    embed.add_field(name="ID", value=str(server.id), inline=True)
                    embed.add_field(name="Node", value=str(server.node), inline=True)
                    embed.add_field(name="Owner", value=str(server.owner_id), inline=True)
                    embed.add_field(name="Memory", value=f"{server.limits.get('memory', 0)}MB", inline=True)
                    embed.add_field(name="CPU", value=f"{server.limits.get('cpu', 0)}%", inline=True)
                    embed.add_field(name="Disk", value=f"{server.limits.get('disk', 0)}MB", inline=True)
                    embed.add_field(name="Egg", value=str(server.egg), inline=True)
                    embed.add_field(name="Docker Image", value=server.docker_image, inline=True)
                    await ctx.followup.send(embed=embed)
                
                elif action == "resources":
                    resources = await api.get_server_resources(server_id)
                    if not resources:
                        await ctx.followup.send(embed=error_embed("Not Found", "Server not found"))
                        return
                    embed = info_embed(f"Resources for Server {server_id}")
                    embed.add_field(name="Memory", value=f"{resources.get('memory_bytes', 0) / 1024 / 1024:.1f} MB", inline=True)
                    embed.add_field(name="CPU", value=f"{resources.get('cpu_absolute', 0):.1f}%", inline=True)
                    embed.add_field(name="Disk", value=f"{resources.get('disk_bytes', 0) / 1024 / 1024:.1f} MB", inline=True)
                    embed.add_field(name="Network RX", value=f"{resources.get('network_rx_bytes', 0) / 1024 / 1024:.1f} MB", inline=True)
                    embed.add_field(name="Network TX", value=f"{resources.get('network_tx_bytes', 0) / 1024 / 1024:.1f} MB", inline=True)
                    embed.add_field(name="Uptime", value=f"{resources.get('uptime', 0)}s", inline=True)
                    await ctx.followup.send(embed=embed)
                
                elif action == "command":
                    await ctx.followup.send(embed=info_embed("Send Command", "Use the modal to send a command"), ephemeral=True)
                
                else:
                    await ctx.followup.send(embed=error_embed("Invalid Action", "restart, stop, start, kill, reinstall, backup, suspend, unsuspend, delete, info, resources, command"))
        
        except PterodactylAPIError as e:
            log_pterodactyl_action(action.upper(), server_id, ctx.author.id, False, str(e))
            await ctx.followup.send(embed=error_embed("Pterodactyl Error", str(e)))
        except Exception as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))
    
    @commands.hybrid_command(name="ptero-nodes", description="List Pterodactyl nodes")
    @commands.guild_only()
    async def ptero_nodes(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        if not settings.PTERODACTYL_URL or not settings.PTERODACTYL_API_KEY:
            await ctx.send(embed=error_embed("Not Configured", "Pterodactyl not configured"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        try:
            async with get_pterodactyl_api() as api:
                nodes = await api.get_nodes()
            
            embed = info_embed("Pterodactyl Nodes", f"Total: {len(nodes)}")
            for node in nodes:
                status = "����" if not node.maintenance_mode else "����"
                embed.add_field(
                    name=f"{status} {node.name}",
                    value=f"FQDN: {node.fqdn}\nMemory: {node.memory}MB | Disk: {node.disk}GB\nAllocated: {node.allocated_resources.get('memory', 0)}MB / {node.allocated_resources.get('disk', 0)}GB",
                    inline=False
                )
            await ctx.followup.send(embed=embed)
        
        except PterodactylAPIError as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))
    
    @commands.hybrid_command(name="ptero-eggs", description="List available eggs")
    @commands.guild_only()
    async def ptero_eggs(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        if not settings.PTERODACTYL_URL or not settings.PTERODACTYL_API_KEY:
            await ctx.send(embed=error_embed("Not Configured", "Pterodactyl not configured"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        try:
            async with get_pterodactyl_api() as api:
                nests = await api.get_nests()
            
            embed = info_embed("Available Eggs", f"{len(nests)} nests")
            for nest in nests[:10]:
                attrs = nest['attributes']
                eggs = await api.get_eggs(attrs['id'])
                egg_list = ", ".join([e.name for e in eggs[:5]])
                embed.add_field(
                    name=f"Nest: {attrs['name']} (ID: {attrs['id']})",
                    value=f"Eggs: {egg_list}{'...' if len(eggs) > 5 else ''}",
                    inline=False
                )
            await ctx.followup.send(embed=embed)
        
        except PterodactylAPIError as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))

async def setup(bot):
    await bot.add_cog(PterodactylCog(bot))