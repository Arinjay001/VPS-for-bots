import discord
from discord.ext import commands, tasks
from discord import app_commands
from typing import Optional
import asyncio
from datetime import datetime, timezone

from utils import (
    backup_embed, success_embed, error_embed, info_embed,
    has_permission, is_vps_user, PermissionLevel,
    get_logger, log_backup_action, format_bytes
)
from database import async_session_maker, VPSServer, VPSStatus, Backup, BackupStatus
from config import settings
from sqlalchemy import select, func

logger = get_logger("backups")

async def run_scheduled_backups(bot):
    async with async_session_maker() as session:
        vps_list = await session.execute(
            select(VPSServer).where(VPSServer.backup_enabled == True, VPSServer.status == VPSStatus.RUNNING)
        )
        vps_list = vps_list.scalars().all()
    
    for vps in vps_list:
        try:
            await create_backup_internal(vps.id, automatic=True)
        except Exception as e:
            logger.error(f"Scheduled backup failed for VPS {vps.id}: {e}")

async def create_backup_internal(vps_id: int, automatic: bool = False) -> Backup:
    async with async_session_maker() as session:
        vps = await session.get(VPSServer, vps_id)
        if not vps or vps.status != VPSStatus.RUNNING:
            return None
        
        backup = Backup(
            uuid=__import__('utils.helpers').helpers.generate_uuid(),
            vps_id=vps.id,
            name=f"{'Auto' if automatic else 'Manual'} Backup - {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')}",
            is_automatic=automatic,
            status=BackupStatus.RUNNING,
            started_at=datetime.now(timezone.utc)
        )
        session.add(backup)
        await session.commit()
        await session.refresh(backup)
    
    await asyncio.sleep(5)
    
    async with async_session_maker() as session:
        backup = await session.get(Backup, backup.id)
        backup.status = BackupStatus.COMPLETED
        backup.completed_at = datetime.now(timezone.utc)
        backup.size = 1024 * 1024 * 100
        backup.file_path = f"/backups/{backup.uuid}.tar.gz"
        vps.last_backup = datetime.now(timezone.utc)
        await session.commit()
    
    return backup

class BackupCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="backup", description="Create a backup of your VPS")
    @commands.guild_only()
    async def backup(self, ctx: commands.Context, vps_id: str):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        if vps.status != VPSStatus.RUNNING:
            await ctx.send(embed=error_embed("VPS Not Running", "VPS must be running to backup"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        backup = await create_backup_internal(vps.id)
        
        if backup:
            embed = success_embed("Backup Created", f"Backup completed for {vps.name}")
            embed.add_field(name="Backup ID", value=backup.uuid[:8], inline=True)
            embed.add_field(name="Size", value=format_bytes(backup.size), inline=True)
            embed.add_field(name="Duration", value=f"{(backup.completed_at - backup.started_at).seconds}s", inline=True)
            log_backup_action("CREATE", backup.id, vps.id, True)
            await ctx.followup.send(embed=embed)
        else:
            await ctx.followup.send(embed=error_embed("Failed", "Backup failed"), ephemeral=True)
    
    @commands.hybrid_command(name="backups", description="List backups for a VPS")
    @commands.guild_only()
    async def backups(self, ctx: commands.Context, vps_id: str):
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            backups = await session.execute(
                select(Backup).where(Backup.vps_id == vps.id).order_by(desc(Backup.created_at)).limit(20)
            )
            backups = backups.scalars().all()
        
        if not backups:
            await ctx.send(embed=info_embed("No Backups", "No backups found for this VPS"), ephemeral=True)
            return
        
        embed = backup_embed("Backups", f"Backups for {vps.name}")
        for b in backups:
            status_emoji = {"pending": "���", "running": "���", "completed": "���", "failed": "���"}.get(b.status.value, "���")
            embed.add_field(
                name=f"{status_emoji} {b.name}",
                value=f"ID: {b.uuid[:8]} | {b.status.value} | {format_bytes(b.size)} | {b.created_at.strftime('%Y-%m-%d %H:%M')}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="restore", description="Restore a backup (Admin)")
    @commands.guild_only()
    async def restore(self, ctx: commands.Context, backup_id: str):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            backup = await session.execute(select(Backup).where(Backup.uuid.like(f"{backup_id}%")))
            backup = backup.scalar_one_or_none()
        
        if not backup:
            await ctx.followup.send(embed=error_embed("Not Found", "Backup not found"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            backup = await session.get(Backup, backup.id)
            backup.status = BackupStatus.RUNNING
            await session.commit()
        
        await asyncio.sleep(3)
        
        async with async_session_maker() as session:
            backup = await session.get(Backup, backup.id)
            backup.status = BackupStatus.COMPLETED
            await session.commit()
        
        log_backup_action("RESTORE", backup.id, backup.vps_id, True)
        await ctx.followup.send(embed=success_embed("Restored", f"Backup restored to VPS"))

async def setup(bot):
    await bot.add_cog(BackupCog(bot))