import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

from utils import (
    error_embed, success_embed, info_embed, warning_embed,
    is_admin, is_owner, has_permission, PermissionLevel,
    get_logger, log_guild_action
)
from database import async_session_maker, GuildConfig
from config import settings
from sqlalchemy import select

logger = get_logger("admin")

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="setup", description="Initial server setup wizard")
    @commands.guild_only()
    async def setup(self, ctx: commands.Context):
        if not is_owner(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Bot owner only"), ephemeral=True)
            return
        
        embed = info_embed("GTX Bot Setup Wizard", "Configure the bot for this server")
        embed.add_field(name="1. Ticket System", value="Set ticket category, log channel, transcript channel", inline=False)
        embed.add_field(name="2. Guardian", value="Configure security modules", inline=False)
        embed.add_field(name="3. Roles", value="Set Admin, Staff, Customer, VPS User, Premium roles", inline=False)
        embed.add_field(name="4. Nodes", value="Register VPS nodes", inline=False)
        
        view = SetupView(ctx.author.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="config", description="View/Edit server configuration")
    @commands.guild_only()
    async def config(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == ctx.guild.id))
            config = config.scalar_one_or_none()
        
        if not config:
            config = GuildConfig(guild_id=ctx.guild.id)
        
        embed = info_embed("Server Configuration", f"Settings for {ctx.guild.name}")
        embed.add_field(name="Prefix", value=config.prefix, inline=True)
        embed.add_field(name="Language", value=config.language, inline=True)
        embed.add_field(name="Timezone", value=config.timezone, inline=True)
        embed.add_field(name="Ticket Category", value=f"<#{config.ticket_category_id}>" if config.ticket_category_id else "Not set", inline=True)
        embed.add_field(name="Ticket Logs", value=f"<#{config.ticket_log_channel_id}>" if config.ticket_log_channel_id else "Not set", inline=True)
        embed.add_field(name="Transcripts", value=f"<#{config.transcript_channel_id}>" if config.transcript_channel_id else "Not set", inline=True)
        embed.add_field(name="VPS Logs", value=f"<#{config.vps_log_channel_id}>" if config.vps_log_channel_id else "Not set", inline=True)
        embed.add_field(name="Guardian Logs", value=f"<#{config.guardian_log_channel_id}>" if config.guardian_log_channel_id else "Not set", inline=True)
        embed.add_field(name="Guardian Enabled", value="Yes" if config.guardian_enabled else "No", inline=True)
        embed.add_field(name="Anti-Raid", value="Yes" if config.anti_raid_enabled else "No", inline=True)
        embed.add_field(name="Anti-Spam", value="Yes" if config.anti_spam_enabled else "No", inline=True)
        
        view = ConfigView(ctx.guild.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="set-role", description="Set a role for bot permissions")
    @commands.guild_only()
    async def set_role(self, ctx: commands.Context, role_type: str, role: discord.Role):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        role_map = {
            "admin": "ADMIN_ROLE_IDS",
            "staff": "STAFF_ROLE_IDS",
            "customer": "CUSTOMER_ROLE_IDS",
            "vps": "VPS_USER_ROLE_IDS",
            "premium": "PREMIUM_ROLE_IDS",
        }
        
        if role_type.lower() not in role_map:
            await ctx.send(embed=error_embed("Invalid Type", f"Types: {', '.join(role_map.keys())}"), ephemeral=True)
            return
        
        await ctx.send(embed=success_embed("Role Set", f"{role_type.title()} role set to {role.mention}\nRestart bot to apply."))
    
    @commands.hybrid_command(name="reload", description="Reload bot extensions (Owner)")
    @commands.guild_only()
    async def reload(self, ctx: commands.Context, extension: str = None):
        if not is_owner(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Owner only"), ephemeral=True)
            return
        
        if extension:
            try:
                await self.bot.reload_extension(f"cogs.{extension}")
                await ctx.send(embed=success_embed("Reloaded", f"Extension {extension} reloaded"))
            except Exception as e:
                await ctx.send(embed=error_embed("Error", str(e)))
        else:
            for ext in self.bot.initial_extensions:
                try:
                    await self.bot.reload_extension(ext)
                except Exception:
                    pass
            await ctx.send(embed=success_embed("Reloaded", "All extensions reloaded"))
    
    @commands.hybrid_command(name="sync", description="Sync slash commands (Owner)")
    @commands.guild_only()
    async def sync(self, ctx: commands.Context, guild_only: bool = False):
        if not is_owner(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Owner only"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        if guild_only:
            await self.bot.tree.sync(guild=ctx.guild)
            await ctx.followup.send(embed=success_embed("Synced", f"Commands synced to {ctx.guild.name}"))
        else:
            await self.bot.tree.sync()
            await ctx.followup.send(embed=success_embed("Synced", "Global commands synced"))
    
    @commands.hybrid_command(name="lockdown", description="Toggle server lockdown (Admin)")
    @commands.guild_only()
    async def lockdown(self, ctx: commands.Context, enabled: bool):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        try:
            await ctx.guild.default_role.edit(permissions=discord.Permissions.none() if enabled else discord.Permissions.all())
            await ctx.send(embed=success_embed("Lockdown", f"Server {'locked' if enabled else 'unlocked'}"))
        except Exception as e:
            await ctx.send(embed=error_embed("Error", str(e)))
    
    @commands.hybrid_command(name="announce", description="Send announcement (Admin)")
    @commands.guild_only()
    async def announce(self, ctx: commands.Context, channel: discord.TextChannel, title: str, message: str):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        embed = info_embed(title, message)
        embed.set_footer(text=f"Announcement by {ctx.author}")
        await channel.send(embed=embed)
        await ctx.send(embed=success_embed("Sent", f"Announcement sent to {channel.mention}"), ephemeral=True)

class SetupView(discord.ui.View):
    def __init__(self, author_id: int):
        super().__init__(timeout=300)
        self.author_id = author_id
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author_id

class ConfigView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=300)
        self.guild_id = guild_id

async def setup(bot):
    await bot.add_cog(AdminCog(bot))