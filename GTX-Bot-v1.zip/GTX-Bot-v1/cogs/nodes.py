import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button, Select
from typing import Optional, List
import asyncio
from datetime import datetime, timezone

from utils import (
    node_embed, success_embed, error_embed, info_embed,
    has_permission, PermissionLevel,
    log_node_event, get_logger, validate_node_name, validate_node_host,
    generate_api_key, format_bytes
)
from database import async_session_maker, Node, NodeStatus, GuildConfig
from config import settings
from sqlalchemy import select, func
import aiohttp

logger = get_logger("nodes")

class NodeRegisterModal(Modal, title="Register Node"):
    def __init__(self):
        super().__init__()
        self.name = TextInput(label="Node Name", placeholder="us-east-1", required=True, max_length=64)
        self.host = TextInput(label="Host (IP or Domain)", placeholder="192.168.1.100", required=True, max_length=255)
        self.port = TextInput(label="Port", placeholder="8080", required=True, max_length=5)
        self.location = TextInput(label="Location", placeholder="New York, USA", required=True, max_length=100)
        self.api_key = TextInput(label="API Key (leave blank to auto-generate)", placeholder="auto-generated if empty", required=False, max_length=100)
        self.add_item(self.name)
        self.add_item(self.host)
        self.add_item(self.port)
        self.add_item(self.location)
        self.add_item(self.api_key)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not validate_node_name(self.name.value):
            await interaction.response.send_message(embed=error_embed("Invalid Name", "Use alphanumeric, hyphens, underscores"), ephemeral=True)
            return
        if not validate_node_host(self.host.value):
            await interaction.response.send_message(embed=error_embed("Invalid Host", "Invalid IP or hostname"), ephemeral=True)
            return
        try:
            port = int(self.port.value)
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            await interaction.response.send_message(embed=error_embed("Invalid Port", "Port must be 1-65535"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        api_key = self.api_key.value or generate_api_key("node")
        
        async with async_session_maker() as session:
            existing = await session.execute(select(Node).where(Node.name == self.name.value))
            if existing.scalar_one_or_none():
                await interaction.followup.send(embed=error_embed("Exists", "Node with this name already exists"), ephemeral=True)
                return
            
            node = Node(
                name=self.name.value,
                host=self.host.value,
                port=port,
                api_key=api_key,
                location=self.location.value,
                is_active=True,
                status=NodeStatus.OFFLINE
            )
            session.add(node)
            await session.commit()
            await session.refresh(node)
        
        log_node_event("REGISTER", node.id, f"Registered by {interaction.user}")
        
        embed = success_embed("Node Registered", f"Node **{node.name}** registered successfully")
        embed.add_field(name="Host", value=f"{node.host}:{node.port}", inline=True)
        embed.add_field(name="Location", value=node.location, inline=True)
        embed.add_field(name="API Key", value=f"||{api_key}||", inline=False)
        embed.add_field(name="Virtualization", value="Auto-detect on connect", inline=True)
        
        await interaction.followup.send(embed=embed, ephemeral=True)

class NodeActionView(View):
    def __init__(self, node_id: int):
        super().__init__(timeout=None)
        self.node_id = node_id
    
    @discord.ui.button(label="Test Connection", style=discord.ButtonStyle.primary, emoji="����", custom_id="node_test")
    async def test_btn(self, interaction: discord.Interaction, button: Button):
        await self.test_connection(interaction)
    
    @discord.ui.button(label="Refresh Stats", style=discord.ButtonStyle.secondary, emoji="����", custom_id="node_refresh")
    async def refresh_btn(self, interaction: discord.Interaction, button: Button):
        await self.refresh_stats(interaction)
    
    @discord.ui.button(label="Toggle Active", style=discord.ButtonStyle.success, emoji="����", custom_id="node_toggle")
    async def toggle_btn(self, interaction: discord.Interaction, button: Button):
        await self.toggle_active(interaction)
    
    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="�������", custom_id="node_delete")
    async def delete_btn(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(DeleteNodeModal(self.node_id))
    
    async def test_connection(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            node = await session.get(Node, self.node_id)
            if not node:
                await interaction.followup.send(embed=error_embed("Not Found", "Node not found"), ephemeral=True)
                return
        
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get(f"http://{node.host}:{node.port}/health", headers={"Authorization": f"Bearer {node.api_key}"}) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        async with async_session_maker() as session:
                            node = await session.get(Node, self.node_id)
                            node.status = NodeStatus.ONLINE
                            node.last_heartbeat = datetime.now(timezone.utc)
                            await session.commit()
                        await interaction.followup.send(embed=success_embed("Connection OK", f"Node responded: {data}"), ephemeral=True)
                    else:
                        await interaction.followup.send(embed=error_embed("Failed", f"HTTP {resp.status}"), ephemeral=True)
        except Exception as e:
            async with async_session_maker() as session:
                node = await session.get(Node, self.node_id)
                node.status = NodeStatus.OFFLINE
                await session.commit()
            await interaction.followup.send(embed=error_embed("Connection Failed", str(e)), ephemeral=True)
    
    async def refresh_stats(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            node = await session.get(Node, self.node_id)
            if not node:
                await interaction.followup.send(embed=error_embed("Not Found", "Node not found"), ephemeral=True)
                return
        
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get(f"http://{node.host}:{node.port}/api/v1/stats", headers={"Authorization": f"Bearer {node.api_key}"}) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        async with async_session_maker() as session:
                            node = await session.get(Node, self.node_id)
                            node.current_ram = data.get("memory_used", 0)
                            node.current_cpu = data.get("cpu_percent", 0)
                            node.current_disk = data.get("disk_used", 0)
                            node.current_vps = data.get("vps_count", 0)
                            node.network_rx = data.get("network_rx", 0)
                            node.network_tx = data.get("network_tx", 0)
                            node.latency = data.get("latency", 0)
                            node.last_stats = datetime.now(timezone.utc)
                            node.last_heartbeat = datetime.now(timezone.utc)
                            node.status = NodeStatus.ONLINE
                            
                            if "virtualization" in data:
                                node.set_virtualization_types(data["virtualization"])
                            
                            await session.commit()
                        
                        log_node_event("STATS_REFRESH", node.id, f"Refreshed by {interaction.user}")
                        await interaction.followup.send(embed=success_embed("Stats Refreshed", "Node statistics updated"), ephemeral=True)
                    else:
                        await interaction.followup.send(embed=error_embed("Failed", f"HTTP {resp.status}"), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=error_embed("Failed", str(e)), ephemeral=True)
    
    async def toggle_active(self, interaction: discord.Interaction):
        if not has_permission(interaction.user, PermissionLevel.ADMIN):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            node = await session.get(Node, self.node_id)
            if not node:
                await interaction.response.send_message(embed=error_embed("Not Found", "Node not found"), ephemeral=True)
                return
            
            node.is_active = not node.is_active
            await session.commit()
            
            log_node_event("TOGGLE_ACTIVE", node.id, f"Set to {node.is_active} by {interaction.user}")
            
            await interaction.response.send_message(embed=success_embed("Toggled", f"Node is now {'active' if node.is_active else 'inactive'}"), ephemeral=True)

class DeleteNodeModal(Modal, title="Delete Node - Confirm"):
    def __init__(self, node_id: int):
        super().__init__()
        self.node_id = node_id
        self.confirm = TextInput(label="Type DELETE to confirm", placeholder="DELETE", required=True, max_length=6)
        self.add_item(self.confirm)
    
    async def on_submit(self, interaction: discord.Interaction):
        if self.confirm.value != "DELETE":
            await interaction.response.send_message(embed=error_embed("Cancelled", "Deletion cancelled"), ephemeral=True)
            return
        
        if not has_permission(interaction.user, PermissionLevel.ADMIN):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            node = await session.get(Node, self.node_id)
            if not node:
                await interaction.followup.send(embed=error_embed("Not Found", "Node not found"), ephemeral=True)
                return
            
            vps_count = await session.execute(select(func.count()).select_from(Node.__table__.join(VPSServer.__table__)).where(Node.id == self.node_id))
            
            await session.delete(node)
            await session.commit()
        
        log_node_event("DELETE", self.node_id, f"Deleted by {interaction.user}")
        await interaction.followup.send(embed=success_embed("Deleted", "Node has been deleted"), ephemeral=True)

class NodesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="node-add", description="Register a new node")
    @commands.guild_only()
    async def node_add(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        await ctx.send_modal(NodeRegisterModal())
    
    @commands.hybrid_command(name="nodes", description="List all nodes")
    @commands.guild_only()
    async def nodes_list(self, ctx: commands.Context):
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).order_by(Node.created_at.desc()))
            nodes = nodes.scalars().all()
        
        if not nodes:
            await ctx.send(embed=info_embed("No Nodes", "No nodes registered. Use `!node-add` to add one"), ephemeral=True)
            return
        
        embed = node_embed("Node List", f"Total: {len(nodes)}")
        for node in nodes:
            status_emoji = {"online": "����", "offline": "����", "maintenance": "����", "error": "���"}.get(node.status.value, "���")
            virt_types = ", ".join([v.value for v in node.get_virtualization_types()])
            embed.add_field(
                name=f"{status_emoji} {node.name} ({node.location})",
                value=f"Host: {node.host}:{node.port} | RAM: {format_bytes(node.current_ram*1024*1024)}/{format_bytes(node.max_ram*1024*1024)} | CPU: {node.current_cpu}/{node.max_cpu} | VPS: {node.current_vps}/{node.max_vps} | Virt: {virt_types}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="node", description="View node details")
    @commands.guild_only()
    async def node_info(self, ctx: commands.Context, node_id: int):
        async with async_session_maker() as session:
            node = await session.get(Node, node_id)
        
        if not node:
            await ctx.send(embed=error_embed("Not Found", "Node not found"), ephemeral=True)
            return
        
        embed = node_embed(f"Node: {node.name}", f"Location: {node.location}")
        embed.add_field(name="ID", value=str(node.id), inline=True)
        embed.add_field(name="Host", value=f"{node.host}:{node.port}", inline=True)
        embed.add_field(name="Status", value=node.status.value, inline=True)
        embed.add_field(name="Active", value="Yes" if node.is_active else "No", inline=True)
        embed.add_field(name="RAM", value=f"{format_bytes(node.current_ram*1024*1024)} / {format_bytes(node.max_ram*1024*1024)}", inline=True)
        embed.add_field(name="CPU", value=f"{node.current_cpu}% / {node.max_cpu} cores", inline=True)
        embed.add_field(name="Disk", value=f"{format_bytes(node.current_disk*1024*1024)} / {format_bytes(node.max_disk*1024*1024)}", inline=True)
        embed.add_field(name="VPS Count", value=f"{node.current_vps} / {node.max_vps}", inline=True)
        embed.add_field(name="Latency", value=f"{node.latency}ms", inline=True)
        embed.add_field(name="Network RX", value=format_bytes(node.network_rx), inline=True)
        embed.add_field(name="Network TX", value=format_bytes(node.network_tx), inline=True)
        embed.add_field(name="Virtualization", value=", ".join([v.value for v in node.get_virtualization_types()]), inline=True)
        embed.add_field(name="Last Heartbeat", value=node.last_heartbeat.strftime("%Y-%m-%d %H:%M:%S") if node.last_heartbeat else "Never", inline=True)
        embed.add_field(name="Last Stats", value=node.last_stats.strftime("%Y-%m-%d %H:%M:%S") if node.last_stats else "Never", inline=True)
        
        view = NodeActionView(node.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="node-refresh", description="Refresh all node stats")
    @commands.guild_only()
    async def node_refresh_all(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        await ctx.send(embed=info_embed("Refreshing", "Refreshing all node stats..."), ephemeral=True)
        
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).where(Node.is_active == True))
            nodes = nodes.scalars().all()
        
        success = 0
        for node in nodes:
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                    async with session.get(f"http://{node.host}:{node.port}/api/v1/stats", headers={"Authorization": f"Bearer {node.api_key}"}) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            async with async_session_maker() as session:
                                n = await session.get(Node, node.id)
                                n.current_ram = data.get("memory_used", 0)
                                n.current_cpu = data.get("cpu_percent", 0)
                                n.current_disk = data.get("disk_used", 0)
                                n.current_vps = data.get("vps_count", 0)
                                n.network_rx = data.get("network_rx", 0)
                                n.network_tx = data.get("network_tx", 0)
                                n.latency = data.get("latency", 0)
                                n.last_stats = datetime.now(timezone.utc)
                                n.last_heartbeat = datetime.now(timezone.utc)
                                n.status = NodeStatus.ONLINE
                                if "virtualization" in data:
                                    n.set_virtualization_types(data["virtualization"])
                                await session.commit()
                            success += 1
            except Exception:
                pass
        
        await ctx.send(embed=success_embed("Done", f"Refreshed {success}/{len(nodes)} nodes"), ephemeral=True)

async def setup(bot):
    bot.add_view(NodeActionView(0))
    await bot.add_cog(NodesCog(bot))