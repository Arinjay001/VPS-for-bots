import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button, Select, Modal, TextInput
from typing import Optional
import asyncio
from datetime import datetime, timezone, timedelta

from utils import (
    error_embed, success_embed, info_embed,
    has_permission, is_admin, PermissionLevel,
    get_logger, generate_uuid
)
from database import async_session_maker, User
from config import settings
from sqlalchemy import select, Column, Integer, String, BigInteger, Float, DateTime, Enum, ForeignKey, Text
from sqlalchemy.ext.declarative import declarative_base
import enum

logger = get_logger("billing")

Base = declarative_base()

class TransactionType(str, enum.Enum):
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"
    PURCHASE = "purchase"
    REFUND = "refund"
    CREDIT = "credit"

class TransactionStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class InvoiceStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    EXPIRED = "expired"
    CANCELLED = "cancelled"

class Wallet(Base):
    __tablename__ = "wallets"
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, unique=True, nullable=False)
    balance = Column(Float, default=0.0)
    currency = Column(String(10), default="USD")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    uuid = Column(String(36), unique=True, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    type = Column(Enum(TransactionType), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    status = Column(Enum(TransactionStatus), default=TransactionStatus.PENDING)
    description = Column(Text)
    reference_id = Column(String(100))
    payment_method = Column(String(50))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)

class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True)
    uuid = Column(String(36), unique=True, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    status = Column(Enum(InvoiceStatus), default=InvoiceStatus.PENDING)
    description = Column(Text)
    due_date = Column(DateTime, nullable=False)
    paid_at = Column(DateTime, nullable=True)
    payment_url = Column(String(500))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class Plan(Base):
    __tablename__ = "plans"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    price = Column(Float, nullable=False)
    currency = Column(String(10), default="USD")
    interval = Column(String(20), default="monthly")
    ram = Column(Integer)
    cpu = Column(Integer)
    disk = Column(Integer)
    bandwidth = Column(Integer)
    backups = Column(Integer, default=0)
    features = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class BillingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="wallet", description="View your wallet balance")
    @commands.guild_only()
    async def wallet(self, ctx: commands.Context):
        async with async_session_maker() as session:
            wallet = await session.execute(select(Wallet).where(Wallet.user_id == ctx.author.id))
            wallet = wallet.scalar_one_or_none()
        
        if not wallet:
            async with async_session_maker() as session:
                wallet = Wallet(user_id=ctx.author.id, balance=0.0)
                session.add(wallet)
                await session.commit()
        
        embed = info_embed("Wallet", f"Balance: **${wallet.balance:.2f} {wallet.currency}**")
        embed.add_field(name="Add Funds", value="Use `!deposit` to add funds", inline=False)
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="deposit", description="Add funds to wallet")
    @commands.guild_only()
    async def deposit(self, ctx: commands.Context, amount: float):
        if amount < 1 or amount > 10000:
            await ctx.send(embed=error_embed("Invalid Amount", "Amount must be between $1 and $10,000"), ephemeral=True)
            return
        
        embed = info_embed("Deposit", f"Amount: **${amount:.2f}**")
        embed.add_field(name="Payment Methods", value="• Stripe\n• PayPal\n• Crypto (USDT/USDC)\n• Bank Transfer", inline=False)
        embed.add_field(name="Instructions", value="Payment integration requires Stripe/PayPal keys in .env", inline=False)
        
        view = DepositView(ctx.author.id, amount)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="plans", description="View available hosting plans")
    @commands.guild_only()
    async def plans(self, ctx: commands.Context):
        async with async_session_maker() as session:
            plans = await session.execute(select(Plan).where(Plan.is_active == True).order_by(Plan.price))
            plans = plans.scalars().all()
        
        if not plans:
            await ctx.send(embed=info_embed("No Plans", "No hosting plans configured"), ephemeral=True)
            return
        
        embed = info_embed("Hosting Plans", "Choose a plan for your VPS")
        for plan in plans:
            features = plan.features.split(",") if plan.features else []
            feat_text = "\n".join([f"• {f.strip()}" for f in features[:5]])
            embed.add_field(
                name=f"{plan.name} - ${plan.price:.2f}/{plan.interval}",
                value=f"{plan.ram}MB RAM | {plan.cpu} CPU | {plan.disk}GB Disk\n{feat_text}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="purchase", description="Purchase a hosting plan")
    @commands.guild_only()
    async def purchase(self, ctx: commands.Context, plan_name: str):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            plan = await session.execute(select(Plan).where(Plan.name == plan_name, Plan.is_active == True))
            plan = plan.scalar_one_or_none()
            wallet = await session.execute(select(Wallet).where(Wallet.user_id == ctx.author.id))
            wallet = wallet.scalar_one_or_none()
        
        if not plan:
            await ctx.send(embed=error_embed("Plan Not Found", f"Plan '{plan_name}' not found"), ephemeral=True)
            return
        
        if not wallet or wallet.balance < plan.price:
            await ctx.send(embed=error_embed("Insufficient Funds", f"Need ${plan.price:.2f}, have ${wallet.balance:.2f if wallet else 0}"), ephemeral=True)
            return
        
        await ctx.send_modal(PurchaseConfirmModal(ctx.author.id, plan.id))
    
    @commands.hybrid_command(name="transactions", description="View transaction history")
    @commands.guild_only()
    async def transactions(self, ctx: commands.Context, limit: int = 10):
        async with async_session_maker() as session:
            txns = await session.execute(
                select(Transaction)
                .where(Transaction.user_id == ctx.author.id)
                .order_by(Transaction.created_at.desc())
                .limit(limit)
            )
            txns = txns.scalars().all()
        
        if not txns:
            await ctx.send(embed=info_embed("No Transactions", "No transaction history"), ephemeral=True)
            return
        
        embed = info_embed("Transaction History", f"Last {len(txns)} transactions")
        for txn in txns:
            status_emoji = {"completed": "���", "pending": "���", "failed": "���", "cancelled": "������"}.get(txn.status.value, "���")
            embed.add_field(
                name=f"{status_emoji} {txn.type.value.title()} - ${txn.amount:.2f}",
                value=f"{txn.description or 'N/A'} | {txn.created_at.strftime('%Y-%m-%d %H:%M')}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="invoice", description="Create invoice for manual payment")
    @commands.guild_only()
    async def invoice(self, ctx: commands.Context, amount: float, description: str = "Manual payment"):
        if amount < 1:
            await ctx.send(embed=error_embed("Invalid Amount", "Amount must be at least $1"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            invoice = Invoice(
                uuid=generate_uuid(),
                user_id=ctx.author.id,
                amount=amount,
                description=description,
                due_date=datetime.now(timezone.utc) + timedelta(days=7)
            )
            session.add(invoice)
            await session.commit()
        
        embed = success_embed("Invoice Created", f"Invoice for **${amount:.2f}**")
        embed.add_field(name="Invoice ID", value=invoice.uuid[:8], inline=True)
        embed.add_field(name="Due Date", value=invoice.due_date.strftime("%Y-%m-%d"), inline=True)
        embed.add_field(name="Description", value=description, inline=False)
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="add-funds", description="Add funds to user (Admin)")
    @commands.guild_only()
    async def add_funds(self, ctx: commands.Context, user: discord.User, amount: float):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            wallet = await session.execute(select(Wallet).where(Wallet.user_id == user.id))
            wallet = wallet.scalar_one_or_none()
            if not wallet:
                wallet = Wallet(user_id=user.id, balance=0.0)
                session.add(wallet)
            wallet.balance += amount
            await session.commit()
        
        await ctx.send(embed=success_embed("Funds Added", f"Added ${amount:.2f} to {user.mention}"))

class DepositView(View):
    def __init__(self, user_id: int, amount: float):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.amount = amount

class PurchaseConfirmModal(Modal, title="Confirm Purchase"):
    def __init__(self, user_id: int, plan_id: int):
        super().__init__()
        self.user_id = user_id
        self.plan_id = plan_id
        self.confirm = TextInput(label="Type CONFIRM to purchase", placeholder="CONFIRM", required=True, max_length=7)
        self.add_item(self.confirm)
    
    async def on_submit(self, interaction: discord.Interaction):
        if self.confirm.value != "CONFIRM":
            await interaction.response.send_message(embed=error_embed("Cancelled", "Purchase cancelled"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            plan = await session.get(Plan, self.plan_id)
            wallet = await session.execute(select(Wallet).where(Wallet.user_id == interaction.user.id))
            wallet = wallet.scalar_one_or_none()
            
            wallet.balance -= plan.price
            
            txn = Transaction(
                uuid=generate_uuid(),
                user_id=interaction.user.id,
                type=TransactionType.PURCHASE,
                amount=-plan.price,
                status=TransactionStatus.COMPLETED,
                description=f"Purchased {plan.name} plan",
                completed_at=datetime.now(timezone.utc)
            )
            session.add(txn)
            await session.commit()
        
        await interaction.followup.send(embed=success_embed("Purchase Complete", f"Purchased **{plan.name}** for ${plan.price:.2f}"), ephemeral=True)

async def setup(bot):
    await bot.add_cog(BillingCog(bot))