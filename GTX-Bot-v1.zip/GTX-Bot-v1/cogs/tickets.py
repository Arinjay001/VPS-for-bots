import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button, Select, Modal, TextInput
from typing import Optional, List
import asyncio
from datetime import datetime, timezone

from utils import (
    ticket_embed, success_embed, error_embed, info_embed,
    has_permission, is_staff, PermissionLevel,
    log_ticket_action, get_logger, validate_ticket_subject, validate_ticket_description
)
from database import async_session_maker, Ticket, TicketStatus, TicketCategory, TicketMessage, TicketParticipant, GuildConfig, User
from config import settings
from sqlalchemy import select, func, desc

logger = get_logger("tickets")

class TicketCategorySelect(Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="General Support", value="general", description="General questions and support", emoji="���"),
            discord.SelectOption(label="Technical Support", value="technical", description="Technical issues and troubleshooting", emoji="����"),
            discord.SelectOption(label="VPS Issues", value="vps", description="VPS-related problems", emoji="�������"),
            discord.SelectOption(label="Minecraft Server", value="minecraft", description="Minecraft server issues", emoji="����"),
            discord.SelectOption(label="Billing", value="billing", description="Billing and payment questions", emoji="����"),
            discord.SelectOption(label="Abuse Report", value="abuse", description="Report abuse or violations", emoji="������"),
            discord.SelectOption(label="Other", value="other", description="Other inquiries", emoji="����"),
        ]
        super().__init__(placeholder="Select a category...", options=options, custom_id="ticket_category_select")
    
    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(TicketCreateModal(self.values[0]))

class TicketCreateModal(Modal, title="Create Ticket"):
    def __init__(self, category: str):
        super().__init__(custom_id=f"ticket_create_{category}")
        self.category = category
        
        self.subject = TextInput(
            label="Subject",
            placeholder="Brief description of your issue",
            required=True,
            max_length=100
        )
        self.description = TextInput(
            label="Description",
            placeholder="Detailed description of your issue...",
            style=discord.TextStyle.paragraph,
            required=True,
            max_length=4000
        )
        self.add_item(self.subject)
        self.add_item(self.description)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not validate_ticket_subject(self.subject.value):
            await interaction.response.send_message(embed=error_embed("Invalid Subject", "Subject must be 1-100 characters"), ephemeral=True)
            return
        if not validate_ticket_description(self.description.value):
            await interaction.response.send_message(embed=error_embed("Invalid Description", "Description too long (max 4000 chars)"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            guild_config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == interaction.guild.id))
            guild_config = guild_config.scalar_one_or_none()
            
            if not guild_config or not guild_config.ticket_category_id:
                await interaction.followup.send(embed=error_embed("Not Configured", "Ticket system not set up. Contact admin."), ephemeral=True)
                return
            
            category_channel = interaction.guild.get_channel(guild_config.ticket_category_id)
            if not category_channel:
                await interaction.followup.send(embed=error_embed("Category Missing", "Ticket category channel not found"), ephemeral=True)
                return
            
            existing = await session.execute(
                select(Ticket).where(
                    Ticket.guild_id == interaction.guild.id,
                    Ticket.creator_id == interaction.user.id,
                    Ticket.status.in_([TicketStatus.OPEN, TicketStatus.CLAIMED])
                )
            )
            if existing.scalar_one_or_none():
                await interaction.followup.send(embed=error_embed("Limit Reached", "You already have an open ticket"), ephemeral=True)
                return
            
            ticket_number = await session.execute(
                select(func.max(Ticket.ticket_number)).where(Ticket.guild_id == interaction.guild.id)
            )
            ticket_number = (ticket_number.scalar() or 0) + 1
            
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True, embed_links=True),
                interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True, manage_messages=True)
            }
            
            for role_id in settings.STAFF_ROLE_IDS:
                role = interaction.guild.get_role(role_id)
                if role:
                    overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
            
            ticket_channel = await category_channel.create_text_channel(
                name=f"ticket-{ticket_number:04d}-{interaction.user.name}",
                overwrites=overwrites,
                topic=f"Ticket #{ticket_number} | {interaction.user} ({interaction.user.id}) | Category: {self.category}"
            )
            
            ticket = Ticket(
                ticket_number=ticket_number,
                guild_id=interaction.guild.id,
                channel_id=ticket_channel.id,
                creator_id=interaction.user.id,
                category=TicketCategory(self.category),
                subject=self.subject.value,
                description=self.description.value,
                status=TicketStatus.OPEN
            )
            session.add(ticket)
            
            participant = TicketParticipant(
                ticket_id=ticket.id,
                user_id=interaction.user.id,
                user_name=str(interaction.user),
                added_by=interaction.user.id
            )
            session.add(participant)
            
            await session.commit()
            await session.refresh(ticket)
            
            embed = ticket_embed(
                f"Ticket #{ticket_number:04d} - {self.subject.value}",
                f"**Category:** {self.category.title()}\n**Created by:** {interaction.user.mention}\n\n{self.description.value}"
            )
            embed.add_field(name="Status", value="���� Open", inline=True)
            embed.add_field(name="Priority", value="Normal", inline=True)
            
            view = TicketControlView(ticket.id)
            msg = await ticket_channel.send(content=interaction.user.mention, embed=embed, view=view)
            
            ticket_msg = TicketMessage(
                ticket_id=ticket.id,
                author_id=interaction.user.id,
                author_name=str(interaction.user),
                content=self.description.value
            )
            session.add(ticket_msg)
            await session.commit()
            
            log_ticket_action("CREATE", ticket.id, interaction.user.id, interaction.guild.id, f"Category: {self.category}")
            
            await interaction.followup.send(embed=success_embed("Ticket Created", f"Your ticket has been created: {ticket_channel.mention}"), ephemeral=True)
            
            if guild_config.ticket_log_channel_id:
                log_channel = interaction.guild.get_channel(guild_config.ticket_log_channel_id)
                if log_channel:
                    log_embed = ticket_embed("New Ticket Created", f"Ticket #{ticket_number:04d} created by {interaction.user.mention}")
                    log_embed.add_field(name="Category", value=self.category.title(), inline=True)
                    log_embed.add_field(name="Channel", value=ticket_channel.mention, inline=True)
                    await log_channel.send(embed=log_embed)

class TicketControlView(View):
    def __init__(self, ticket_id: int):
        super().__init__(timeout=None)
        self.ticket_id = ticket_id
    
    @discord.ui.button(label="Claim", style=discord.ButtonStyle.primary, emoji="����", custom_id="ticket_claim")
    async def claim_button(self, interaction: discord.Interaction, button: Button):
        await self.handle_claim(interaction)
    
    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, emoji="����", custom_id="ticket_close")
    async def close_button(self, interaction: discord.Interaction, button: Button):
        await self.handle_close(interaction)
    
    @discord.ui.button(label="Delete", style=discord.ButtonStyle.secondary, emoji="�������", custom_id="ticket_delete")
    async def delete_button(self, interaction: discord.Interaction, button: Button):
        await self.handle_delete(interaction)
    
    @discord.ui.button(label="Add User", style=discord.ButtonStyle.success, emoji="���", custom_id="ticket_add")
    async def add_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(AddUserModal(self.ticket_id))
    
    @discord.ui.button(label="Remove User", style=discord.ButtonStyle.secondary, emoji="���", custom_id="ticket_remove")
    async def remove_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(RemoveUserModal(self.ticket_id))
    
    @discord.ui.button(label="Rename", style=discord.ButtonStyle.secondary, emoji="������", custom_id="ticket_rename")
    async def rename_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.send_modal(RenameTicketModal(self.ticket_id))
    
    async def handle_claim(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket:
                await interaction.response.send_message(embed=error_embed("Not Found", "Ticket not found"), ephemeral=True)
                return
            
            if ticket.status == TicketStatus.CLAIMED:
                await interaction.response.send_message(embed=error_embed("Already Claimed", f"Claimed by <@{ticket.claimant_id}>"), ephemeral=True)
                return
            
            ticket.status = TicketStatus.CLAIMED
            ticket.claimant_id = interaction.user.id
            await session.commit()
            
            log_ticket_action("CLAIM", ticket.id, interaction.user.id, interaction.guild.id)
            
            embed = interaction.message.embeds[0]
            embed.set_field_at(0, name="Status", value=f"���� Claimed by {interaction.user.mention}", inline=True)
            await interaction.message.edit(embed=embed)
            await interaction.response.send_message(embed=success_embed("Claimed", "You have claimed this ticket"), ephemeral=True)
    
    async def handle_close(self, interaction: discord.Interaction):
        if not is_staff(interaction.user) and interaction.user.id != interaction.message.embeds[0].fields[0].value.split("(")[-1].split(")")[0] if interaction.message.embeds else False:
            async with async_session_maker() as session:
                ticket = await session.get(Ticket, self.ticket_id)
                if ticket and ticket.creator_id != interaction.user.id and not is_staff(interaction.user):
                    await interaction.response.send_message(embed=error_embed("Permission Denied", "Only staff or ticket creator can close"), ephemeral=True)
                    return
        
        await interaction.response.send_message(embed=info_embed("Closing Ticket", f"Ticket will close in {settings.TICKET_CLOSE_DELAY}s. Use Delete button to remove immediately."), ephemeral=True)
        await asyncio.sleep(settings.TICKET_CLOSE_DELAY)
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket or ticket.status == TicketStatus.CLOSED:
                return
            
            ticket.status = TicketStatus.CLOSED
            ticket.closed_at = datetime.now(timezone.utc)
            await session.commit()
            
            log_ticket_action("CLOSE", ticket.id, interaction.user.id, interaction.guild.id)
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            if channel:
                overwrites = channel.overwrites
                for target, perm in overwrites.items():
                    if isinstance(target, discord.Member) or (isinstance(target, discord.Role) and target.id not in settings.STAFF_ROLE_IDS):
                        perm.update(view_channel=False)
                        await channel.set_permissions(target, overwrite=perm)
                
                embed = ticket_embed("Ticket Closed", f"This ticket has been closed by {interaction.user.mention}")
                view = TicketClosedView(ticket.id)
                await channel.send(embed=embed, view=view)
    
    async def handle_delete(self, interaction: discord.Interaction):
        if not is_staff(interaction.user):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        await interaction.response.send_modal(DeleteConfirmModal(self.ticket_id))

class TicketClosedView(View):
    def __init__(self, ticket_id: int):
        super().__init__(timeout=None)
        self.ticket_id = ticket_id
    
    @discord.ui.button(label="Reopen", style=discord.ButtonStyle.success, emoji="����", custom_id="ticket_reopen")
    async def reopen_button(self, interaction: discord.Interaction, button: Button):
        if not is_staff(interaction.user):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket or ticket.status != TicketStatus.CLOSED:
                await interaction.response.send_message(embed=error_embed("Error", "Ticket not closed"), ephemeral=True)
                return
            
            ticket.status = TicketStatus.OPEN
            ticket.closed_at = None
            await session.commit()
            
            log_ticket_action("REOPEN", ticket.id, interaction.user.id, interaction.guild.id)
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            if channel:
                await channel.set_permissions(interaction.guild.default_role, view_channel=False)
                creator = channel.guild.get_member(ticket.creator_id)
                if creator:
                    await channel.set_permissions(creator, view_channel=True, send_messages=True)
                for role_id in settings.STAFF_ROLE_IDS:
                    role = channel.guild.get_role(role_id)
                    if role:
                        await channel.set_permissions(role, view_channel=True, send_messages=True)
                
                embed = ticket_embed("Ticket Reopened", f"Ticket reopened by {interaction.user.mention}")
                view = TicketControlView(ticket.id)
                await channel.send(embed=embed, view=view)
            
            await interaction.response.send_message(embed=success_embed("Reopened", "Ticket has been reopened"), ephemeral=True)
    
    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="�������", custom_id="ticket_delete_final")
    async def delete_button(self, interaction: discord.Interaction, button: Button):
        if not is_staff(interaction.user):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        await interaction.response.send_modal(DeleteConfirmModal(self.ticket_id))

class DeleteConfirmModal(Modal, title="Confirm Deletion"):
    def __init__(self, ticket_id: int):
        super().__init__(custom_id=f"ticket_delete_confirm_{ticket_id}")
        self.ticket_id = ticket_id
        self.confirm = TextInput(label="Type DELETE to confirm", placeholder="DELETE", required=True, max_length=6)
        self.add_item(self.confirm)
    
    async def on_submit(self, interaction: discord.Interaction):
        if self.confirm.value != "DELETE":
            await interaction.response.send_message(embed=error_embed("Cancelled", "Deletion cancelled"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket:
                await interaction.followup.send(embed=error_embed("Not Found", "Ticket not found"), ephemeral=True)
                return
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            
            if settings.TICKET_TRANSCRIPT_CHANNEL_ID:
                transcript_channel = interaction.guild.get_channel(settings.TICKET_TRANSCRIPT_CHANNEL_ID)
                if transcript_channel:
                    messages = await session.execute(
                        select(TicketMessage).where(TicketMessage.ticket_id == ticket.id).order_by(TicketMessage.created_at)
                    )
                    messages = messages.scalars().all()
                    
                    transcript = f"Ticket #{ticket.ticket_number:04d} Transcript\n"
                    transcript += f"Subject: {ticket.subject}\n"
                    transcript += f"Category: {ticket.category.value}\n"
                    transcript += f"Creator: {ticket.creator_id}\n"
                    transcript += f"Status: {ticket.status.value}\n"
                    transcript += "=" * 50 + "\n\n"
                    
                    for msg in messages:
                        transcript += f"[{msg.created_at.strftime('%Y-%m-%d %H:%M:%S')}] {msg.author_name}: {msg.content}\n\n"
                    
                    file = discord.File(
                        fp=bytes(transcript, 'utf-8'),
                        filename=f"ticket-{ticket.ticket_number:04d}-transcript.txt"
                    )
                    embed = ticket_embed("Ticket Transcript", f"Ticket #{ticket.ticket_number:04d} deleted by {interaction.user.mention}")
                    await transcript_channel.send(embed=embed, file=file)
            
            ticket.status = TicketStatus.DELETED
            ticket.deleted_at = datetime.now(timezone.utc)
            await session.commit()
            
            log_ticket_action("DELETE", ticket.id, interaction.user.id, interaction.guild.id)
            
            if channel:
                await channel.delete(reason=f"Ticket deleted by {interaction.user}")
            
            await interaction.followup.send(embed=success_embed("Deleted", "Ticket has been deleted"), ephemeral=True)

class AddUserModal(Modal, title="Add User to Ticket"):
    def __init__(self, ticket_id: int):
        super().__init__(custom_id=f"ticket_add_user_{ticket_id}")
        self.ticket_id = ticket_id
        self.user_input = TextInput(label="User ID or Mention", placeholder="123456789 or @user", required=True, max_length=100)
        self.add_item(self.user_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        user_id = self.user_input.value.strip()
        if user_id.startswith("<@") and user_id.endswith(">"):
            user_id = user_id[2:-1].replace("!", "")
        
        try:
            user_id = int(user_id)
            user = interaction.guild.get_member(user_id)
        except ValueError:
            await interaction.followup.send(embed=error_embed("Invalid User", "Provide a valid user ID or mention"), ephemeral=True)
            return
        
        if not user:
            await interaction.followup.send(embed=error_embed("User Not Found", "User not in this server"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket:
                await interaction.followup.send(embed=error_embed("Not Found", "Ticket not found"), ephemeral=True)
                return
            
            existing = await session.execute(
                select(TicketParticipant).where(
                    TicketParticipant.ticket_id == ticket.id,
                    TicketParticipant.user_id == user.id
                )
            )
            if existing.scalar_one_or_none():
                await interaction.followup.send(embed=error_embed("Already Added", "User already has access"), ephemeral=True)
                return
            
            participant = TicketParticipant(
                ticket_id=ticket.id,
                user_id=user.id,
                user_name=str(user),
                added_by=interaction.user.id
            )
            session.add(participant)
            await session.commit()
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            if channel:
                await channel.set_permissions(user, view_channel=True, send_messages=True)
            
            log_ticket_action("ADD_USER", ticket.id, interaction.user.id, interaction.guild.id, f"Added {user.id}")
            
            await interaction.followup.send(embed=success_embed("User Added", f"{user.mention} has been added to the ticket"), ephemeral=True)

class RemoveUserModal(Modal, title="Remove User from Ticket"):
    def __init__(self, ticket_id: int):
        super().__init__(custom_id=f"ticket_remove_user_{ticket_id}")
        self.ticket_id = ticket_id
        self.user_input = TextInput(label="User ID or Mention", placeholder="123456789 or @user", required=True, max_length=100)
        self.add_item(self.user_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        user_id = self.user_input.value.strip()
        if user_id.startswith("<@") and user_id.endswith(">"):
            user_id = user_id[2:-1].replace("!", "")
        
        try:
            user_id = int(user_id)
            user = interaction.guild.get_member(user_id)
        except ValueError:
            await interaction.followup.send(embed=error_embed("Invalid User", "Provide a valid user ID or mention"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket:
                await interaction.followup.send(embed=error_embed("Not Found", "Ticket not found"), ephemeral=True)
                return
            
            if user_id == ticket.creator_id:
                await interaction.followup.send(embed=error_embed("Cannot Remove", "Cannot remove ticket creator"), ephemeral=True)
                return
            
            participant = await session.execute(
                select(TicketParticipant).where(
                    TicketParticipant.ticket_id == ticket.id,
                    TicketParticipant.user_id == user_id
                )
            )
            participant = participant.scalar_one_or_none()
            if not participant:
                await interaction.followup.send(embed=error_embed("Not a Participant", "User doesn't have access"), ephemeral=True)
                return
            
            await session.delete(participant)
            await session.commit()
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            if channel and user:
                await channel.set_permissions(user, overwrite=None)
            
            log_ticket_action("REMOVE_USER", ticket.id, interaction.user.id, interaction.guild.id, f"Removed {user_id}")
            
            await interaction.followup.send(embed=success_embed("User Removed", f"{user.mention if user else 'User'} has been removed from the ticket"), ephemeral=True)

class RenameTicketModal(Modal, title="Rename Ticket"):
    def __init__(self, ticket_id: int):
        super().__init__(custom_id=f"ticket_rename_{ticket_id}")
        self.ticket_id = ticket_id
        self.new_name = TextInput(label="New Name", placeholder="New ticket name (max 100 chars)", required=True, max_length=100)
        self.add_item(self.new_name)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not validate_ticket_subject(self.new_name.value):
            await interaction.response.send_message(embed=error_embed("Invalid Name", "Name must be 1-100 characters"), ephemeral=True)
            return
        
        await interaction.response.defer(ephemeral=True)
        
        async with async_session_maker() as session:
            ticket = await session.get(Ticket, self.ticket_id)
            if not ticket:
                await interaction.followup.send(embed=error_embed("Not Found", "Ticket not found"), ephemeral=True)
                return
            
            channel = interaction.guild.get_channel(ticket.channel_id)
            if channel:
                await channel.edit(name=f"ticket-{ticket.ticket_number:04d}-{self.new_name.value[:50]}")
            
            ticket.subject = self.new_name.value
            await session.commit()
            
            log_ticket_action("RENAME", ticket.id, interaction.user.id, interaction.guild.id, f"New name: {self.new_name.value}")
            
            await interaction.followup.send(embed=success_embed("Renamed", f"Ticket renamed to: {self.new_name.value}"), ephemeral=True)

class TicketPanelView(View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketCategorySelect())

class TicketsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="ticket", description="Open the ticket panel")
    @commands.guild_only()
    async def ticket(self, ctx: commands.Context):
        embed = ticket_embed(
            "GTX Support Tickets",
            "Select a category below to create a new ticket.\n\n"
            "**Categories:**\n"
            "��� General Support - General questions\n"
            "���� Technical Support - Technical issues\n"
            "������� VPS Issues - VPS-related problems\n"
            "���� Minecraft Server - Minecraft server issues\n"
            "���� Billing - Billing and payments\n"
            "������ Abuse Report - Report violations\n"
            "���� Other - Other inquiries"
        )
        embed.set_footer(text="GTX Bot v1 • Premium Hosting")
        view = TicketPanelView()
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="ticket-setup", description="Setup ticket system (Admin)")
    @commands.guild_only()
    async def ticket_setup(self, ctx: commands.Context, category: discord.CategoryChannel, log_channel: discord.TextChannel = None, transcript_channel: discord.TextChannel = None):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == ctx.guild.id))
            config = config.scalar_one_or_none()
            if not config:
                config = GuildConfig(guild_id=ctx.guild.id)
                session.add(config)
            
            config.ticket_category_id = category.id
            if log_channel:
                config.ticket_log_channel_id = log_channel.id
            if transcript_channel:
                config.transcript_channel_id = transcript_channel.id
            
            await session.commit()
        
        embed = success_embed("Ticket System Configured", f"Category: {category.mention}")
        if log_channel:
            embed.add_field(name="Log Channel", value=log_channel.mention, inline=True)
        if transcript_channel:
            embed.add_field(name="Transcript Channel", value=transcript_channel.mention, inline=True)
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="ticket-stats", description="View ticket statistics")
    @commands.guild_only()
    async def ticket_stats(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            total = await session.execute(select(func.count(Ticket.id)).where(Ticket.guild_id == ctx.guild.id))
            open_tickets = await session.execute(select(func.count(Ticket.id)).where(Ticket.guild_id == ctx.guild.id, Ticket.status == TicketStatus.OPEN))
            claimed = await session.execute(select(func.count(Ticket.id)).where(Ticket.guild_id == ctx.guild.id, Ticket.status == TicketStatus.CLAIMED))
            closed = await session.execute(select(func.count(Ticket.id)).where(Ticket.guild_id == ctx.guild.id, Ticket.status == TicketStatus.CLOSED))
            deleted = await session.execute(select(func.count(Ticket.id)).where(Ticket.guild_id == ctx.guild.id, Ticket.status == TicketStatus.DELETED))
            
            by_category = await session.execute(
                select(Ticket.category, func.count(Ticket.id))
                .where(Ticket.guild_id == ctx.guild.id)
                .group_by(Ticket.category)
            )
        
        embed = ticket_embed("Ticket Statistics", f"Statistics for {ctx.guild.name}")
        embed.add_field(name="Total", value=str(total.scalar()), inline=True)
        embed.add_field(name="���� Open", value=str(open_tickets.scalar()), inline=True)
        embed.add_field(name="���� Claimed", value=str(claimed.scalar()), inline=True)
        embed.add_field(name="���� Closed", value=str(closed.scalar()), inline=True)
        embed.add_field(name="������� Deleted", value=str(deleted.scalar()), inline=True)
        
        cat_text = "\n".join(f"{cat.value.title()}: {count}" for cat, count in by_category.all())
        if cat_text:
            embed.add_field(name="By Category", value=cat_text, inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="my-tickets", description="View your tickets")
    @commands.guild_only()
    async def my_tickets(self, ctx: commands.Context):
        async with async_session_maker() as session:
            tickets = await session.execute(
                select(Ticket)
                .where(Ticket.guild_id == ctx.guild.id, Ticket.creator_id == ctx.author.id)
                .order_by(desc(Ticket.created_at))
                .limit(10)
            )
            tickets = tickets.scalars().all()
        
        if not tickets:
            await ctx.send(embed=info_embed("No Tickets", "You haven't created any tickets"), ephemeral=True)
            return
        
        embed = ticket_embed("Your Tickets", f"Showing {len(tickets)} most recent tickets")
        for ticket in tickets:
            status_emoji = {"open": "����", "claimed": "����", "closed": "����", "deleted": "�������"}.get(ticket.status.value, "���")
            channel = ctx.guild.get_channel(ticket.channel_id)
            embed.add_field(
                name=f"#{ticket.ticket_number:04d} {status_emoji} {ticket.subject}",
                value=f"Category: {ticket.category.value.title()} | Status: {ticket.status.value.title()} | {channel.mention if channel else 'Channel deleted'}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):
    bot.add_view(TicketPanelView())
    bot.add_view(TicketControlView(0))
    bot.add_view(TicketClosedView(0))
    await bot.add_cog(TicketsCog(bot))