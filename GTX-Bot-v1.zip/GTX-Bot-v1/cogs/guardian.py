import discord
from discord.ext import commands, tasks
from discord import app_commands
from typing import Optional, List, Dict
import asyncio
from datetime import datetime, timezone, timedelta
from collections import defaultdict

from utils import (
    error_embed, success_embed, info_embed, warning_embed,
    has_permission, is_staff, is_admin, PermissionLevel,
    log_security_event, log_guild_action, get_logger,
    validate_discord_id
)
from database import async_session_maker, User, GuardianLog, GuildConfig
from config import settings
from sqlalchemy import select, func, and_, desc

logger = get_logger("guardian")

class GuardianCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.join_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.message_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.mention_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.channel_delete_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.role_delete_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.kick_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.ban_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.webhook_tracker: Dict[int, List[datetime]] = defaultdict(list)
        self.whitelist_cache: set = set()
        self.load_whitelist()
        self.cleanup_task.start()
    
    def load_whitelist(self):
        self.whitelist_cache = set(settings.OWNER_IDS)
    
    def is_whitelisted(self, user_id: int) -> bool:
        return user_id in self.whitelist_cache or user_id in settings.OWNER_IDS
    
    def cog_unload(self):
        self.cleanup_task.cancel()
    
    @tasks.loop(minutes=5)
    async def cleanup_task(self):
        now = datetime.now(timezone.utc)
        for tracker in [self.join_tracker, self.message_tracker, self.mention_tracker,
                       self.channel_delete_tracker, self.role_delete_tracker,
                       self.kick_tracker, self.ban_tracker, self.webhook_tracker]:
            for guild_id in list(tracker.keys()):
                tracker[guild_id] = [t for t in tracker[guild_id] if (now - t).total_seconds() < 300]
                if not tracker[guild_id]:
                    del tracker[guild_id]
    
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not settings.GUARDIAN_ENABLED:
            return
        if self.is_whitelisted(member.id):
            return
        
        if not await self.check_guild_config(member.guild.id, "anti_raid_enabled"):
            return
        
        now = datetime.now(timezone.utc)
        self.join_tracker[member.guild.id].append(now)
        
        recent_joins = len([t for t in self.join_tracker[member.guild.id] 
                           if (now - t).total_seconds() <= settings.ANTI_RAID_WINDOW])
        
        if recent_joins >= settings.ANTI_RAID_THRESHOLD:
            await self.trigger_anti_raid(member.guild, recent_joins)
    
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not settings.GUARDIAN_ENABLED:
            return
        if not message.guild:
            return
        if message.author.bot:
            return
        if self.is_whitelisted(message.author.id):
            return
        if await self.has_staff_perms(message.author):
            return
        
        if not await self.check_guild_config(message.guild.id, "anti_spam_enabled"):
            return
        
        now = datetime.now(timezone.utc)
        self.message_tracker[message.author.id].append(now)
        
        recent_messages = len([t for t in self.message_tracker[message.author.id] 
                              if (now - t).total_seconds() <= settings.ANTI_SPAM_WINDOW])
        
        if recent_messages >= settings.ANTI_SPAM_THRESHOLD:
            await self.trigger_anti_spam(message, recent_messages)
        
        mentions = len(message.mentions) + len(message.role_mentions)
        if mentions > 0:
            self.mention_tracker[message.author.id].append(now)
            recent_mentions = len([t for t in self.mention_tracker[message.author.id] 
                                  if (now - t).total_seconds() <= settings.ANTI_SPAM_WINDOW])
            
            if recent_mentions * mentions >= settings.ANTI_MENTION_LIMIT:
                await self.trigger_anti_mention(message, mentions)
    
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(guild.id, "anti_nuke_enabled"):
            return
        
        async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1):
            if entry.target.id == user.id:
                if self.is_whitelisted(entry.user.id):
                    return
                if await self.has_staff_perms(entry.user):
                    return
                
                now = datetime.now(timezone.utc)
                self.ban_tracker[guild.id].append(now)
                
                recent_bans = len([t for t in self.ban_tracker[guild.id] 
                                  if (now - t).total_seconds() <= 10])
                
                if recent_bans >= 3:
                    await self.trigger_anti_nuke(guild, entry.user, "mass_ban")
                return
    
    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(member.guild.id, "anti_nuke_enabled"):
            return
        
        await asyncio.sleep(1)
        
        async for entry in member.guild.audit_logs(action=discord.AuditLogAction.kick, limit=1):
            if entry.target.id == member.id:
                if self.is_whitelisted(entry.user.id):
                    return
                if await self.has_staff_perms(entry.user):
                    return
                
                now = datetime.now(timezone.utc)
                self.kick_tracker[member.guild.id].append(now)
                
                recent_kicks = len([t for t in self.kick_tracker[member.guild.id] 
                                   if (now - t).total_seconds() <= 10])
                
                if recent_kicks >= 3:
                    await self.trigger_anti_nuke(member.guild, entry.user, "mass_kick")
                return
    
    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(channel.guild.id, "anti_nuke_enabled"):
            return
        
        await asyncio.sleep(1)
        
        async for entry in channel.guild.audit_logs(action=discord.AuditLogAction.channel_delete, limit=1):
            if self.is_whitelisted(entry.user.id):
                return
            if await self.has_staff_perms(entry.user):
                return
            
            now = datetime.now(timezone.utc)
            self.channel_delete_tracker[channel.guild.id].append(now)
            
            recent_deletes = len([t for t in self.channel_delete_tracker[channel.guild.id] 
                                 if (now - t).total_seconds() <= 10])
            
            if recent_deletes >= 3:
                await self.trigger_anti_nuke(channel.guild, entry.user, "mass_channel_delete")
            return
    
    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(role.guild.id, "anti_nuke_enabled"):
            return
        
        await asyncio.sleep(1)
        
        async for entry in role.guild.audit_logs(action=discord.AuditLogAction.role_delete, limit=1):
            if self.is_whitelisted(entry.user.id):
                return
            if await self.has_staff_perms(entry.user):
                return
            
            now = datetime.now(timezone.utc)
            self.role_delete_tracker[role.guild.id].append(now)
            
            recent_deletes = len([t for t in self.role_delete_tracker[role.guild.id] 
                                 if (now - t).total_seconds() <= 10])
            
            if recent_deletes >= 3:
                await self.trigger_anti_nuke(role.guild, entry.user, "mass_role_delete")
            return
    
    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.abc.GuildChannel):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(channel.guild.id, "anti_webhook_enabled"):
            return
        
        await asyncio.sleep(1)
        
        async for entry in channel.guild.audit_logs(action=discord.AuditLogAction.webhook_create, limit=1):
            if self.is_whitelisted(entry.user.id):
                return
            if await self.has_staff_perms(entry.user):
                return
            
            now = datetime.now(timezone.utc)
            self.webhook_tracker[channel.guild.id].append(now)
            
            recent_webhooks = len([t for t in self.webhook_tracker[channel.guild.id] 
                                  if (now - t).total_seconds() <= 10])
            
            if recent_webhooks >= 3:
                await self.trigger_anti_nuke(channel.guild, entry.user, "mass_webhook_create")
            return
    
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        if not settings.GUARDIAN_ENABLED:
            return
        if not await self.check_guild_config(after.guild.id, "anti_bot_enabled"):
            return
        
        if before.pending and not after.pending:
            if after.bot and not self.is_whitelisted(after.id):
                try:
                    await after.kick(reason="Guardian: Unauthorized bot join")
                    log_security_event("BOT_KICK", after.guild.id, after.id, "Unauthorized bot join")
                except Exception:
                    pass
    
    async def check_guild_config(self, guild_id: int, setting: str) -> bool:
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == guild_id))
            config = config.scalar_one_or_none()
            return config and getattr(config, setting, True) if config else True
    
    async def has_staff_perms(self, member: discord.Member) -> bool:
        return is_staff(member) or member.guild_permissions.administrator
    
    async def trigger_anti_raid(self, guild: discord.Guild, count: int):
        log_security_event("ANTI_RAID_TRIGGERED", guild.id, self.bot.user.id, 
                          f"{count} joins in {settings.ANTI_RAID_WINDOW}s", "LOCKDOWN")
        
        try:
            await guild.edit(verification_level=discord.VerificationLevel.highest)
        except Exception:
            pass
        
        for channel in guild.text_channels:
            try:
                await channel.set_permissions(guild.default_role, send_messages=False)
            except Exception:
                pass
        
        log_channel_id = await self.get_log_channel(guild.id)
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                embed = warning_embed("������� Anti-Raid Triggered", 
                    f"**{count} joins** detected in **{settings.ANTI_RAID_WINDOW}s**\n"
                    f"Server locked down. Verification level set to highest.")
                await log_channel.send(embed=embed)
    
    async def trigger_anti_spam(self, message: discord.Message, count: int):
        try:
            await message.delete()
        except Exception:
            pass
        
        try:
            await message.author.timeout(timedelta(minutes=10), reason="Guardian: Spam detected")
        except Exception:
            pass
        
        log_security_event("ANTI_SPAM", message.guild.id, message.author.id,
                          f"{count} messages in {settings.ANTI_SPAM_WINDOW}s", "TIMEOUT_10M")
        
        log_channel_id = await self.get_log_channel(message.guild.id)
        if log_channel_id:
            log_channel = message.guild.get_channel(log_channel_id)
            if log_channel:
                embed = warning_embed("������� Anti-Spam", 
                    f"{message.author.mention} timed out for spam\n"
                    f"**{count} messages** in **{settings.ANTI_SPAM_WINDOW}s**")
                await log_channel.send(embed=embed)
    
    async def trigger_anti_mention(self, message: discord.Message, mentions: int):
        try:
            await message.delete()
        except Exception:
            pass
        
        try:
            await message.author.timeout(timedelta(minutes=5), reason="Guardian: Mention spam")
        except Exception:
            pass
        
        log_security_event("ANTI_MENTION_SPAM", message.guild.id, message.author.id,
                          f"{mentions} mentions in one message", "TIMEOUT_5M")
    
    async def trigger_anti_nuke(self, guild: discord.Guild, actor: discord.User, action: str):
        log_security_event(f"ANTI_NUKE_{action.upper()}", guild.id, actor.id,
                          f"Mass {action.replace('_', ' ')} detected", "STRIP_PERMS")
        
        try:
            member = guild.get_member(actor.id)
            if member:
                for role in member.roles[1:]:
                    if not role.managed:
                        await member.remove_roles(role, reason=f"Guardian: Anti-nuke ({action})")
        except Exception:
            pass
        
        try:
            await guild.edit(verification_level=discord.VerificationLevel.highest)
        except Exception:
            pass
        
        log_channel_id = await self.get_log_channel(guild.id)
        if log_channel_id:
            log_channel = guild.get_channel(log_channel_id)
            if log_channel:
                embed = error_embed("������� Anti-Nuke Triggered",
                    f"{actor.mention} attempted **{action.replace('_', ' ')}**\n"
                    f"Permissions stripped. Server locked down.")
                await log_channel.send(embed=embed)
    
    async def get_log_channel(self, guild_id: int) -> Optional[int]:
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == guild_id))
            config = config.scalar_one_or_none()
            return config.guardian_log_channel_id if config else None
    
    async def log_action(self, guild_id: int, action: str, target_id: int = None, 
                        target_name: str = None, moderator_id: int = None, 
                        moderator_name: str = None, reason: str = None, 
                        punishment: str = None, details: str = None):
        async with async_session_maker() as session:
            log = GuardianLog(
                guild_id=guild_id,
                action=action,
                target_id=target_id,
                target_name=target_name,
                moderator_id=moderator_id,
                moderator_name=moderator_name,
                reason=reason,
                details=details,
                punishment=punishment
            )
            session.add(log)
            await session.commit()
    
    @commands.hybrid_command(name="guardian", description="Guardian security dashboard")
    @commands.guild_only()
    async def guardian(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == ctx.guild.id))
            config = config.scalar_one_or_none()
            
            recent_logs = await session.execute(
                select(GuardianLog)
                .where(GuardianLog.guild_id == ctx.guild.id)
                .order_by(desc(GuardianLog.created_at))
                .limit(10)
            )
            recent_logs = recent_logs.scalars().all()
        
        embed = info_embed("������� Guardian Security", f"Security status for {ctx.guild.name}")
        
        if config:
            embed.add_field(name="Anti-Raid", value="����" if config.anti_raid_enabled else "����", inline=True)
            embed.add_field(name="Anti-Spam", value="����" if config.anti_spam_enabled else "����", inline=True)
            embed.add_field(name="Anti-Bot", value="����" if config.anti_bot_enabled else "����", inline=True)
            embed.add_field(name="Anti-Webhook", value="����" if config.anti_webhook_enabled else "����", inline=True)
            embed.add_field(name="Anti-Nuke", value="����" if config.anti_nuke_enabled else "����", inline=True)
        
        if recent_logs:
            logs_text = "\n".join(
                f"`{log.created_at.strftime('%H:%M:%S')}` {log.action} - "
                f"{f'<@{log.target_id}>' if log.target_id else 'N/A'} "
                f"({'By ' + log.moderator_name if log.moderator_name else 'Auto'})"
                for log in recent_logs
            )
            embed.add_field(name="Recent Actions", value=logs_text[:1024], inline=False)
        
        view = GuardianConfigView(ctx.guild.id)
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="whitelist", description="Manage Guardian whitelist")
    @commands.guild_only()
    async def whitelist(self, ctx: commands.Context, action: str, user: discord.User = None):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        if action.lower() == "add" and user:
            self.whitelist_cache.add(user.id)
            await ctx.send(embed=success_embed("Whitelisted", f"{user.mention} added to whitelist"))
        elif action.lower() == "remove" and user:
            self.whitelist_cache.discard(user.id)
            await ctx.send(embed=success_embed("Removed", f"{user.mention} removed from whitelist"))
        elif action.lower() == "list":
            whitelisted = [f"<@{uid}>" for uid in self.whitelist_cache if uid not in settings.OWNER_IDS]
            embed = info_embed("Whitelist", "\n".join(whitelisted) if whitelisted else "No custom whitelisted users")
            await ctx.send(embed=embed, ephemeral=True)
        else:
            await ctx.send(embed=error_embed("Usage", "`!whitelist add @user`, `!whitelist remove @user`, `!whitelist list`"), ephemeral=True)
    
    @commands.hybrid_command(name="guardian-logs", description="View Guardian logs")
    @commands.guild_only()
    async def guardian_logs(self, ctx: commands.Context, limit: int = 20):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            logs = await session.execute(
                select(GuardianLog)
                .where(GuardianLog.guild_id == ctx.guild.id)
                .order_by(desc(GuardianLog.created_at))
                .limit(min(limit, 50))
            )
            logs = logs.scalars().all()
        
        if not logs:
            await ctx.send(embed=info_embed("No Logs", "No Guardian logs found"), ephemeral=True)
            return
        
        embed = info_embed("������� Guardian Logs", f"Last {len(logs)} actions")
        for log in logs:
            target = f"<@{log.target_id}>" if log.target_id else "N/A"
            moderator = log.moderator_name or "Auto"
            embed.add_field(
                name=f"{log.action} - {log.created_at.strftime('%Y-%m-%d %H:%M:%S')}",
                value=f"Target: {target}\nModerator: {moderator}\nReason: {log.reason or 'N/A'}\nPunishment: {log.punishment or 'N/A'}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)

class GuardianConfigView(discord.ui.View):
    def __init__(self, guild_id: int):
        super().__init__(timeout=300)
        self.guild_id = guild_id
    
    @discord.ui.button(label="Anti-Raid", style=discord.ButtonStyle.primary, custom_id="guardian_anti_raid")
    async def anti_raid(self, interaction: discord.Interaction, button: Button):
        await self.toggle_setting(interaction, "anti_raid_enabled", "Anti-Raid")
    
    @discord.ui.button(label="Anti-Spam", style=discord.ButtonStyle.primary, custom_id="guardian_anti_spam")
    async def anti_spam(self, interaction: discord.Interaction, button: Button):
        await self.toggle_setting(interaction, "anti_spam_enabled", "Anti-Spam")
    
    @discord.ui.button(label="Anti-Bot", style=discord.ButtonStyle.primary, custom_id="guardian_anti_bot")
    async def anti_bot(self, interaction: discord.Interaction, button: Button):
        await self.toggle_setting(interaction, "anti_bot_enabled", "Anti-Bot")
    
    @discord.ui.button(label="Anti-Webhook", style=discord.ButtonStyle.primary, custom_id="guardian_anti_webhook")
    async def anti_webhook(self, interaction: discord.Interaction, button: Button):
        await self.toggle_setting(interaction, "anti_webhook_enabled", "Anti-Webhook")
    
    @discord.ui.button(label="Anti-Nuke", style=discord.ButtonStyle.danger, custom_id="guardian_anti_nuke")
    async def anti_nuke(self, interaction: discord.Interaction, button: Button):
        await self.toggle_setting(interaction, "anti_nuke_enabled", "Anti-Nuke")
    
    async def toggle_setting(self, interaction: discord.Interaction, setting: str, name: str):
        if not has_permission(interaction.user, PermissionLevel.ADMIN):
            await interaction.response.send_message(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            config = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == self.guild_id))
            config = config.scalar_one_or_none()
            if not config:
                config = GuildConfig(guild_id=self.guild_id)
                session.add(config)
            
            current = getattr(config, setting, True)
            setattr(config, setting, not current)
            await session.commit()
            
            status = "Enabled" if not current else "Disabled"
            embed = success_embed(f"{name} {status}", f"{name} has been {status.lower()}")
            await interaction.response.edit_message(embed=embed, view=self)

async def setup(bot):
    await bot.add_cog(GuardianCog(bot))