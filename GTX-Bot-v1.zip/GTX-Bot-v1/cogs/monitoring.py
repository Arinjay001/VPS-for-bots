import discord
from discord.ext import commands, tasks
from discord import app_commands
from typing import Optional, List
import asyncio
from datetime import datetime, timezone

from utils import (
    monitoring_embed, success_embed, error_embed, info_embed,
    has_permission, PermissionLevel, format_bytes, get_logger
)
from database import async_session_maker, Node, NodeStatus
from config import settings
from sqlalchemy import select
import aiohttp

logger = get_logger("monitoring")

class MonitoringCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.refresh_task.start()
    
    def cog_unload(self):
        self.refresh_task.cancel()
    
    @tasks.loop(minutes=1)
    async def refresh_task(self):
        await self.check_node_alerts()
    
    async def check_node_alerts(self):
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).where(Node.is_active == True))
            nodes = nodes.scalars().all()
        
        for node in nodes:
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                    async with session.get(f"http://{node.host}:{node.port}/health", headers={"Authorization": f"Bearer {node.api_key}"}) as resp:
                        if resp.status != 200:
                            await self.alert_node_down(node)
                        else:
                            await self.alert_node_recovered(node)
            except Exception:
                await self.alert_node_down(node)
    
    async def alert_node_down(self, node: Node):
        pass
    
    async def alert_node_recovered(self, node: Node):
        pass
    
    @commands.hybrid_command(name="status", description="Quick status overview")
    @commands.guild_only()
    async def status(self, ctx: commands.Context):
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).where(Node.is_active == True))
            nodes = nodes.scalars().all()
        
        online = sum(1 for n in nodes if n.status == NodeStatus.ONLINE)
        offline = sum(1 for n in nodes if n.status == NodeStatus.OFFLINE)
        maintenance = sum(1 for n in nodes if n.status == NodeStatus.MAINTENANCE)
        error = sum(1 for n in nodes if n.status == NodeStatus.ERROR)
        
        total_vps = sum(n.current_vps for n in nodes)
        total_ram = sum(n.current_ram for n in nodes)
        total_cpu = sum(n.current_cpu for n in nodes)
        total_disk = sum(n.current_disk for n in nodes)
        
        embed = monitoring_embed("System Status", f"**{online} Online** | **{offline} Offline** | **{maintenance} Maintenance** | **{error} Error**")
        embed.add_field(name="Total VPS", value=str(total_vps), inline=True)
        embed.add_field(name="RAM Used", value=format_bytes(total_ram * 1024 * 1024), inline=True)
        embed.add_field(name="CPU Avg", value=f"{total_cpu/len(nodes):.1f}%" if nodes else "0%", inline=True)
        embed.add_field(name="Disk Used", value=format_bytes(total_disk * 1024 * 1024), inline=True)
        embed.add_field(name="Nodes", value=str(len(nodes)), inline=True)
        
        if nodes:
            node_list = "\n".join(f"`{n.name}`: {n.status.value} ({n.current_vps} VPS)" for n in nodes[:10])
            embed.add_field(name="Node Details", value=node_list, inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.hybrid_command(name="stats", description="Detailed statistics")
    @commands.guild_only()
    async def stats(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).order_by(Node.name))
            nodes = nodes.scalars().all()
        
        embed = monitoring_embed("Detailed Statistics", f"{len(nodes)} nodes")
        
        for node in nodes:
            ram_pct = (node.current_ram / node.max_ram * 100) if node.max_ram else 0
            cpu_pct = (node.current_cpu / node.max_cpu * 100) if node.max_cpu else 0
            disk_pct = (node.current_disk / node.max_disk * 100) if node.max_disk else 0
            
            ram_bar = self.progress_bar(ram_pct)
            cpu_bar = self.progress_bar(cpu_pct)
            disk_bar = self.progress_bar(disk_pct)
            
            status_emoji = {"online": "����", "offline": "����", "maintenance": "����", "error": "���"}.get(node.status.value, "���")
            
            embed.add_field(
                name=f"{status_emoji} {node.name} ({node.location})",
                value=f"RAM: {ram_bar} {ram_pct:.1f}%\nCPU: {cpu_bar} {cpu_pct:.1f}%\nDisk: {disk_bar} {disk_pct:.1f}%\nVPS: {node.current_vps}/{node.max_vps} | Latency: {node.latency}ms",
                inline=False
            )
        
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="monitor", description="Start live monitoring (updates every 30s)")
    @commands.guild_only()
    async def monitor(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        msg = await ctx.send(embed=info_embed("Starting Monitor", "Fetching initial data..."), ephemeral=True)
        
        for _ in range(10):
            async with async_session_maker() as session:
                nodes = await session.execute(select(Node).where(Node.is_active == True))
                nodes = nodes.scalars().all()
            
            online = sum(1 for n in nodes if n.status == NodeStatus.ONLINE)
            embed = monitoring_embed("Live Monitor", f"Auto-refreshing... ({online}/{len(nodes)} online)")
            
            for node in nodes[:15]:
                ram_pct = (node.current_ram / node.max_ram * 100) if node.max_ram else 0
                status_emoji = {"online": "����", "offline": "����", "maintenance": "����", "error": "���"}.get(node.status.value, "���")
                embed.add_field(
                    name=f"{status_emoji} {node.name}",
                    value=f"RAM: {ram_pct:.1f}% | CPU: {node.current_cpu:.1f}% | VPS: {node.current_vps} | {node.latency}ms",
                    inline=True
                )
            
            try:
                await msg.edit(embed=embed)
            except Exception:
                break
            
            await asyncio.sleep(30)
        
        await msg.edit(embed=info_embed("Monitor Stopped", "Live monitor ended after 10 updates"))
    
    def progress_bar(self, pct: float, length: int = 10) -> str:
        filled = int(pct / 100 * length)
        return "█" * filled + "��" * (length - filled)
    
    @commands.hybrid_command(name="alert-test", description="Test alert system")
    @commands.guild_only()
    async def alert_test(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        embed = monitoring_embed("Test Alert", "This is a test alert from the monitoring system")
        await ctx.send(embed=embed)

async def check_node_alerts(bot):
    pass

async def setup(bot):
    await bot.add_cog(MonitoringCog(bot))