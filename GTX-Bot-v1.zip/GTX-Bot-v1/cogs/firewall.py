import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional
import asyncio

from utils import (
    error_embed, success_embed, info_embed,
    has_permission, is_admin, PermissionLevel,
    get_logger
)
from database import async_session_maker, VPSServer, VPSStatus, Node
from config import settings
from sqlalchemy import select
import aiohttp

logger = get_logger("firewall")

class FirewallCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="fw-allow", description="Allow port/IP on VPS firewall")
    @commands.guild_only()
    async def fw_allow(self, ctx: commands.Context, vps_id: str, port: int, protocol: str = "tcp", ip: str = "0.0.0.0/0"):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        if protocol not in ["tcp", "udp"]:
            await ctx.send(embed=error_embed("Invalid Protocol", "tcp or udp"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        try:
            async with async_session_maker() as session:
                node = await session.get(Node, vps.node_id)
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"http://{node.host}:{node.port}/api/v1/firewall/allow",
                    headers={"Authorization": f"Bearer {node.api_key}"},
                    json={"vps_uuid": vps.uuid, "port": port, "protocol": protocol, "source": ip}
                ) as resp:
                    if resp.status == 200:
                        await ctx.followup.send(embed=success_embed("Rule Added", f"Allowed {port}/{protocol} from {ip}"))
                    else:
                        await ctx.followup.send(embed=error_embed("Failed", f"HTTP {resp.status}"))
        except Exception as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))
    
    @commands.hybrid_command(name="fw-deny", description="Deny port/IP on VPS firewall")
    @commands.guild_only()
    async def fw_deny(self, ctx: commands.Context, vps_id: str, port: int, protocol: str = "tcp", ip: str = "0.0.0.0/0"):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        try:
            async with async_session_maker() as session:
                node = await session.get(Node, vps.node_id)
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"http://{node.host}:{node.port}/api/v1/firewall/deny",
                    headers={"Authorization": f"Bearer {node.api_key}"},
                    json={"vps_uuid": vps.uuid, "port": port, "protocol": protocol, "source": ip}
                ) as resp:
                    if resp.status == 200:
                        await ctx.followup.send(embed=success_embed("Rule Added", f"Denied {port}/{protocol} from {ip}"))
                    else:
                        await ctx.followup.send(embed=error_embed("Failed", f"HTTP {resp.status}"))
        except Exception as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))
    
    @commands.hybrid_command(name="fw-list", description="List firewall rules for VPS")
    @commands.guild_only()
    async def fw_list(self, ctx: commands.Context, vps_id: str):
        if not has_permission(ctx.author, PermissionLevel.VPS_USER):
            await ctx.send(embed=error_embed("Permission Denied", "VPS User role required"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            vps = await session.execute(select(VPSServer).where(VPSServer.uuid.like(f"{vps_id}%")))
            vps = vps.scalar_one_or_none()
        
        if not vps or vps.owner_id != ctx.author.id:
            await ctx.send(embed=error_embed("Not Found", "VPS not found"), ephemeral=True)
            return
        
        await ctx.defer(ephemeral=True)
        
        try:
            async with async_session_maker() as session:
                node = await session.get(Node, vps.node_id)
            
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"http://{node.host}:{node.port}/api/v1/firewall/rules",
                    headers={"Authorization": f"Bearer {node.api_key}"},
                    params={"vps_uuid": vps.uuid}
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        rules = data.get("rules", [])
                        
                        embed = info_embed("Firewall Rules", f"VPS: {vps.name}")
                        for rule in rules[:20]:
                            action = "ALLOW" if rule.get("action") == "allow" else "DENY"
                            embed.add_field(
                                name=f"{action} {rule.get('port')}/{rule.get('protocol')}",
                                value=f"Source: {rule.get('source')}",
                                inline=True
                            )
                        await ctx.followup.send(embed=embed)
                    else:
                        await ctx.followup.send(embed=error_embed("Failed", f"HTTP {resp.status}"))
        except Exception as e:
            await ctx.followup.send(embed=error_embed("Error", str(e)))

async def setup(bot):
    await bot.add_cog(FirewallCog(bot))