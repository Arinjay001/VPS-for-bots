import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

from utils import (
    error_embed, success_embed, info_embed,
    has_permission, is_admin, PermissionLevel,
    get_logger, get_user_permission_level
)
from database import async_session_maker, User
from config import settings
from sqlalchemy import select, func, desc

logger = get_logger("users")

class UsersCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="profile", description="View your profile")
    @commands.guild_only()
    async def profile(self, ctx: commands.Context, user: discord.User = None):
        user = user or ctx.author
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
            
            vps_count = await session.execute(select(func.count()).where(User.discord_id == user.id))
        
        if not db_user:
            await ctx.send(embed=info_embed("No Profile", "User not in database yet"), ephemeral=True)
            return
        
        embed = info_embed(f"Profile: {user}", f"Discord ID: {user.id}")
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.add_field(name="Username", value=user.name, inline=True)
        embed.add_field(name="Total VPS", value=str(db_user.total_vps), inline=True)
        embed.add_field(name="Total Tickets", value=str(db_user.total_tickets), inline=True)
        embed.add_field(name="Premium", value="Yes" if db_user.is_premium else "No", inline=True)
        embed.add_field(name="Banned", value="Yes" if db_user.is_banned else "No", inline=True)
        if db_user.ban_reason:
            embed.add_field(name="Ban Reason", value=db_user.ban_reason, inline=False)
        embed.add_field(name="Joined", value=db_user.created_at.strftime("%Y-%m-%d"), inline=True)
        
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="userinfo", description="View user info (Staff)")
    @commands.guild_only()
    async def userinfo(self, ctx: commands.Context, user: discord.User):
        if not has_permission(ctx.author, PermissionLevel.STAFF):
            await ctx.send(embed=error_embed("Permission Denied", "Staff only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
        
        if not db_user:
            await ctx.send(embed=info_embed("Not Found", "User not in database"), ephemeral=True)
            return
        
        perm_level = get_user_permission_level(ctx.guild.get_member(user.id)) if ctx.guild.get_member(user.id) else PermissionLevel.USER
        
        embed = info_embed(f"User Info: {user}", f"Discord ID: {user.id}")
        embed.add_field(name="Permission Level", value=perm_level.name, inline=True)
        embed.add_field(name="Total VPS", value=str(db_user.total_vps), inline=True)
        embed.add_field(name="Total Tickets", value=str(db_user.total_tickets), inline=True)
        embed.add_field(name="Premium", value="Yes" if db_user.is_premium else "No", inline=True)
        embed.add_field(name="Staff", value="Yes" if db_user.is_staff else "No", inline=True)
        embed.add_field(name="Admin", value="Yes" if db_user.is_admin else "No", inline=True)
        embed.add_field(name="Banned", value="Yes" if db_user.is_banned else "No", inline=True)
        if db_user.ban_reason:
            embed.add_field(name="Ban Reason", value=db_user.ban_reason, inline=False)
        embed.add_field(name="Created", value=db_user.created_at.strftime("%Y-%m-%d %H:%M"), inline=True)
        
        await ctx.send(embed=embed, ephemeral=True)
    
    @commands.hybrid_command(name="ban-user", description="Ban a user (Admin)")
    @commands.guild_only()
    async def ban_user(self, ctx: commands.Context, user: discord.User, reason: str = "No reason provided"):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
            if not db_user:
                db_user = User(discord_id=user.id, username=str(user))
                session.add(db_user)
            
            db_user.is_banned = True
            db_user.ban_reason = reason
            await session.commit()
        
        await ctx.send(embed=success_embed("User Banned", f"{user.mention} has been banned\nReason: {reason}"))
    
    @commands.hybrid_command(name="unban-user", description="Unban a user (Admin)")
    @commands.guild_only()
    async def unban_user(self, ctx: commands.Context, user: discord.User):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
            if db_user:
                db_user.is_banned = False
                db_user.ban_reason = None
                await session.commit()
        
        await ctx.send(embed=success_embed("User Unbanned", f"{user.mention} has been unbanned"))
    
    @commands.hybrid_command(name="add-premium", description="Add premium to user (Admin)")
    @commands.guild_only()
    async def add_premium(self, ctx: commands.Context, user: discord.User):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
            if not db_user:
                db_user = User(discord_id=user.id, username=str(user))
                session.add(db_user)
            
            db_user.is_premium = True
            await session.commit()
        
        await ctx.send(embed=success_embed("Premium Added", f"{user.mention} now has premium"))
    
    @commands.hybrid_command(name="remove-premium", description="Remove premium from user (Admin)")
    @commands.guild_only()
    async def remove_premium(self, ctx: commands.Context, user: discord.User):
        if not is_admin(ctx.author):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            db_user = await session.execute(select(User).where(User.discord_id == user.id))
            db_user = db_user.scalar_one_or_none()
            if db_user:
                db_user.is_premium = False
                await session.commit()
        
        await ctx.send(embed=success_embed("Premium Removed", f"{user.mention} no longer has premium"))

async def setup(bot):
    await bot.add_cog(UsersCog(bot))