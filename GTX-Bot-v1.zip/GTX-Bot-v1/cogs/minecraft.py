import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Select, Modal, TextInput
from typing import Optional, List
import asyncio

from utils import (
    minecraft_embed, success_embed, error_embed, info_embed,
    has_permission, PermissionLevel, get_logger,
    get_pterodactyl_api, find_minecraft_egg, MC_EGG_CONFIGS,
    log_pterodactyl_action
)
from database import async_session_maker, Node, User, MinecraftServer
from config import settings
from sqlalchemy import select, func
from utils.ptero_api import PterodactylAPIError

logger = get_logger("minecraft")

class MCCreateWizard(View):
    def __init__(self, author_id: int):
        super().__init__(timeout=300)
        self.author_id = author_id
        self.data = {}
        self.step = 0
    
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("Not your wizard", ephemeral=True)
            return False
        return True
    
    @discord.ui.select(placeholder="Select Node", custom_id="mc_node_select")
    async def node_select(self, interaction: discord.Interaction, select: Select):
        self.data['node_id'] = int(select.values[0])
        await self.show_software_select(interaction)
    
    async def show_software_select(self, interaction: discord.Interaction):
        options = [
            discord.SelectOption(label="Paper", value="paper", description="High performance PaperMC", emoji="����"),
            discord.SelectOption(label="Purpur", value="purpur", description="Optimized Paper fork", emoji="����"),
            discord.SelectOption(label="Fabric", value="fabric", description="Lightweight modding platform", emoji="����"),
            discord.SelectOption(label="Forge", value="forge", description="Classic modding platform", emoji="����"),
            discord.SelectOption(label="NeoForge", value="neoforge", description="Modern Forge fork", emoji="����"),
            discord.SelectOption(label="Spigot", value="spigot", description="Classic Spigot", emoji="����"),
            discord.SelectOption(label="Vanilla", value="vanilla", description="Official Mojang server", emoji="����"),
        ]
        select = Select(placeholder="Select Software", options=options, custom_id="mc_software_select")
        
        async def callback(interaction: discord.Interaction):
            self.data['software'] = select.values[0]
            await self.show_version_select(interaction)
        
        select.callback = callback
        view = View()
        view.add_item(select)
        await interaction.response.send_message(embed=info_embed("Select Software", "Choose Minecraft server software"), view=view, ephemeral=True)
    
    async def show_version_select(self, interaction: discord.Interaction):
        versions = {
            "paper": ["1.21.4", "1.21.3", "1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2", "1.16.5"],
            "purpur": ["1.21.4", "1.21.3", "1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2"],
            "fabric": ["1.21.4", "1.21.3", "1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2"],
            "forge": ["1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2", "1.16.5"],
            "neoforge": ["1.21.1", "1.20.6", "1.20.4", "1.19.4"],
            "spigot": ["1.21.4", "1.20.6", "1.19.4", "1.18.2", "1.16.5", "1.12.2"],
            "vanilla": ["1.21.4", "1.21.3", "1.21.1", "1.20.6", "1.20.4", "1.19.4", "1.18.2", "1.16.5"],
        }
        opts = [discord.SelectOption(label=v, value=v) for v in versions.get(self.data['software'], ["1.21.4"])]
        select = Select(placeholder="Select Version", options=opts, custom_id="mc_version_select")
        
        async def callback(interaction: discord.Interaction):
            self.data['version'] = select.values[0]
            await self.show_name_modal(interaction)
        
        select.callback = callback
        view = View()
        view.add_item(select)
        await interaction.response.send_message(embed=info_embed("Select Version", "Choose Minecraft version"), view=view, ephemeral=True)
    
    async def show_name_modal(self, interaction: discord.Interaction):
        await interaction.response.send_modal(MCNameModal(self))

class MCNameModal(Modal, title="Server Details"):
    def __init__(self, wizard: MCCreateWizard):
        super().__init__()
        self.wizard = wizard
        self.name = TextInput(label="Server Name", placeholder="My MC Server", required=True, max_length=64)
        self.add_item(self.name)
    
    async def on_submit(self, interaction: discord.Interaction):
        self.wizard.data['name'] = self.name.value
        await self.confirm(interaction)
    
    async def confirm(self, interaction: discord.Interaction):
        d = self.wizard.data
        embed = minecraft_embed("Confirm Server Creation", "Review configuration:")
        embed.add_field(name="Name", value=d['name'], inline=True)
        embed.add_field(name="Software", value=d['software'].title(), inline=True)
        embed.add_field(name="Version", value=d['version'], inline=True)
        
        async with async_session_maker() as session:
            node = await session.get(Node, d['node_id'])
            embed.add_field(name="Node", value=node.name if node else "Unknown", inline=True)
        
        view = ConfirmMCView(self.wizard)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

class ConfirmMCView(View):
    def __init__(self, wizard: MCCreateWizard):
        super().__init__(timeout=60)
        self.wizard = wizard
    
    @discord.ui.button(label="Deploy", style=discord.ButtonStyle.success, emoji="����")
    async def deploy(self, interaction: discord.Interaction, button: Button):
        await self.create_server(interaction)
    
    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger, emoji="���")
    async def cancel(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(embed=error_embed("Cancelled", "Server creation cancelled"), view=None)
    
    async def create_server(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        d = self.wizard.data
        
        try:
            async with get_pterodactyl_api() as api:
                nodes = await api.get_nodes()
                node = next((n for n in nodes if n.id == d['node_id']), None)
                if not node:
                    await interaction.followup.send(embed=error_embed("Error", "Node not found in Pterodactyl"), ephemeral=True)
                    return
                
                egg_config = MC_EGG_CONFIGS.get(d['software'])
                if not egg_config:
                    await interaction.followup.send(embed=error_embed("Error", "Invalid software"), ephemeral=True)
                    return
                
                egg = await api.get_egg(egg_config['nest'], egg_config['egg'])
                if not egg:
                    await interaction.followup.send(embed=error_embed("Error", "Egg not found"), ephemeral=True)
                    return
                
                alloc_data = await api.get_allocations(node.id)
                free_port = None
                for alloc in alloc_data:
                    attrs = alloc['attributes']
                    if attrs.get('alias') == 'minecraft' or not attrs.get('assigned'):
                        free_port = attrs['port']
                        break
                
                if not free_port:
                    await interaction.followup.send(embed=error_embed("Error", "No free ports on node"), ephemeral=True)
                    return
                
                server_data = {
                    "name": d['name'],
                    "user": 1,
                    "node": node.id,
                    "nest": egg_config['nest'],
                    "egg": egg_config['egg'],
                    "docker_image": settings.PTERODACTYL_DOCKER_IMAGE,
                    "startup": egg.startup,
                    "environment": {
                        "VERSION": d['version'],
                        "SERVER_JARFILE": "server.jar"
                    },
                    "limits": {"memory": 2048, "swap": 0, "disk": 10240, "io": 500, "cpu": 200},
                    "feature_limits": {"databases": 5, "allocations": 1, "backups": 5},
                    "allocation": free_port,
                    "deploy": True
                }
                
                result = await api.create_server(server_data)
                server_attrs = result['attributes']
                
                await api.power_action(server_attrs['id'], 'start')
                
                async with async_session_maker() as session:
                    mc_server = MinecraftServer(
                        uuid=server_attrs['uuid'],
                        name=d['name'],
                        owner_id=interaction.user.id,
                        node_id=d['node_id'],
                        pterodactyl_server_id=server_attrs['id'],
                        pterodactyl_node_id=node.id,
                        software=d['software'],
                        version=d['version'],
                        ram=2048,
                        cpu=2,
                        disk=10,
                        port=free_port,
                        egg_id=egg_config['egg'],
                        docker_image=settings.PTERODACTYL_DOCKER_IMAGE,
                        startup_command=egg.startup,
                        status="running"
                    )
                    session.add(mc_server)
                    await session.commit()
                
                log_pterodactyl_action("CREATE_MC", server_attrs['id'], interaction.user.id, True)
                
                embed = success_embed("Server Deployed", f"Minecraft server **{d['name']}** is starting")
                embed.add_field(name="Software", value=f"{d['software'].title()} {d['version']}", inline=True)
                embed.add_field(name="Node", value=node.name, inline=True)
                embed.add_field(name="Port", value=str(free_port), inline=True)
                embed.add_field(name="Panel ID", value=str(server_attrs['id']), inline=True)
                embed.add_field(name="UUID", value=server_attrs['uuid'][:8], inline=True)
                
                await interaction.followup.send(embed=embed, ephemeral=True)
        
        except PterodactylAPIError as e:
            log_pterodactyl_action("CREATE_MC", None, interaction.user.id, False, str(e))
            await interaction.followup.send(embed=error_embed("Deploy Failed", str(e)), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=error_embed("Error", str(e)), ephemeral=True)

class MinecraftCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.hybrid_command(name="create-mc", description="Create Minecraft server (Admin)")
    @commands.guild_only()
    async def create_mc(self, ctx: commands.Context):
        if not has_permission(ctx.author, PermissionLevel.ADMIN):
            await ctx.send(embed=error_embed("Permission Denied", "Admin only"), ephemeral=True)
            return
        
        if not settings.PTERODACTYL_URL or not settings.PTERODACTYL_API_KEY:
            await ctx.send(embed=error_embed("Not Configured", "Pterodactyl not configured"), ephemeral=True)
            return
        
        async with async_session_maker() as session:
            nodes = await session.execute(select(Node).where(Node.is_active == True, Node.status == "online"))
            nodes = nodes.scalars().all()
        
        if not nodes:
            await ctx.send(embed=error_embed("No Nodes", "No online nodes available"), ephemeral=True)
            return
        
        options = [discord.SelectOption(label=f"{n.name} ({n.location})", value=str(n.id)) for n in nodes]
        select = Select(placeholder="Select Node", options=options, custom_id="mc_node_select")
        
        wizard = MCCreateWizard(ctx.author.id)
        
        async def node_callback(interaction: discord.Interaction):
            wizard.data['node_id'] = int(select.values[0])
            await wizard.show_software_select(interaction)
        
        select.callback = node_callback
        view = View()
        view.add_item(select)
        
        embed = minecraft_embed("Minecraft Server Creator", "Deploy a Minecraft server via Pterodactyl")
        embed.add_field(name="Supported Software", value="Paper, Purpur, Fabric, Forge, NeoForge, Spigot, Vanilla", inline=False)
        embed.add_field(name="Auto-configuration", value="RAM, CPU, Disk, Port allocated automatically", inline=False)
        
        await ctx.send(embed=embed, view=view, ephemeral=True)
    
    @commands.hybrid_command(name="mc-list", description="List your Minecraft servers")
    @commands.guild_only()
    async def mc_list(self, ctx: commands.Context):
        async with async_session_maker() as session:
            servers = await session.execute(
                select(MinecraftServer).where(MinecraftServer.owner_id == ctx.author.id)
                .order_by(MinecraftServer.created_at.desc())
            )
            servers = servers.scalars().all()
        
        if not servers:
            await ctx.send(embed=info_embed("No Servers", "No Minecraft servers found"), ephemeral=True)
            return
        
        embed = minecraft_embed("Your Minecraft Servers", f"Total: {len(servers)}")
        for s in servers:
            status_emoji = {"running": "����", "stopped": "����", "installing": "���", "error": "���", "suspended": "������"}.get(s.status, "���")
            embed.add_field(
                name=f"{status_emoji} {s.name}",
                value=f"{s.software.title()} {s.version} | {s.ram}MB RAM | Port: {s.port} | Node: {s.node_id}",
                inline=False
            )
        await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(MinecraftCog(bot))