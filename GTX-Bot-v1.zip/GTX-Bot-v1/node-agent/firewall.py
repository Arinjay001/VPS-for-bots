import asyncio
import logging
from typing import Dict, Any, List

logger = logging.getLogger("node-agent.firewall")

class FirewallManager:
    def __init__(self):
        self.rules: Dict[str, List[Dict]] = {}
    
    async def add_rule(self, uuid: str, port: int, protocol: str, action: str, source: str):
        if uuid not in self.rules:
            self.rules[uuid] = []
        
        rule = {"port": port, "protocol": protocol, "action": action, "source": source}
        self.rules[uuid].append(rule)
        
        await self._apply_rule(uuid, rule)
        logger.info(f"Added firewall rule for {uuid}: {action} {port}/{protocol} from {source}")
    
    async def _apply_rule(self, uuid: str, rule: Dict):
        pass
    
    async def remove_rule(self, uuid: str, port: int, protocol: str):
        if uuid in self.rules:
            self.rules[uuid] = [r for r in self.rules[uuid] if not (r["port"] == port and r["protocol"] == protocol)]
    
    async def list_rules(self, uuid: str) -> List[Dict]:
        return self.rules.get(uuid, [])
    
    async def clear_rules(self, uuid: str):
        if uuid in self.rules:
            del self.rules[uuid]