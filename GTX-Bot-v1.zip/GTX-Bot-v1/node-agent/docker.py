import asyncio
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("node-agent.docker")

class DockerManager:
    def __init__(self):
        self.client = None
    
    async def _get_client(self):
        if self.client is None:
            try:
                import docker
                self.client = docker.from_env()
            except Exception as e:
                logger.error(f"Docker not available: {e}")
                raise RuntimeError("Docker not available")
        return self.client
    
    async def create_container(self, config: Dict[str, Any]):
        client = await self._get_client()
        try:
            image_map = {
                "ubuntu-22.04": "ubuntu:22.04",
                "ubuntu-24.04": "ubuntu:24.04",
                "debian-12": "debian:12",
                "almalinux-9": "almalinux:9",
            }
            image = image_map.get(config["os_template"], "ubuntu:22.04")
            
            container = client.containers.run(
                image,
                detach=True,
                name=config["uuid"],
                hostname=config["hostname"],
                mem_limit=f"{config['ram']}m",
                cpu_count=config["cpu"],
                ports={'22/tcp': config["ssh_port"]},
                environment={"ROOT_PASSWORD": config["root_password"]},
                privileged=True,
                command="/sbin/init"
            )
            logger.info(f"Created Docker container {config['uuid']}")
        except Exception as e:
            logger.error(f"Docker create failed: {e}")
            raise
    
    async def delete_container(self, uuid: str):
        client = await self._get_client()
        try:
            container = client.containers.get(uuid)
            container.stop(timeout=10)
            container.remove()
            logger.info(f"Deleted Docker container {uuid}")
        except Exception as e:
            logger.error(f"Docker delete failed: {e}")
            raise
    
    async def start(self, uuid: str):
        client = await self._get_client()
        container = client.containers.get(uuid)
        container.start()
    
    async def stop(self, uuid: str):
        client = await self._get_client()
        container = client.containers.get(uuid)
        container.stop(timeout=30)
    
    async def restart(self, uuid: str):
        client = await self._get_client()
        container = client.containers.get(uuid)
        container.restart()
    
    async def execute(self, uuid: str, command: str) -> str:
        client = await self._get_client()
        container = client.containers.get(uuid)
        result = container.exec_run(command)
        return result.output.decode() if result.output else ""
    
    async def get_stats(self, uuid: str) -> Dict[str, Any]:
        client = await self._get_client()
        container = client.containers.get(uuid)
        stats = container.stats(stream=False)
        
        cpu_delta = stats["cpu_stats"]["cpu_usage"]["total_usage"] - stats["precpu_stats"]["cpu_usage"]["total_usage"]
        system_delta = stats["cpu_stats"]["system_cpu_usage"] - stats["precpu_stats"]["system_cpu_usage"]
        cpu_percent = (cpu_delta / system_delta) * 100 * len(stats["cpu_stats"]["cpu_usage"]["percpu_usage"]) if system_delta > 0 else 0
        
        mem_usage = stats["memory_stats"]["usage"]
        mem_limit = stats["memory_stats"]["limit"]
        
        return {
            "cpu_percent": cpu_percent,
            "memory_used": mem_usage,
            "memory_limit": mem_limit,
            "running": container.status == "running"
        }