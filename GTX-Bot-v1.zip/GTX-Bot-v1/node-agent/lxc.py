import asyncio
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("node-agent.lxc")

class LXCManager:
    def __init__(self):
        pass
    
    async def _run(self, cmd: list) -> tuple:
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        return proc.returncode, stdout.decode(), stderr.decode()
    
    async def create_container(self, config: Dict[str, Any]):
        uuid = config["uuid"]
        template = config["os_template"]
        
        cmd = ["lxc-create", "-n", uuid, "-t", "download", "--", "-d", template.split('-')[0], "-r", template.split('-')[1] if '-' in template else "22.04", "-a", "amd64"]
        code, out, err = await self._run(cmd)
        if code != 0:
            raise RuntimeError(f"LXC create failed: {err}")
        
        await self._set_config(uuid, config)
        await self._run(["lxc-start", "-n", uuid])
        logger.info(f"Created LXC container {uuid}")
    
    async def _set_config(self, uuid: str, config: Dict[str, Any]):
        config_lines = [
            f"lxc.cgroup.memory.max = {config['ram']}M",
            f"lxc.cgroup.cpu.max = {config['cpu']} 100000",
        ]
        
        with open(f"/var/lib/lxc/{uuid}/config", "a") as f:
            f.write("\n" + "\n".join(config_lines))
    
    async def delete_container(self, uuid: str):
        await self._run(["lxc-stop", "-n", uuid, "-k"])
        await self._run(["lxc-destroy", "-n", uuid])
        logger.info(f"Deleted LXC container {uuid}")
    
    async def start(self, uuid: str):
        await self._run(["lxc-start", "-n", uuid])
    
    async def stop(self, uuid: str):
        await self._run(["lxc-stop", "-n", uuid])
    
    async def restart(self, uuid: str):
        await self.stop(uuid)
        await asyncio.sleep(2)
        await self.start(uuid)
    
    async def execute(self, uuid: str, command: str) -> str:
        code, out, err = await self._run(["lxc-attach", "-n", uuid, "--", "bash", "-c", command])
        return out if code == 0 else err
    
    async def get_stats(self, uuid: str) -> Dict[str, Any]:
        code, out, err = await self._run(["lxc-info", "-n", uuid, "--stats"])
        return {"running": code == 0, "raw": out}