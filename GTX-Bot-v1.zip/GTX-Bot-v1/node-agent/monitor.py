import asyncio
import psutil
import logging
from typing import Dict, List, Any
from dataclasses import dataclass

from config import agent_settings
from utils.virtualization import detect_virtualization_support

logger = logging.getLogger("node-agent.monitor")

@dataclass
class SystemStats:
    cpu_percent: float
    memory_total: int
    memory_used: int
    memory_available: int
    disk_total: int
    disk_used: int
    disk_free: int
    network_rx: int
    network_tx: int
    load_avg: List[float]
    uptime: int
    vps_count: int = 0

class SystemMonitor:
    def __init__(self):
        self.running = False
        self.task = None
        self.last_net_io = psutil.net_io_counters()
    
    async def start(self):
        self.running = True
        self.task = asyncio.create_task(self.monitor_loop())
        logger.info("System monitor started")
    
    async def stop(self):
        self.running = False
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        logger.info("System monitor stopped")
    
    async def monitor_loop(self):
        while self.running:
            try:
                await self.collect_stats()
            except Exception as e:
                logger.error(f"Monitor error: {e}")
            await asyncio.sleep(agent_settings.MONITOR_INTERVAL)
    
    async def collect_stats(self):
        pass
    
    async def get_stats(self) -> Dict[str, Any]:
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        net = psutil.net_io_counters()
        
        rx_diff = net.bytes_recv - self.last_net_io.bytes_recv
        tx_diff = net.bytes_sent - self.last_net_io.bytes_sent
        self.last_net_io = net
        
        return {
            "cpu_percent": cpu,
            "memory_total": mem.total,
            "memory_used": mem.used,
            "memory_available": mem.available,
            "disk_total": disk.total,
            "disk_used": disk.used,
            "disk_free": disk.free,
            "network_rx": rx_diff,
            "network_tx": tx_diff,
            "load_avg": list(psutil.getloadavg()) if hasattr(psutil, 'getloadavg') else [0, 0, 0],
            "uptime": int(psutil.boot_time()),
            "vps_count": await self.get_vps_count()
        }
    
    async def get_vps_count(self) -> int:
        count = 0
        try:
            import subprocess
            result = subprocess.run(["docker", "ps", "-q"], capture_output=True, text=True)
            count += len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        except Exception:
            pass
        try:
            import subprocess
            result = subprocess.run(["lxc-ls", "--active"], capture_output=True, text=True)
            count += len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        except Exception:
            pass
        try:
            import subprocess
            result = subprocess.run(["lxc", "list", "--format=csv", "-c=n", "status=running"], capture_output=True, text=True)
            count += len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        except Exception:
            pass
        try:
            import subprocess
            result = subprocess.run(["virsh", "list", "--state-running", "--name"], capture_output=True, text=True)
            count += len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        except Exception:
            pass
        return count
    
    async def get_virtualization_support(self) -> List:
        return await detect_virtualization_support()