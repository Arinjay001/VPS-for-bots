import asyncio
import logging
import xml.etree.ElementTree as ET
from typing import Dict, Any

logger = logging.getLogger("node-agent.kvm")

class KVMManager:
    def __init__(self):
        pass
    
    async def _run(self, cmd: list) -> tuple:
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        return proc.returncode, stdout.decode(), stderr.decode()
    
    async def create_vm(self, config: Dict[str, Any]):
        uuid = config["uuid"]
        
        disk_path = f"/var/lib/libvirt/images/{uuid}.qcow2"
        code, out, err = await self._run(["qemu-img", "create", "-f", "qcow2", disk_path, f"{config['disk']}G"])
        if code != 0:
            raise RuntimeError(f"Disk create failed: {err}")
        
        xml = self._generate_xml(config, disk_path)
        with open(f"/tmp/{uuid}.xml", "w") as f:
            f.write(xml)
        
        code, out, err = await self._run(["virsh", "define", f"/tmp/{uuid}.xml"])
        if code != 0:
            raise RuntimeError(f"VM define failed: {err}")
        
        await self._run(["virsh", "start", uuid])
        logger.info(f"Created KVM VM {uuid}")
    
    def _generate_xml(self, config: Dict[str, Any], disk_path: str) -> str:
        return f"""<domain type='kvm'>
  <name>{config['uuid']}</name>
  <memory unit='MiB'>{config['ram']}</memory>
  <vcpu>{config['cpu']}</vcpu>
  <os>
    <type arch='x86_64' machine='pc-q35-6.2'>hvm</type>
    <boot dev='hd'/>
  </os>
  <devices>
    <disk type='file' device='disk'>
      <driver name='qemu' type='qcow2'/>
      <source file='{disk_path}'/>
      <target dev='vda' bus='virtio'/>
    </disk>
    <interface type='bridge'>
      <source bridge='gtxbr0'/>
      <model type='virtio'/>
    </interface>
    <console type='pty'/>
  </devices>
</domain>"""
    
    async def delete_vm(self, uuid: str):
        await self._run(["virsh", "destroy", uuid])
        await self._run(["virsh", "undefine", uuid, "--remove-all-storage"])
        logger.info(f"Deleted KVM VM {uuid}")
    
    async def start(self, uuid: str):
        await self._run(["virsh", "start", uuid])
    
    async def stop(self, uuid: str):
        await self._run(["virsh", "shutdown", uuid])
        await asyncio.sleep(5)
        await self._run(["virsh", "destroy", uuid])
    
    async def restart(self, uuid: str):
        await self.stop(uuid)
        await asyncio.sleep(2)
        await self.start(uuid)
    
    async def execute(self, uuid: str, command: str) -> str:
        return "KVM guest agent required for command execution"
    
    async def get_stats(self, uuid: str) -> Dict[str, Any]:
        code, out, err = await self._run(["virsh", "domstats", uuid, "--cpu", "--memory"])
        return {"running": code == 0, "raw": out}