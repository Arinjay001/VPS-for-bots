import asyncio
import logging
import signal
import sys
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from api import router as api_router
from monitor import SystemMonitor
from config import agent_settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("node-agent")

monitor = SystemMonitor()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting GTX Node Agent...")
    await monitor.start()
    yield
    logger.info("Shutting down GTX Node Agent...")
    await monitor.stop()

app = FastAPI(
    title="GTX Node Agent",
    description="Node agent for GTX Bot v1 - VPS & Container Management",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer(auto_error=False)

async def verify_api_key(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing API key",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if credentials.credentials != agent_settings.API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials

app.include_router(api_router, prefix="/api/v1", dependencies=[Depends(verify_api_key)])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "gtx-node-agent"}

@app.get("/")
async def root():
    return {"service": "GTX Node Agent", "version": "1.0.0"}

def main():
    logger.info("Starting GTX Node Agent server...")
    uvicorn.run(
        "agent:app",
        host=agent_settings.HOST,
        port=agent_settings.PORT,
        reload=agent_settings.DEBUG,
        log_level="info",
    )

if __name__ == "__main__":
    main()