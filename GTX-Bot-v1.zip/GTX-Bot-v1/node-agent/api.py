from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import asyncio
import logging

from docker_manager import DockerManager
from lxc_manager import LXCManager
from lxd_manager import LXDManager
from kvm_manager import KVMManager
from firewall import FirewallManager
from monitor import SystemMonitor
from config import agent_settings

logger = logging.getLogger("node-agent.api")

router = APIRouter()

docker_mgr = DockerManager()
lxc_mgr = LXCManager()
lxd_mgr = LXDManager()
kvm_mgr = KVMManager()
firewall_mgr = FirewallManager()
monitor = SystemMonitor()

class VPSCreateRequest(BaseModel):
    uuid: str
    name: str
    hostname: str
    virtualization: str
    os_template: str
    ram: int
    cpu: int
    disk: int
    ssh_port: int
    root_password: str

class VPSActionRequest(BaseModel):
    uuid: str

class CommandRequest(BaseModel):
    uuid: str
    command: str

class FirewallRuleRequest(BaseModel):
    uuid: str
    port: int
    protocol: str = "tcp"
    action: str
    source: str = "0.0.0.0/0"

@router.get("/stats")
async def get_stats():
    stats = await monitor.get_stats()
    virt = await monitor.get_virtualization_support()
    return {
        **stats,
        "virtualization": [v.value for v in virt]
    }

@router.post("/vps/create")
async def create_vps(request: VPSCreateRequest, background_tasks: BackgroundTasks):
    try:
        if request.virtualization == "docker":
            background_tasks.add_task(docker_mgr.create_container, request.dict())
        elif request.virtualization == "lxc_lxd_supported":
            background_tasks.add_task(lxd_mgr.create_container, request.dict())
        elif request.virtualization == "lxc_lxd_unsupported":
            background_tasks.add_task(lxc_mgr.create_container, request.dict())
        elif request.virtualization == "kvm":
            background_tasks.add_task(kvm_mgr.create_vm, request.dict())
        else:
            raise HTTPException(400, "Invalid virtualization type")
        return {"status": "creating", "uuid": request.uuid}
    except Exception as e:
        logger.error(f"Create VPS failed: {e}")
        raise HTTPException(500, str(e))

@router.post("/vps/delete")
async def delete_vps(request: VPSActionRequest):
    try:
        results = await asyncio.gather(
            docker_mgr.delete_container(request.uuid),
            lxc_mgr.delete_container(request.uuid),
            lxd_mgr.delete_container(request.uuid),
            kvm_mgr.delete_vm(request.uuid),
            return_exceptions=True
        )
        return {"status": "deleted", "uuid": request.uuid}
    except Exception as e:
        logger.error(f"Delete VPS failed: {e}")
        raise HTTPException(500, str(e))

@router.post("/vps/start")
async def start_vps(request: VPSActionRequest):
    for mgr in [docker_mgr, lxc_mgr, lxd_mgr, kvm_mgr]:
        try:
            await mgr.start(request.uuid)
            return {"status": "starting", "uuid": request.uuid}
        except Exception:
            continue
    raise HTTPException(404, "VPS not found")

@router.post("/vps/stop")
async def stop_vps(request: VPSActionRequest):
    for mgr in [docker_mgr, lxc_mgr, lxd_mgr, kvm_mgr]:
        try:
            await mgr.stop(request.uuid)
            return {"status": "stopping", "uuid": request.uuid}
        except Exception:
            continue
    raise HTTPException(404, "VPS not found")

@router.post("/vps/restart")
async def restart_vps(request: VPSActionRequest):
    for mgr in [docker_mgr, lxc_mgr, lxd_mgr, kvm_mgr]:
        try:
            await mgr.restart(request.uuid)
            return {"status": "restarting", "uuid": request.uuid}
        except Exception:
            continue
    raise HTTPException(404, "VPS not found")

@router.post("/vps/reinstall")
async def reinstall_vps(request: VPSActionRequest):
    raise HTTPException(501, "Not implemented")

@router.post("/vps/execute")
async def execute_command(request: CommandRequest):
    for mgr in [docker_mgr, lxc_mgr, lxd_mgr, kvm_mgr]:
        try:
            output = await mgr.execute(request.uuid, request.command)
            return {"output": output}
        except Exception:
            continue
    raise HTTPException(404, "VPS not found")

@router.get("/vps/{uuid}/stats")
async def get_vps_stats(uuid: str):
    for mgr in [docker_mgr, lxc_mgr, lxd_mgr, kvm_mgr]:
        try:
            stats = await mgr.get_stats(uuid)
            return stats
        except Exception:
            continue
    raise HTTPException(404, "VPS not found")

@router.post("/firewall/allow")
async def firewall_allow(request: FirewallRuleRequest):
    try:
        await firewall_mgr.add_rule(request.uuid, request.port, request.protocol, "allow", request.source)
        return {"status": "allowed"}
    except Exception as e:
        raise HTTPException(500, str(e))

@router.post("/firewall/deny")
async def firewall_deny(request: FirewallRuleRequest):
    try:
        await firewall_mgr.add_rule(request.uuid, request.port, request.protocol, "deny", request.source)
        return {"status": "denied"}
    except Exception as e:
        raise HTTPException(500, str(e))

@router.get("/firewall/rules")
async def firewall_list(uuid: str):
    try:
        rules = await firewall_mgr.list_rules(uuid)
        return {"rules": rules}
    except Exception as e:
        raise HTTPException(500, str(e))