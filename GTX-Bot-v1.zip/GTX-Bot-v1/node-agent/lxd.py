import asyncio
import logging
from typing import Dict, Any

logger = logging.getLogger("node-agent.lxd")

class LXDManager:
    def __init__(self):
        self.client = None
    
    async def _get_client(self):
        if self.client is None:
            try:
                import pylxd
                self.client = pylxd.Client()
            except Exception as e:
                logger.error(f"LXD not available: {e}")
                raise RuntimeError("LXD not available")
        return self.client
    
    async def create_container(self, config: Dict[str, Any]):
        client = await self._get_client()
        uuid = config["uuid"]
        
        try:
            image_map = {
                "ubuntu-22.04": "ubuntu:22.04",
                "ubuntu-24.04": "ubuntu:24.04",
                "debian-12": "debian:12",
                "almalinux-9": "almalinux:9",
            }
            image = image_map.get(config["os_template"], "ubuntu:22.04")
            
            container = client.containers.create({
                "name": uuid,
                "source": {"type": "image", "alias": image},
                "config": {
                    "limits.memory": f"{config['ram']}MB",
                    "limits.cpu": str(config["cpu"]),
                },
                "profiles": ["default"]
            }, wait=True)
            
            container.start()
            logger.info(f"Created LXD container {uuid}")
        except Exception as e:
            logger.error(f"LXD create failed: {e}")
            raise
    
    async def delete_container(self, uuid: str):
        client = await self._get_client()
        try:
            container = client.containers.get(uuid)
            container.stop(wait=True)
            container.delete()
            logger.info(f"Deleted LXD container {uuid}")
        except Exception as e:
            logger.error(f"LXD delete failed: {e}")
            raise
    
    async def start(self, uuid: str):
        client = await self._get_client()
        container = client.containers.get(uuid)
        container.start()
    
    async def stop(self, uuid: str):
        client = await self._get_client()
        container = client.containers.get(uuid)
        container.stop(wait=True)
    
    async def restart(self, uuid: str):
        await self.stop(uuid)
        await self.start(uuid)
    
    async def execute(self, uuid: str, command: str) -> str:
        client = await self._get_client()
        container = client.containers.get(uuid)
        result = container.execute(["bash", "-c", command])
        return result.stdout if result.exit_code == 0 else result.stderr
    
    async def get_stats(self, uuid: str) -> Dict[str, Any]:
        client = await self._get_client()
        container = client.containers.get(uuid)
        state = container.state()
        return {
            "running": state.status == "Running",
            "cpu_percent": state.cpu.usage / 1e9 if state.cpu else 0,
            "memory_used": state.memory.usage if state.memory else 0,
        }