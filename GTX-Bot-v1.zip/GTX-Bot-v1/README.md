# GTX Bot v1

A production-ready Discord hosting bot with VPS management, Minecraft server creation, ticket system, and security features.

## Features

- **VPS Management**: Create, delete, restart, stop, start, reinstall VPS instances
- **Minecraft Server Creator**: Deploy Paper, Purpur, Fabric, Forge, NeoForge, Spigot, Vanilla servers via Pterodactyl
- **Premium Ticket System**: Categories, claims, transcripts, user management, statistics
- **Guardian Security**: Anti-raid, anti-spam, anti-bot, anti-webhook, anti-nuke, audit logs
- **Node Management**: Unlimited remote/local nodes with health monitoring
- **Node Agent**: FastAPI-based agent for VPS operations (Docker, LXC, LXD, KVM)
- **Auto Port Allocation**: Automatic free port discovery and reservation
- **Backup System**: Automatic, manual, scheduled backups with restore
- **Monitoring**: Real-time node stats, latency, resource usage
- **Pterodactyl Integration**: Full Application API support
- **Role-based Permissions**: Owner, Admin, Staff, Customer, VPS User, Premium User
- **Purple GTX Branding**: Professional embeds, buttons, dropdowns, modals

## Requirements

- Python 3.12+
- Discord.py 2.3+
- SQLite (included) or PostgreSQL
- Pterodactyl Panel (for Minecraft/VPS)
- Node agents on each VPS host

## Installation

### 1. Clone and Setup

```bash
git clone <repository>
cd GTX-Bot-v1
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your values
```

Required settings:
- `DISCORD_TOKEN` - Your bot token from Discord Developer Portal
- `ENCRYPTION_KEY` - Generate with: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`
- `NODE_AGENT_API_KEY` - Shared secret for node communication
- `PTERODACTYL_URL` and `PTERODACTYL_API_KEY` - For Minecraft/VPS features

### 3. Setup Database

```bash
python -c "import asyncio; from database import init_db; asyncio.run(init_db())"
```

### 4. Run the Bot

```bash
python bot.py
```

### 5. Run Node Agent (on each VPS host)

```bash
cd node-agent
pip install -r requirements.txt
cp ../.env .env  # Copy relevant settings
python agent.py
```

## Project Structure

```
GTX-Bot-v1/
├── bot.py                 # Main entry point
├── config.py              # Configuration management
├── database.py            # SQLAlchemy models & database
├── requirements.txt       # Python dependencies
├── .env                   # Environment variables
├── cogs/                  # Discord command modules
│   ├── guardian.py        # Security module
│   ├── tickets.py         # Ticket system
│   ├── vps.py             # VPS management
│   ├── nodes.py           # Node management
│   ├── monitoring.py      # Monitoring commands
│   ├── minecraft.py       # Minecraft server creator
│   ├── pterodactyl.py     # Pterodactyl integration
│   ├── users.py           # User management
│   ├── admin.py           # Admin commands
│   ├── backups.py         # Backup system
│   ├── ports.py           # Port allocation
│   ├── firewall.py        # Firewall management
│   ├── dashboard.py       # Dashboard preparation
│   ├── logs.py            # Log viewing
│   └── utils.py           # Utility commands
├── utils/                 # Shared utilities
│   ├── embeds.py          # Embed builders
│   ├── permissions.py     # Permission system
│   ├── helpers.py         # Helper functions
│   ├── logger.py          # Logging setup
│   ├── validator.py       # Input validation
│   ├── network.py         # Network utilities
│   ├── virtualization.py  # Virtualization detection
│   └── ptero_api.py       # Pterodactyl API client
├── node-agent/            # FastAPI node agent
│   ├── agent.py           # Main FastAPI app
│   ├── api.py             # API routes
│   ├── monitor.py         # System monitoring
│   ├── docker.py          # Docker operations
│   ├── lxc.py             # LXC operations
│   ├── lxd.py             # LXD operations
│   ├── kvm.py             # KVM operations
│   ├── firewall.py        # Firewall management
│   ├── config.py          # Agent configuration
│   └── requirements.txt   # Agent dependencies
├── install/               # Installation scripts
├── services/              # Systemd service files
├── database/              # Database files & migrations
├── logs/                  # Log files
├── backups/               # Backup storage
├── assets/                # Images, icons, themes
��── docs/                  # Documentation
```

## Commands

### VPS Management
- `!create` - Interactive VPS creation wizard
- `!delete <vps_id>` - Delete a VPS
- `!restart <vps_id>` - Restart a VPS
- `!stop <vps_id>` - Stop a VPS
- `!start <vps_id>` - Start a VPS
- `!reinstall <vps_id>` - Reinstall VPS OS
- `!listvps` - List all VPS (admin)
- `!myvps` - List your VPS

### Minecraft
- `!create-mc` - Create Minecraft server (admin)

### Nodes
- `!nodes` - List all nodes
- `!node <id>` - Node details
- `!status` - Quick status overview
- `!stats` - Detailed statistics

### Tickets
- `!ticket` - Open ticket panel
- `!ticket-stats` - Ticket statistics

### Guardian
- `!guardian` - Guardian dashboard
- `!whitelist <user>` - Whitelist user
- `!unwhitelist <user>` - Remove whitelist

### Admin
- `!setup` - Initial setup wizard
- `!backup` - Manual backup
- `!restore` - Restore backup

## Virtualization Support

| Type | Description | Requirements |
|------|-------------|--------------|
| KVM | Full virtualization | CPU virtualization extensions |
| LXC (LXD Supported) | System containers with LXD | LXD daemon |
| LXC (LXD Unsupported) | Basic LXC containers | LXC tools |
| Docker | Container platform | Docker daemon |

The bot automatically detects supported types on each node.

## Security

- API key authentication for node communication
- JWT support for dashboard
- Owner/Admin lock modes
- Command cooldowns
- Encrypted configuration values
- Comprehensive audit logging
- Role-based access control

## Monitoring

The bot provides real-time monitoring of:
- Node online/offline status
- Latency (ping)
- RAM/CPU/Disk usage
- Network RX/TX
- VPS count per node
- Automatic health checks every 30 seconds

## Backup System

- Automatic daily backups (configurable)
- Manual backup creation
- Backup retention (default 7 days)
- One-click restore
- Scheduled via cron-like syntax

## License

MIT License - see LICENSE file for details.

## Support

For issues and feature requests, please use the GitHub issue tracker.