import os
from datetime import datetime
from typing import Optional, List, AsyncGenerator
from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, ForeignKey, 
    Enum, BigInteger, JSON, Index, UniqueConstraint, select
)
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base, relationship, declared_attr
from sqlalchemy.dialects.sqlite import JSON as SQLiteJSON
import enum

from config import settings

Base = declarative_base()

class PermissionLevel(enum.IntEnum):
    USER = 0
    VPS_USER = 1
    PREMIUM_USER = 1
    CUSTOMER = 2
    STAFF = 3
    ADMIN = 4
    OWNER = 5

class VirtualizationType(enum.Enum):
    KVM = "kvm"
    LXD_SUPPORTED = "lxd_supported"
    LXD_UNSUPPORTED = "lxd_unsupported"
    DOCKER = "docker"

class NodeStatus(enum.Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    MAINTENANCE = "maintenance"
    ERROR = "error"

class VPSStatus(enum.Enum):
    CREATING = "creating"
    RUNNING = "running"
    STOPPED = "stopped"
    REINSTALLING = "reinstalling"
    ERROR = "error"
    DELETED = "deleted"

class ServerStatus(enum.Enum):
    CREATING = "creating"
    RUNNING = "running"
    STOPPED = "stopped"
    RESTARTING = "restarting"
    REINSTALLING = "reinstalling"
    BACKING_UP = "backing_up"
    SUSPENDED = "suspended"
    ERROR = "error"

class TicketStatus(enum.Enum):
    OPEN = "open"
    CLAIMED = "claimed"
    CLOSED = "closed"
    DELETED = "deleted"

class BackupType(enum.Enum):
    AUTO = "auto"
    MANUAL = "manual"
    SCHEDULED = "scheduled"

class BackupStatus(enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class GuardianAction(enum.Enum):
    WARN = "warn"
    MUTE = "mute"
    KICK = "kick"
    BAN = "ban"
    TIMEOUT = "timeout"

class User(Base):
    __tablename__ = "users"
    
    id = Column(BigInteger, primary_key=True)
    discord_id = Column(BigInteger, unique=True, nullable=False, index=True)
    username = Column(String(100), nullable=False)
    discriminator = Column(String(10), nullable=True)
    avatar = Column(String(200), nullable=True)
    
    permission_level = Column(Integer, default=PermissionLevel.USER.value)
    is_whitelisted = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    ban_reason = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    vps_instances = relationship("VPSInstance", back_populates="owner")
    minecraft_servers = relationship("MinecraftServer", back_populates="owner")
    tickets = relationship("Ticket", back_populates="creator")
    tickets_claimed = relationship("Ticket", back_populates="claimer", foreign_keys="Ticket.claimer_id")
    guardian_logs = relationship("GuardianLog", back_populates="user")
    api_keys = relationship("APIKey", back_populates="user")

class GuildConfig(Base):
    __tablename__ = "guild_configs"
    
    id = Column(BigInteger, primary_key=True)
    guild_id = Column(BigInteger, unique=True, nullable=False, index=True)
    
    ticket_category_id = Column(BigInteger, nullable=True)
    ticket_log_channel_id = Column(BigInteger, nullable=True)
    ticket_transcript_channel_id = Column(BigInteger, nullable=True)
    
    admin_role_ids = Column(SQLiteJSON, default=list)
    staff_role_ids = Column(SQLiteJSON, default=list)
    customer_role_ids = Column(SQLiteJSON, default=list)
    vps_user_role_ids = Column(SQLiteJSON, default=list)
    premium_user_role_ids = Column(SQLiteJSON, default=list)
    whitelist_role_ids = Column(SQLiteJSON, default=list)
    ticket_staff_role_ids = Column(SQLiteJSON, default=list)
    
    anti_raid_enabled = Column(Boolean, default=True)
    anti_spam_enabled = Column(Boolean, default=True)
    anti_bot_enabled = Column(Boolean, default=True)
    anti_webhook_enabled = Column(Boolean, default=True)
    anti_nuke_enabled = Column(Boolean, default=True)
    anti_kick_enabled = Column(Boolean, default=True)
    anti_ban_enabled = Column(Boolean, default=True)
    anti_role_delete_enabled = Column(Boolean, default=True)
    anti_channel_delete_enabled = Column(Boolean, default=True)
    anti_mention_enabled = Column(Boolean, default=True)
    anti_spam_threshold = Column(Integer, default=5)
    anti_spam_window = Column(Integer, default=10)
    
    max_tickets_per_user = Column(Integer, default=3)
    ticket_close_delay = Column(Integer, default=5)
    
    vps_default_ram = Column(Integer, default=2048)
    vps_default_cpu = Column(Integer, default=2)
    vps_default_disk = Column(Integer, default=20)
    vps_default_os = Column(String(50), default="ubuntu22.04")
    vps_default_virtualization = Column(String(20), default="lxd_unsupported")
    
    pterodactyl_url = Column(String(200), nullable=True)
    pterodactyl_api_key = Column(String(200), nullable=True)
    pterodactyl_app_api_key = Column(String(200), nullable=True)
    pterodactyl_client_api_key = Column(String(200), nullable=True)
    
    mc_default_egg = Column(String(50), default="paper")
    mc_default_version = Column(String(50), default="latest")
    mc_allocation_start = Column(Integer, default=25565)
    mc_allocation_end = Column(Integer, default=25665)
    
    monitoring_interval = Column(Integer, default=60)
    monitoring_alert_cpu = Column(Integer, default=90)
    monitoring_alert_ram = Column(Integer, default=90)
    monitoring_alert_disk = Column(Integer, default=90)
    
    backup_enabled = Column(Boolean, default=True)
    backup_interval = Column(Integer, default=3600)
    backup_retention_days = Column(Integer, default=7)
    backup_path = Column(String(200), default="backups/")
    backup_compression = Column(Boolean, default=True)
    
    rate_limit_commands = Column(Integer, default=10)
    rate_limit_window = Column(Integer, default=60)
    rate_limit_global = Column(Integer, default=100)
    
    cooldown_create_vps = Column(Integer, default=300)
    cooldown_create_mc = Column(Integer, default=60)
    cooldown_ticket = Column(Integer, default=10)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Node(Base):
    __tablename__ = "nodes"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    host = Column(String(200), nullable=False)
    port = Column(Integer, default=8080)
    api_key = Column(String(100), nullable=False)
    jwt_secret = Column(String(100), nullable=False)
    
    is_local = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    supported_virtualization = Column(SQLiteJSON, default=list)
    
    total_ram = Column(Integer, default=0)
    total_cpu = Column(Integer, default=0)
    total_disk = Column(Integer, default=0)
    used_ram = Column(Integer, default=0)
    used_cpu = Column(Integer, default=0)
    used_disk = Column(Integer, default=0)
    
    status = Column(Enum(NodeStatus), default=NodeStatus.OFFLINE)
    last_heartbeat = Column(DateTime, nullable=True)
    latency = Column(Integer, default=0)
    
    network_info = Column(SQLiteJSON, default=dict)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    vps_instances = relationship("VPSInstance", back_populates="node")
    minecraft_servers = relationship("MinecraftServer", back_populates="node")

class VPSInstance(Base):
    __tablename__ = "vps_instances"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    hostname = Column(String(100), nullable=False, unique=True)
    
    owner_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    node_id = Column(Integer, ForeignKey("nodes.id"), nullable=False, index=True)
    
    ram = Column(Integer, nullable=False)
    cpu = Column(Integer, nullable=False)
    disk = Column(Integer, nullable=False)
    
    os_template = Column(String(100), nullable=False)
    virtualization = Column(Enum(VirtualizationType), default=VirtualizationType.KVM)
    
    ip_address = Column(String(45), nullable=True)
    ipv6_address = Column(String(45), nullable=True)
    ssh_port = Column(Integer, default=22)
    root_password = Column(String(100), nullable=True)
    
    status = Column(Enum(VPSStatus), default=VPSStatus.CREATING)
    
    pterodactyl_server_id = Column(Integer, nullable=True)
    pterodactyl_node_id = Column(Integer, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    
    owner = relationship("User", back_populates="vps_instances")
    node = relationship("Node", back_populates="vps_instances")
    backups = relationship("Backup", back_populates="vps_instance")

class MinecraftServer(Base):
    __tablename__ = "minecraft_servers"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    identifier = Column(String(100), nullable=False, unique=True)
    
    owner_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    node_id = Column(Integer, ForeignKey("nodes.id"), nullable=False, index=True)
    
    software = Column(String(50), nullable=False)
    version = Column(String(50), nullable=False)
    
    ram = Column(Integer, nullable=False)
    cpu = Column(Integer, nullable=False)
    disk = Column(Integer, nullable=False)
    
    port = Column(Integer, nullable=False, unique=True)
    allocation_id = Column(Integer, nullable=True)
    
    egg_id = Column(Integer, nullable=True)
    docker_image = Column(String(200), nullable=True)
    startup_command = Column(Text, nullable=True)
    
    status = Column(Enum(ServerStatus), default=ServerStatus.CREATING)
    
    pterodactyl_server_id = Column(Integer, nullable=True, unique=True)
    pterodactyl_node_id = Column(Integer, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    
    owner = relationship("User", back_populates="minecraft_servers")
    node = relationship("Node", back_populates="minecraft_servers")
    backups = relationship("Backup", back_populates="minecraft_server")

class Ticket(Base):
    __tablename__ = "tickets"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ticket_number = Column(Integer, nullable=False)
    
    guild_id = Column(BigInteger, nullable=False, index=True)
    channel_id = Column(BigInteger, nullable=False, unique=True)
    
    creator_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    claimer_id = Column(BigInteger, ForeignKey("users.id"), nullable=True, index=True)
    
    category = Column(String(50), nullable=False)
    subject = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    
    status = Column(Enum(TicketStatus), default=TicketStatus.OPEN)
    
    claimed_at = Column(DateTime, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True)
    
    transcript = Column(Text, nullable=True)
    transcript_channel_id = Column(BigInteger, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    creator = relationship("User", back_populates="tickets", foreign_keys=[creator_id])
    claimer = relationship("User", back_populates="tickets_claimed", foreign_keys=[claimer_id])
    participants = relationship("TicketParticipant", back_populates="ticket")

class TicketParticipant(Base):
    __tablename__ = "ticket_participants"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id"), nullable=False, index=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    added_by = Column(BigInteger, nullable=False)
    
    added_at = Column(DateTime, default=datetime.utcnow)
    
    ticket = relationship("Ticket", back_populates="participants")
    user = relationship("User")

class GuardianLog(Base):
    __tablename__ = "guardian_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    guild_id = Column(BigInteger, nullable=False, index=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    moderator_id = Column(BigInteger, nullable=True)
    
    action = Column(Enum(GuardianAction), nullable=False)
    reason = Column(Text, nullable=True)
    details = Column(SQLiteJSON, default=dict)
    
    triggered_by = Column(String(50), nullable=False)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    user = relationship("User", back_populates="guardian_logs")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    guild_id = Column(BigInteger, nullable=False, index=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    
    action = Column(String(100), nullable=False)
    target_type = Column(String(50), nullable=True)
    target_id = Column(BigInteger, nullable=True)
    
    before = Column(SQLiteJSON, default=dict)
    after = Column(SQLiteJSON, default=dict)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class Backup(Base):
    __tablename__ = "backups"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(200), nullable=False)
    
    vps_instance_id = Column(Integer, ForeignKey("vps_instances.id"), nullable=True, index=True)
    minecraft_server_id = Column(Integer, ForeignKey("minecraft_servers.id"), nullable=True, index=True)
    
    backup_type = Column(Enum(BackupType), default=BackupType.MANUAL)
    status = Column(Enum(BackupStatus), default=BackupStatus.PENDING)
    
    file_path = Column(String(500), nullable=True)
    file_size = Column(Integer, default=0)
    checksum = Column(String(64), nullable=True)
    
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    vps_instance = relationship("VPSInstance", back_populates="backups")
    minecraft_server = relationship("MinecraftServer", back_populates="backups")

class APIKey(Base):
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    
    name = Column(String(100), nullable=False)
    key_hash = Column(String(128), nullable=False, unique=True)
    key_prefix = Column(String(10), nullable=False)
    
    permissions = Column(SQLiteJSON, default=list)
    is_active = Column(Boolean, default=True)
    
    last_used = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="api_keys")

class PortAllocation(Base):
    __tablename__ = "port_allocations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(Integer, ForeignKey("nodes.id"), nullable=False, index=True)
    
    port = Column(Integer, nullable=False)
    protocol = Column(String(10), default="tcp")
    
    allocated_to_type = Column(String(50), nullable=True)
    allocated_to_id = Column(Integer, nullable=True)
    
    is_reserved = Column(Boolean, default=False)
    reserved_until = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint('node_id', 'port', 'protocol', name='unique_port_per_node'),
    )

class SSHKey(Base):
    __tablename__ = "ssh_keys"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    node_id = Column(Integer, ForeignKey("nodes.id"), nullable=True, index=True)
    
    name = Column(String(100), nullable=False)
    public_key = Column(Text, nullable=False)
    private_key = Column(Text, nullable=True)
    
    is_default = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User")

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DATABASE_ECHO,
    connect_args={"check_same_thread": False}
)

async_session_maker = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

async def init_db():
    os.makedirs(os.path.dirname(settings.DATABASE_URL.replace("sqlite+aiosqlite:///", "")), exist_ok=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def get_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

async def close_db():
    await engine.dispose()

async def get_user(session: AsyncSession, discord_id: int) -> Optional[User]:
    result = await session.execute(select(User).where(User.discord_id == discord_id))
    return result.scalar_one_or_none()

async def get_or_create_user(session: AsyncSession, discord_id: int, username: str, discriminator: str = None, avatar: str = None) -> User:
    user = await get_user(session, discord_id)
    if not user:
        user = User(
            discord_id=discord_id,
            username=username,
            discriminator=discriminator,
            avatar=avatar
        )
        session.add(user)
        await session.flush()
    return user

async def get_guild_config(session: AsyncSession, guild_id: int) -> Optional[GuildConfig]:
    result = await session.execute(select(GuildConfig).where(GuildConfig.guild_id == guild_id))
    return result.scalar_one_or_none()

async def get_or_create_guild_config(session: AsyncSession, guild_id: int) -> GuildConfig:
    config = await get_guild_config(session, guild_id)
    if not config:
        config = GuildConfig(guild_id=guild_id)
        session.add(config)
        await session.flush()
    return config