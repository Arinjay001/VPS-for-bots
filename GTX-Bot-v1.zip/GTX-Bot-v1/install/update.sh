#!/bin/bash
# GTX Bot v1 - Update Script

set -e

BOT_DIR="/opt/gtx-bot"
NODE_AGENT_DIR="/opt/gtx-node-agent"
SERVICE_USER="gtxbot"

echo "=========================================="
echo "  GTX Bot v1 - Update Script"
echo "=========================================="

cd $BOT_DIR
git pull origin main

echo "[1/4] Updating bot dependencies..."
sudo -u $SERVICE_USER $BOT_DIR/venv/bin/pip install -r requirements.txt

echo "[2/4] Updating node agent dependencies..."
cd $NODE_AGENT_DIR
git pull origin main
sudo -u $SERVICE_USER $NODE_AGENT_DIR/venv/bin/pip install -r requirements.txt

echo "[3/4] Running database migrations..."
cd $BOT_DIR
sudo -u $SERVICE_USER $BOT_DIR/venv/bin/python -c "
import asyncio
from database import init_db
asyncio.run(init_db())
"

echo "[4/4] Restarting services..."
systemctl restart gtx-bot node-agent monitoring

echo ""
echo "Update complete!"