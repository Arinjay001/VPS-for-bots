#!/bin/bash
# GTX Bot v1 - Installation Script
# Run as root: sudo bash install.sh

set -e

echo "=========================================="
echo "  GTX Bot v1 - Installation Script"
echo "=========================================="

BOT_DIR="/opt/gtx-bot"
NODE_AGENT_DIR="/opt/gtx-node-agent"
SERVICE_USER="gtxbot"

check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo "This script must be run as root"
        exit 1
    fi
}

install_dependencies() {
    echo "[1/8] Installing system dependencies..."
    apt-get update
    apt-get install -y python3.12 python3.12-venv python3.12-dev \
        git curl wget sqlite3 \
        docker.io lxc lxd qemu-kvm libvirt-daemon-system \
        iptables ipset bridge-utils \
        build-essential libssl-dev libffi-dev
    
    systemctl enable --now docker
    systemctl enable --now libvirtd
    usermod -aG docker $SERVICE_USER 2>/dev/null || true
}

create_user() {
    echo "[2/8] Creating service user..."
    id -u $SERVICE_USER &>/dev/null || useradd -r -s /bin/bash -d /home/$SERVICE_USER -m $SERVICE_USER
}

setup_directories() {
    echo "[3/8] Setting up directories..."
    mkdir -p $BOT_DIR $NODE_AGENT_DIR
    mkdir -p /var/lib/gtx/{vps,backups,templates,logs}
    mkdir -p /etc/gtx
    chown -R $SERVICE_USER:$SERVICE_USER $BOT_DIR $NODE_AGENT_DIR /var/lib/gtx /etc/gtx
}

install_bot() {
    echo "[4/8] Installing GTX Bot..."
    cd $BOT_DIR
    sudo -u $SERVICE_USER python3.12 -m venv venv
    sudo -u $SERVICE_USER $BOT_DIR/venv/bin/pip install --upgrade pip
    sudo -u $SERVICE_USER $BOT_DIR/venv/bin/pip install -r requirements.txt
}

install_node_agent() {
    echo "[5/8] Installing Node Agent..."
    cd $NODE_AGENT_DIR
    sudo -u $SERVICE_USER python3.12 -m venv venv
    sudo -u $SERVICE_USER $NODE_AGENT_DIR/venv/bin/pip install --upgrade pip
    sudo -u $SERVICE_USER $NODE_AGENT_DIR/venv/bin/pip install -r requirements.txt
}

configure_lxd() {
    echo "[6/8] Configuring LXD..."
    sudo -u $SERVICE_USER lxd init --auto --storage-backend=dir 2>/dev/null || true
    lxc network create gtxbr0 ipv4.address=auto ipv6.address=none 2>/dev/null || true
    lxc profile device add default eth0 nic network=gtxbr0 2>/dev/null || true
}

setup_network() {
    echo "[7/8] Setting up network bridge..."
    cat > /etc/netplan/99-gtx-bridge.yaml <<EOF
network:
  version: 2
  bridges:
    gtxbr0:
      interfaces: []
      addresses: [10.99.0.1/24]
      dhcp4: false
EOF
    netplan apply 2>/dev/null || true
}

install_services() {
    echo "[8/8] Installing systemd services..."
    cp $BOT_DIR/services/gtx-bot.service /etc/systemd/system/
    cp $BOT_DIR/services/node-agent.service /etc/systemd/system/
    cp $BOT_DIR/services/monitoring.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable gtx-bot node-agent monitoring
}

main() {
    check_root
    install_dependencies
    create_user
    setup_directories
    install_bot
    install_node_agent
    configure_lxd
    setup_network
    install_services
    
    echo ""
    echo "=========================================="
    echo "  Installation Complete!"
    echo "=========================================="
    echo ""
    echo "Next steps:"
    echo "1. Edit /etc/gtx/.env with your configuration"
    echo "2. Run database migration: sudo -u $SERVICE_USER $BOT_DIR/venv/bin/python -c \"import asyncio; from database import init_db; asyncio.run(init_db())\""
    echo "3. Start services: systemctl start gtx-bot node-agent monitoring"
    echo "4. Check logs: journalctl -u gtx-bot -f"
    echo ""
}

main "$@"