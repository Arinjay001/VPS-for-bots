#!/bin/bash
# GTX Bot v1 - Dependencies Only Install

set -e

echo "=========================================="
echo "  GTX Bot v1 - Dependencies Install"
echo "=========================================="

apt-get update
apt-get install -y python3.12 python3.12-venv python3.12-dev \
    git curl wget sqlite3 \
    docker.io lxc lxd qemu-kvm libvirt-daemon-system \
    iptables ipset bridge-utils \
    build-essential libssl-dev libffi-dev

systemctl enable --now docker
systemctl enable --now libvirtd

echo "Dependencies installed!"