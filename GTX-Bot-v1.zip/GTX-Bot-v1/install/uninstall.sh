#!/bin/bash
# GTX Bot v1 - Uninstall Script

set -e

BOT_DIR="/opt/gtx-bot"
NODE_AGENT_DIR="/opt/gtx-node-agent"
SERVICE_USER="gtxbot"

echo "=========================================="
echo "  GTX Bot v1 - Uninstall Script"
echo "=========================================="
echo ""
echo "WARNING: This will remove all GTX Bot data!"
read -p "Are you sure? (yes/no): " confirm
if [[ "$confirm" != "yes" ]]; then
    echo "Aborted."
    exit 1
fi

echo "Stopping services..."
systemctl stop gtx-bot node-agent monitoring 2>/dev/null || true
systemctl disable gtx-bot node-agent monitoring 2>/dev/null || true

echo "Removing systemd services..."
rm -f /etc/systemd/system/gtx-bot.service
rm -f /etc/systemd/system/node-agent.service
rm -f /etc/systemd/system/monitoring.service
systemctl daemon-reload

echo "Removing directories..."
rm -rf $BOT_DIR $NODE_AGENT_DIR
rm -rf /var/lib/gtx
rm -rf /etc/gtx

echo "Removing network config..."
rm -f /etc/netplan/99-gtx-bridge.yaml
netplan apply 2>/dev/null || true

echo "Removing user..."
userdel -r $SERVICE_USER 2>/dev/null || true

echo "Cleaning up LXD/Docker..."
lxc delete --force $(lxc list -c n --format csv) 2>/dev/null || true
docker rm -f $(docker ps -aq) 2>/dev/null || true

echo ""
echo "Uninstall complete!"