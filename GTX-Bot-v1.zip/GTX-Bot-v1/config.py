import os
from pathlib import Path
from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import Field, validator
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    DISCORD_TOKEN: str = Field(..., env="DISCORD_TOKEN")
    DISCORD_CLIENT_ID: Optional[str] = Field(None, env="DISCORD_CLIENT_ID")
    DISCORD_CLIENT_SECRET: Optional[str] = Field(None, env="DISCORD_CLIENT_SECRET")
    
    BOT_PREFIX: str = Field("!", env="BOT_PREFIX")
    BOT_STATUS: str = Field("GTX Bot v1 | Hosting Automation", env="BOT_STATUS")
    BOT_ACTIVITY_TYPE: str = Field("playing", env="BOT_ACTIVITY_TYPE")
    OWNER_ID: int = Field(..., env="OWNER_ID")
    
    DATABASE_URL: str = Field("sqlite+aiosqlite:///database/gtx.db", env="DATABASE_URL")
    DATABASE_ECHO: bool = Field(False, env="DATABASE_ECHO")
    
    LOG_LEVEL: str = Field("INFO", env="LOG_LEVEL")
    LOG_FILE: str = Field("logs/bot.log", env="LOG_FILE")
    LOG_ROTATION: str = Field("10 MB", env="LOG_ROTATION")
    LOG_RETENTION: str = Field("7 days", env="LOG_RETENTION")
    
    EMBED_COLOR: int = Field(0x8B5CF6, env="EMBED_COLOR")
    EMBED_COLOR_SUCCESS: int = Field(0x10B981, env="EMBED_COLOR_SUCCESS")
    EMBED_COLOR_ERROR: int = Field(0xEF4444, env="EMBED_COLOR_ERROR")
    EMBED_COLOR_WARNING: int = Field(0xF59E0B, env="EMBED_COLOR_WARNING")
    EMBED_COLOR_INFO: int = Field(0x3B82F6, env="EMBED_COLOR_INFO")
    
    ADMIN_ROLE_IDS: List[int] = Field(default_factory=list, env="ADMIN_ROLE_IDS")
    STAFF_ROLE_IDS: List[int] = Field(default_factory=list, env="STAFF_ROLE_IDS")
    CUSTOMER_ROLE_IDS: List[int] = Field(default_factory=list, env="CUSTOMER_ROLE_IDS")
    VPS_USER_ROLE_IDS: List[int] = Field(default_factory=list, env="VPS_USER_ROLE_IDS")
    PREMIUM_USER_ROLE_IDS: List[int] = Field(default_factory=list, env="PREMIUM_USER_ROLE_IDS")
    
    ENCRYPTION_KEY: str = Field(..., env="ENCRYPTION_KEY")
    JWT_SECRET: str = Field(..., env="JWT_SECRET")
    JWT_ALGORITHM: str = Field("HS256", env="JWT_ALGORITHM")
    JWT_EXPIRE_MINUTES: int = Field(60, env="JWT_EXPIRE_MINUTES")
    API_KEY_LENGTH: int = Field(32, env="API_KEY_LENGTH")
    
    ANTI_RAID_ENABLED: bool = Field(True, env="ANTI_RAID_ENABLED")
    ANTI_SPAM_ENABLED: bool = Field(True, env="ANTI_SPAM_ENABLED")
    ANTI_BOT_ENABLED: bool = Field(True, env="ANTI_BOT_ENABLED")
    ANTI_WEBHOOK_ENABLED: bool = Field(True, env="ANTI_WEBHOOK_ENABLED")
    ANTI_NUKE_ENABLED: bool = Field(True, env="ANTI_NUKE_ENABLED")
    ANTI_KICK_ENABLED: bool = Field(True, env="ANTI_KICK_ENABLED")
    ANTI_BAN_ENABLED: bool = Field(True, env="ANTI_BAN_ENABLED")
    ANTI_ROLE_DELETE_ENABLED: bool = Field(True, env="ANTI_ROLE_DELETE_ENABLED")
    ANTI_CHANNEL_DELETE_ENABLED: bool = Field(True, env="ANTI_CHANNEL_DELETE_ENABLED")
    ANTI_MENTION_ENABLED: bool = Field(True, env="ANTI_MENTION_ENABLED")
    ANTI_SPAM_THRESHOLD: int = Field(5, env="ANTI_SPAM_THRESHOLD")
    ANTI_SPAM_WINDOW: int = Field(10, env="ANTI_SPAM_WINDOW")
    WHITELIST_ROLE_IDS: List[int] = Field(default_factory=list, env="WHITELIST_ROLE_IDS")
    WHITELIST_USER_IDS: List[int] = Field(default_factory=list, env="WHITELIST_USER_IDS")
    
    TICKET_CATEGORY_ID: Optional[int] = Field(None, env="TICKET_CATEGORY_ID")
    TICKET_LOG_CHANNEL_ID: Optional[int] = Field(None, env="TICKET_LOG_CHANNEL_ID")
    TICKET_TRANSCRIPT_CHANNEL_ID: Optional[int] = Field(None, env="TICKET_TRANSCRIPT_CHANNEL_ID")
    TICKET_STAFF_ROLE_IDS: List[int] = Field(default_factory=list, env="TICKET_STAFF_ROLE_IDS")
    MAX_TICKETS_PER_USER: int = Field(3, env="MAX_TICKETS_PER_USER")
    TICKET_CLOSE_DELAY: int = Field(5, env="TICKET_CLOSE_DELAY")
    
    VPS_DEFAULT_RAM: int = Field(2048, env="VPS_DEFAULT_RAM")
    VPS_DEFAULT_CPU: int = Field(2, env="VPS_DEFAULT_CPU")
    VPS_DEFAULT_DISK: int = Field(20, env="VPS_DEFAULT_DISK")
    VPS_DEFAULT_OS: str = Field("ubuntu22.04", env="VPS_DEFAULT_OS")
    VPS_DEFAULT_VIRTUALIZATION: str = Field("lxd_unsupported", env="VPS_DEFAULT_VIRTUALIZATION")
    
    NODE_AGENT_ENABLED: bool = Field(True, env="NODE_AGENT_ENABLED")
    NODE_AGENT_HOST: str = Field("0.0.0.0", env="NODE_AGENT_HOST")
    NODE_AGENT_PORT: int = Field(8080, env="NODE_AGENT_PORT")
    NODE_AGENT_API_KEY: str = Field(..., env="NODE_AGENT_API_KEY")
    NODE_AGENT_JWT_SECRET: str = Field(..., env="NODE_AGENT_JWT_SECRET")
    
    NODE_HEARTBEAT_INTERVAL: int = Field(30, env="NODE_HEARTBEAT_INTERVAL")
    NODE_TIMEOUT: int = Field(60, env="NODE_TIMEOUT")
    NODE_MAX_RETRIES: int = Field(3, env="NODE_MAX_RETRIES")
    
    PTERODACTYL_URL: Optional[str] = Field(None, env="PTERODACTYL_URL")
    PTERODACTYL_API_KEY: Optional[str] = Field(None, env="PTERODACTYL_API_KEY")
    PTERODACTYL_APP_API_KEY: Optional[str] = Field(None, env="PTERODACTYL_APP_API_KEY")
    PTERODACTYL_CLIENT_API_KEY: Optional[str] = Field(None, env="PTERODACTYL_CLIENT_API_KEY")
    
    MC_DEFAULT_EGG: str = Field("paper", env="MC_DEFAULT_EGG")
    MC_DEFAULT_VERSION: str = Field("latest", env="MC_DEFAULT_VERSION")
    MC_ALLOCATION_START: int = Field(25565, env="MC_ALLOCATION_START")
    MC_ALLOCATION_END: int = Field(25665, env="MC_ALLOCATION_END")
    
    MONITORING_INTERVAL: int = Field(60, env="MONITORING_INTERVAL")
    MONITORING_ALERT_CPU: int = Field(90, env="MONITORING_ALERT_CPU")
    MONITORING_ALERT_RAM: int = Field(90, env="MONITORING_ALERT_RAM")
    MONITORING_ALERT_DISK: int = Field(90, env="MONITORING_ALERT_DISK")
    
    BACKUP_ENABLED: bool = Field(True, env="BACKUP_ENABLED")
    BACKUP_INTERVAL: int = Field(3600, env="BACKUP_INTERVAL")
    BACKUP_RETENTION_DAYS: int = Field(7, env="BACKUP_RETENTION_DAYS")
    BACKUP_PATH: str = Field("backups/", env="BACKUP_PATH")
    BACKUP_COMPRESSION: bool = Field(True, env="BACKUP_COMPRESSION")
    
    DASHBOARD_ENABLED: bool = Field(False, env="DASHBOARD_ENABLED")
    DASHBOARD_HOST: str = Field("0.0.0.0", env="DASHBOARD_HOST")
    DASHBOARD_PORT: int = Field(3000, env="DASHBOARD_PORT")
    DASHBOARD_SECRET: str = Field(..., env="DASHBOARD_SECRET")
    
    RATE_LIMIT_COMMANDS: int = Field(10, env="RATE_LIMIT_COMMANDS")
    RATE_LIMIT_WINDOW: int = Field(60, env="RATE_LIMIT_WINDOW")
    RATE_LIMIT_GLOBAL: int = Field(100, env="RATE_LIMIT_GLOBAL")
    
    COOLDOWN_CREATE_VPS: int = Field(300, env="COOLDOWN_CREATE_VPS")
    COOLDOWN_CREATE_MC: int = Field(60, env="COOLDOWN_CREATE_MC")
    COOLDOWN_TICKET: int = Field(10, env="COOLDOWN_TICKET")
    
    BOT_NAME: str = Field("GTX Bot v1", env="BOT_NAME")
    BOT_FOOTER: str = Field("GTX Bot v1 | Professional Hosting Automation", env="BOT_FOOTER")
    BOT_LOGO_URL: Optional[str] = Field(None, env="BOT_LOGO_URL")
    BOT_WEBSITE: Optional[str] = Field(None, env="BOT_WEBSITE")
    BOT_SUPPORT_SERVER: Optional[str] = Field(None, env="BOT_SUPPORT_SERVER")
    
    @validator("ADMIN_ROLE_IDS", "STAFF_ROLE_IDS", "CUSTOMER_ROLE_IDS", 
               "VPS_USER_ROLE_IDS", "PREMIUM_USER_ROLE_IDS", 
               "WHITELIST_ROLE_IDS", "WHITELIST_USER_IDS",
               "TICKET_STAFF_ROLE_IDS", pre=True)
    def parse_int_list(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        return v or []
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

settings = Settings()

PERMISSION_LEVELS = {
    "owner": 5,
    "admin": 4,
    "staff": 3,
    "customer": 2,
    "vps_user": 1,
    "premium_user": 1,
    "user": 0
}

VIRTUALIZATION_TYPES = ["kvm", "lxd_supported", "lxd_unsupported", "docker"]

MC_SOFTWARE_TYPES = {
    "paper": {"name": "Paper", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2", "1.16.5"]},
    "purpur": {"name": "Purpur", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2"]},
    "fabric": {"name": "Fabric", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2"]},
    "forge": {"name": "Forge", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2"]},
    "neoforge": {"name": "NeoForge", "versions": ["1.20.4", "1.20.2"]},
    "spigot": {"name": "Spigot", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2", "1.16.5"]},
    "vanilla": {"name": "Vanilla", "versions": ["1.20.4", "1.20.2", "1.19.4", "1.18.2"]}
}

TICKET_CATEGORIES = {
    "general": {"name": "General Support", "emoji": "����", "description": "General questions and support"},
    "vps": {"name": "VPS Issues", "emoji": "�������", "description": "VPS-related problems"},
    "minecraft": {"name": "Minecraft Server", "emoji": "������", "description": "Minecraft server issues"},
    "billing": {"name": "Billing", "emoji": "����", "description": "Billing and payments"},
    "abuse": {"name": "Abuse Report", "emoji": "����", "description": "Report abuse or violations"},
    "other": {"name": "Other", "emoji": "����", "description": "Other issues"}
}

GUARDIAN_PUNISHMENTS = {
    "warn": "Warn",
    "mute": "Mute (10m)",
    "kick": "Kick",
    "ban": "Ban",
    "timeout": "Timeout (1h)"
}

NODE_STATUSES = ["online", "offline", "maintenance", "error"]

VPS_STATUSES = ["creating", "running", "stopped", "reinstalling", "error", "deleted"]

SERVER_STATUSES = ["creating", "running", "stopped", "restarting", "reinstalling", "backing_up", "suspended", "error"]

BACKUP_TYPES = ["auto", "manual", "scheduled"]
BACKUP_STATUSES = ["pending", "running", "completed", "failed"]