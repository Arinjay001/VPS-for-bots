# GTX Bot v1 - Command Reference

## General Commands

| Command | Description | Permission |
|---------|-------------|------------|
| `!ping` | Check bot latency | Everyone |
| `!uuid` | Generate a UUID | Everyone |
| `!password [length]` | Generate secure password | VPS User |
| `!apikey` | Generate API key | VPS User |
| `!serverinfo` | Show server info | Everyone |
| `!userinfo [@user]` | Show user info | Everyone |
| `!avatar [@user]` | Get user avatar | Everyone |
| `!calculate <ram> <cpu> <disk> [count]` | Calculate resources | VPS User |

## VPS Management

| Command | Description | Permission |
|---------|-------------|------------|
| `!create` | Interactive VPS creation wizard | VPS User |
| `!myvps` | List your VPS instances | VPS User |
| `!vps <id>` | Manage specific VPS | VPS User |
| `!listvps` | List all VPS (admin) | Admin |

### VPS Actions (via buttons)
- **Start** - Start VPS
- **Stop** - Stop VPS
- **Restart** - Restart VPS
- **Reinstall** - Reinstall OS
- **Delete** - Delete VPS (confirmation required)

## Minecraft Servers

| Command | Description | Permission |
|---------|-------------|------------|
| `!create-mc` | Create MC server via Pterodactyl | Admin |
| `!mc-list` | List your MC servers | Everyone |

## Node Management

| Command | Description | Permission |
|---------|-------------|------------|
| `!node-add` | Register new node | Admin |
| `!nodes` | List all nodes | Staff |
| `!node <id>` | View node details | Staff |
| `!node-refresh` | Refresh all node stats | Staff |

### Node Actions (via buttons)
- **Test Connection** - Test node connectivity
- **Refresh Stats** - Update node statistics
- **Toggle Active** - Enable/disable node
- **Delete** - Remove node (confirmation required)

## Monitoring

| Command | Description | Permission |
|---------|-------------|------------|
| `!status` | Quick system status | Everyone |
| `!stats` | Detailed statistics | Staff |
| `!monitor` | Live monitoring (30s updates) | Staff |
| `!alert-test` | Test alert system | Admin |

## Ticket System

| Command | Description | Permission |
|---------|-------------|------------|
| `!ticket` | Open ticket panel | Everyone |
| `!ticket-setup <category> [logs] [transcripts]` | Setup ticket system | Admin |
| `!ticket-stats` | View ticket statistics | Staff |
| `!my-tickets` | View your tickets | Everyone |

### Ticket Actions (via buttons)
- **Claim** - Claim ticket (staff)
- **Close** - Close ticket
- **Delete** - Delete ticket (staff)
- **Add User** - Add user to ticket
- **Remove User** - Remove user from ticket
- **Rename** - Rename ticket

## Guardian Security

| Command | Description | Permission |
|---------|-------------|------------|
| `!guardian` | Security dashboard | Staff |
| `!whitelist <add/remove/list> [@user]` | Manage whitelist | Admin |
| `!guardian-logs [limit]` | View security logs | Staff |

### Guardian Modules
- **Anti-Raid** - Detects mass joins
- **Anti-Spam** - Detects message spam
- **Anti-Bot** - Blocks unauthorized bots
- **Anti-Webhook** - Detects webhook spam
- **Anti-Nuke** - Prevents mass destruction
- **Anti-Kick/Ban** - Monitors moderation actions
- **Anti-Mention** - Limits mention spam
- **Anti-Channel/Role Delete** - Protects server structure

## Pterodactyl Integration

| Command | Description | Permission |
|---------|-------------|------------|
| `!ptero-server <action> <id>` | Manage Pterodactyl server | Admin |
| `!ptero-nodes` | List Pterodactyl nodes | Admin |
| `!ptero-eggs` | List available eggs | Admin |

### Pterodactyl Actions
- `restart`, `stop`, `start`, `kill`, `reinstall`
- `backup`, `suspend`, `unsuspend`, `delete`
- `info`, `resources`, `command`

## Firewall Management

| Command | Description | Permission |
|---------|-------------|------------|
| `!fw-allow <vps> <port> [protocol] [ip]` | Allow port/IP | VPS User |
| `!fw-deny <vps> <port> [protocol] [ip]` | Deny port/IP | VPS User |
| `!fw-list <vps>` | List firewall rules | VPS User |

## Backup System

| Command | Description | Permission |
|---------|-------------|------------|
| `!backup <vps>` | Create manual backup | VPS User |
| `!backups <vps>` | List VPS backups | VPS User |
| `!restore <backup>` | Restore backup | Admin |

## User Management

| Command | Description | Permission |
|---------|-------------|------------|
| `!profile [@user]` | View profile | Everyone |
| `!userinfo <@user>` | View user info (staff) | Staff |
| `!ban-user <@user> [reason]` | Ban user | Admin |
| `!unban-user <@user>` | Unban user | Admin |
| `!add-premium <@user>` | Add premium | Admin |
| `!remove-premium <@user>` | Remove premium | Admin |

## Admin Commands

| Command | Description | Permission |
|---------|-------------|------------|
| `!setup` | Initial setup wizard | Owner |
| `!config` | View/edit server config | Admin |
| `!set-role <type> <@role>` | Set permission role | Admin |
| `!reload [cog]` | Reload extensions | Owner |
| `!sync [guild_only]` | Sync slash commands | Owner |
| `!lockdown <true/false>` | Server lockdown | Admin |
| `!announce <channel> <title> <message>` | Send announcement | Admin |
| `!dashboard` | Get dashboard link | Everyone |
| `!stats` | System statistics | Admin |

## Logs & Debugging

| Command | Description | Permission |
|---------|-------------|------------|
| `!logs <type> [lines]` | View bot logs | Admin |
| `!audit-logs [limit]` | View audit logs | Admin |

### Log Types
- `bot`, `guardian`, `tickets`, `nodes`, `ptero`, `errors`

## Permission Levels

| Level | Roles | Commands |
|-------|-------|----------|
| **Owner** | Bot owner IDs | All commands |
| **Admin** | ADMIN_ROLE_IDS | Most admin commands |
| **Staff** | STAFF_ROLE_IDS | Moderation, monitoring |
| **Premium** | PREMIUM_ROLE_IDS | Premium features |
| **VPS User** | VPS_USER_ROLE_IDS | VPS management |
| **Customer** | CUSTOMER_ROLE_IDS | Basic features |
| **User** | Default | Basic commands |

## Interactive Features

### Buttons
All management actions use Discord buttons for confirmation and execution.

### Dropdowns
- Ticket category selection
- Node selection
- Software/version selection
- OS template selection

### Modals
- Ticket creation (subject, description)
- VPS rename
- User add/remove
- Reinstall confirmation
- Delete confirmations (type "DELETE")

## Virtualization Types

| Type | Description | Requirements |
|------|-------------|--------------|
| **KVM** | Full virtualization | CPU virtualization, nested VT |
| **LXC (LXD)** | System containers | LXD daemon |
| **LXC (Basic)** | Basic containers | LXC tools |
| **Docker** | App containers | Docker daemon |

Auto-detected on each node.