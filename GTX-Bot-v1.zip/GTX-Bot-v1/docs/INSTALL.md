# GTX Bot v1 - Installation Guide

## Requirements

### System
- Ubuntu 22.04+ / Debian 12+ (recommended)
- Python 3.12+
- 2GB+ RAM (4GB+ recommended)
- 20GB+ disk space
- Root/sudo access

### External Services
- **Discord Bot Token** - [Discord Developer Portal](https://discord.com/developers/applications)
- **Pterodactyl Panel** (optional) - For Minecraft/VPS management
- **Domain** (optional) - For dashboard/SSL

## Quick Install (Automated)

```bash
# Clone repository
git clone https://github.com/your-repo/GTX-Bot-v1.git
cd GTX-Bot-v1

# Run installer as root
sudo bash install/install.sh

# Configure
sudo nano /etc/gtx/.env

# Initialize database
sudo -u gtxbot /opt/gtx-bot/venv/bin/python -c "
import asyncio
from database import init_db
asyncio.run(init_db())
"

# Start services
sudo systemctl start gtx-bot node-agent monitoring
```

## Manual Install

### 1. System Dependencies

```bash
apt-get update
apt-get install -y python3.12 python3.12-venv python3.12-dev \
    git curl wget sqlite3 \
    docker.io lxc lxd qemu-kvm libvirt-daemon-system \
    iptables ipset bridge-utils \
    build-essential libssl-dev libffi-dev

systemctl enable --now docker
systemctl enable --now libvirtd
```

### 2. Create Service User

```bash
useradd -r -s /bin/bash -d /home/gtxbot -m gtxbot
```

### 3. Setup Directories

```bash
mkdir -p /opt/gtx-bot /opt/gtx-node-agent
mkdir -p /var/lib/gtx/{vps,backups,templates,logs}
mkdir -p /etc/gtx
chown -R gtxbot:gtxbot /opt/gtx-bot /opt/gtx-node-agent /var/lib/gtx /etc/gtx
```

### 4. Install Bot

```bash
cd /opt/gtx-bot
# Copy bot files here
sudo -u gtxbot python3.12 -m venv venv
sudo -u gtxbot venv/bin/pip install --upgrade pip
sudo -u gtxbot venv/bin/pip install -r requirements.txt
```

### 5. Install Node Agent

```bash
cd /opt/gtx-node-agent
# Copy node-agent files here
sudo -u gtxbot python3.12 -m venv venv
sudo -u gtxbot venv/bin/pip install --upgrade pip
sudo -u gtxbot venv/bin/pip install -r requirements.txt
```

### 6. Configure LXD

```bash
sudo -u gtxbot lxd init --auto --storage-backend=dir
lxc network create gtxbr0 ipv4.address=auto ipv6.address=none
lxc profile device add default eth0 nic network=gtxbr0
```

### 7. Network Bridge

```bash
cat > /etc/netplan/99-gtx-bridge.yaml <<EOF
network:
  version: 2
  bridges:
    gtxbr0:
      interfaces: []
      addresses: [10.99.0.1/24]
      dhcp4: false
EOF
netplan apply
```

### 8. Systemd Services

Copy service files from `services/` to `/etc/systemd/system/`:
- `gtx-bot.service`
- `node-agent.service`
- `monitoring.service`

```bash
systemctl daemon-reload
systemctl enable gtx-bot node-agent monitoring
```

## Configuration

Edit `/etc/gtx/.env` with your values:

### Required
```env
DISCORD_TOKEN=your_bot_token
ENCRYPTION_KEY=generate_with_python_cryptography
NODE_AGENT_API_KEY=shared_secret_for_nodes
```

### Pterodactyl (Optional)
```env
PTERODACTYL_URL=https://panel.yourdomain.com
PTERODACTYL_API_KEY=admin_api_key
PTERODACTYL_CLIENT_API_KEY=client_api_key
```

### Database
```env
DATABASE_URL=sqlite+aiosqlite:///./database/gtx.db
# Or PostgreSQL:
# DATABASE_URL=postgresql+asyncpg://user:pass@localhost/gtx
```

### Roles (Get IDs from Discord Developer Mode)
```env
OWNER_IDS=123456789012345678
ADMIN_ROLE_IDS=111111111111111111,222222222222222222
STAFF_ROLE_IDS=333333333333333333
CUSTOMER_ROLE_IDS=444444444444444444
VPS_USER_ROLE_IDS=555555555555555555
PREMIUM_ROLE_IDS=666666666666666666
```

## Database Setup

```bash
sudo -u gtxbot /opt/gtx-bot/venv/bin/python -c "
import asyncio
from database import init_db
asyncio.run(init_db())
"

# Or with Alembic migrations:
cd /opt/gtx-bot
sudo -u gtxbot venv/bin/alembic upgrade head
```

## Start Services

```bash
systemctl start gtx-bot node-agent monitoring

# Check status
systemctl status gtx-bot
systemctl status node-agent

# View logs
journalctl -u gtx-bot -f
journalctl -u node-agent -f
```

## Discord Setup

1. Create application at [Discord Developer Portal](https://discord.com/developers/applications)
2. Enable **Message Content Intent**, **Server Members Intent**, **Presence Intent**
3. Copy token to `.env`
4. Invite bot with `applications.commands` scope
5. Run `!setup` in Discord for initial configuration

## Node Agent Setup (Additional Nodes)

On each VPS host:

```bash
# Install dependencies (same as above)
# Copy node-agent folder
# Configure .env with same NODE_AGENT_API_KEY
# Run: python agent.py
# Or install as service
```

Register node in Discord:
```
!node-add
# Enter: name, host, port, location, API key
```

## Troubleshooting

### Bot won't start
- Check `journalctl -u gtx-bot -f`
- Verify `.env` has all required values
- Check database permissions

### Node agent connection fails
- Verify `NODE_AGENT_API_KEY` matches on bot and node
- Check firewall allows port 8080
- Test: `curl -H "Authorization: Bearer <key>" http://node:8080/health`

### VPS creation fails
- Check node has enough resources
- Verify virtualization support: `lxc-checkconfig` / `kvm-ok`
- Check node agent logs

### Pterodactyl errors
- Verify API keys have correct permissions
- Check panel URL is accessible from bot
- Ensure eggs/nests exist on panel

## Updates

```bash
sudo bash install/update.sh
```

## Uninstall

```bash
sudo bash install/uninstall.sh
```

## Support

- Check logs: `journalctl -u gtx-bot -f`
- Enable debug: `LOG_LEVEL=DEBUG` in `.env`
- Discord community: [Link]
- GitHub Issues: [Link]