# GTX AI — Free Local Discord AI Bot

This bot uses Ollama on your own VPS. It does not require an OpenAI API key.

## VPS requirements

- Ubuntu 22.04 or 24.04
- 4 GB RAM minimum
- 8 GB RAM recommended
- Around 5–10 GB free disk space
- CPU-only works, but replies can be slower

Recommended models:

- 4 GB RAM: `qwen2.5:1.5b`
- 8 GB RAM: `qwen2.5:3b`
- 16 GB+ RAM: `qwen2.5:7b`

## Discord setup

1. Open Discord Developer Portal.
2. Create an application and bot.
3. Enable **Message Content Intent** under Bot → Privileged Gateway Intents.
4. Invite it with the `bot` and `applications.commands` scopes.
5. Give it View Channels, Send Messages, Read Message History, and Use Application Commands.

Never share your bot token.

## Install

Upload/extract this folder on the VPS, then:

```bash
cd GTX-ai-bot
cp .env.example .env
nano .env
chmod +x install.sh
sudo ./install.sh
```

Put the Discord token in `.env` before starting.

## Commands

- `/ask question`
- `/reset`
- `/ping`
- `/model`
- `/clearall` — owner only

The bot also responds when mentioned or when someone replies to one of its messages.

## Useful commands

```bash
systemctl status GTX-ai --no-pager
journalctl -u GTX-ai -f
systemctl restart GTX-ai
systemctl status ollama --no-pager
ollama list
```

## Change model

Edit:

```bash
nano /opt/GTX-ai/.env
```

Then download and activate another model:

```bash
ollama pull qwen2.5:1.5b
systemctl restart GTX-ai
```
