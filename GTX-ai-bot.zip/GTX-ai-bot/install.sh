#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run this installer as root."
  exit 1
fi

APP_DIR="/opt/GTX-ai"
MODEL="${OLLAMA_MODEL:-qwen2.5:3b}"

echo "[1/7] Installing system packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip curl ca-certificates

echo "[2/7] Installing Ollama..."
if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh
fi
systemctl enable --now ollama

echo "[3/7] Installing bot files..."
mkdir -p "$APP_DIR/data"
cp bot.py requirements.txt "$APP_DIR/"
if [[ -f .env ]]; then
  cp .env "$APP_DIR/.env"
elif [[ -f .env.example ]]; then
  cp .env.example "$APP_DIR/.env"
fi

echo "[4/7] Creating Python environment..."
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"

echo "[5/7] Downloading local AI model: $MODEL"
ollama pull "$MODEL"

echo "[6/7] Installing systemd service..."
cp GTX-ai.service /etc/systemd/system/GTX-ai.service
systemctl daemon-reload
systemctl enable GTX-ai

echo "[7/7] Final check..."
if grep -q "PASTE_TOKEN_HERE" "$APP_DIR/.env"; then
  echo
  echo "IMPORTANT: Edit the token first:"
  echo "nano $APP_DIR/.env"
  echo
  echo "Then start the bot:"
  echo "systemctl restart GTX-ai"
else
  systemctl restart GTX-ai
fi

echo
echo "Status: systemctl status GTX-ai --no-pager"
echo "Logs:   journalctl -u GTX-ai -f"
