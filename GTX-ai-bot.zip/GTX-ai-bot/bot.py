import os
import asyncio
import logging
import sqlite3
from collections import defaultdict
from contextlib import closing
from typing import List, Dict

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:3b").strip()
BOT_NAME = os.getenv("BOT_NAME", "GTX AI").strip()
ALLOWED_CHANNEL_ID = int(os.getenv("ALLOWED_CHANNEL_ID", "0") or 0)
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
MAX_HISTORY = max(2, int(os.getenv("MAX_HISTORY", "10")))
MAX_INPUT_CHARS = max(100, int(os.getenv("MAX_INPUT_CHARS", "4000")))
COOLDOWN_SECONDS = max(1, int(os.getenv("COOLDOWN_SECONDS", "8")))
DATABASE_PATH = os.getenv("DATABASE_PATH", "data/memory.db")
SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "You are GTX AI, a helpful Discord assistant. Be concise, accurate, friendly, and safe. "
    "Format code using Markdown code blocks."
)

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing in .env")

os.makedirs(os.path.dirname(DATABASE_PATH) or ".", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("GTX-ai")

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)
user_locks = defaultdict(asyncio.Lock)


def init_db() -> None:
    with closing(sqlite3.connect(DATABASE_PATH)) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.commit()


def get_history(user_id: int) -> List[Dict[str, str]]:
    with closing(sqlite3.connect(DATABASE_PATH)) as db:
        rows = db.execute(
            "SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, MAX_HISTORY * 2)
        ).fetchall()
    rows.reverse()
    return [{"role": role, "content": content} for role, content in rows]


def save_message(user_id: int, role: str, content: str) -> None:
    with closing(sqlite3.connect(DATABASE_PATH)) as db:
        db.execute(
            "INSERT INTO messages(user_id, role, content) VALUES (?, ?, ?)",
            (user_id, role, content)
        )
        db.execute("""
            DELETE FROM messages
            WHERE user_id=? AND id NOT IN (
                SELECT id FROM messages
                WHERE user_id=?
                ORDER BY id DESC
                LIMIT ?
            )
        """, (user_id, user_id, MAX_HISTORY * 2))
        db.commit()


def clear_history(user_id: int) -> None:
    with closing(sqlite3.connect(DATABASE_PATH)) as db:
        db.execute("DELETE FROM messages WHERE user_id=?", (user_id,))
        db.commit()


async def ask_ollama(user_id: int, prompt: str) -> str:
    history = get_history(user_id)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, *history, {"role": "user", "content": prompt}]
    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "options": {"temperature": 0.7}
    }

    timeout = aiohttp.ClientTimeout(total=180)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        try:
            async with session.post(f"{OLLAMA_URL}/api/chat", json=payload) as response:
                if response.status != 200:
                    body = await response.text()
                    raise RuntimeError(f"Ollama returned HTTP {response.status}: {body[:300]}")
                data = await response.json()
        except aiohttp.ClientConnectorError as exc:
            raise RuntimeError("Ollama is not running. Start it with: systemctl start ollama") from exc

    answer = (data.get("message") or {}).get("content", "").strip()
    if not answer:
        raise RuntimeError("The AI returned an empty response.")

    save_message(user_id, "user", prompt)
    save_message(user_id, "assistant", answer)
    return answer


def split_message(text: str, limit: int = 1900) -> List[str]:
    if len(text) <= limit:
        return [text]

    chunks = []
    current = ""
    for line in text.splitlines(keepends=True):
        if len(current) + len(line) <= limit:
            current += line
            continue
        if current:
            chunks.append(current.rstrip())
            current = ""
        while len(line) > limit:
            chunks.append(line[:limit])
            line = line[limit:]
        current = line
    if current:
        chunks.append(current.rstrip())
    return chunks


def channel_allowed(channel_id: int) -> bool:
    return ALLOWED_CHANNEL_ID == 0 or channel_id == ALLOWED_CHANNEL_ID


async def send_ai_reply(target, user_id: int, prompt: str) -> None:
    prompt = prompt.strip()
    if not prompt:
        await target.send("Please send a question.")
        return
    if len(prompt) > MAX_INPUT_CHARS:
        await target.send(f"Your message is too long. Maximum: {MAX_INPUT_CHARS} characters.")
        return

    async with user_locks[user_id]:
        try:
            async with target.typing():
                answer = await ask_ollama(user_id, prompt)
            for chunk in split_message(answer):
                await target.send(chunk)
        except Exception as exc:
            log.exception("AI request failed")
            await target.send(f"⚠️ AI error: `{str(exc)[:300]}`")


@bot.event
async def on_ready():
    init_db()
    try:
        synced = await bot.tree.sync()
        log.info("Synced %s slash commands", len(synced))
    except Exception:
        log.exception("Slash command sync failed")
    log.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "unknown")


@bot.tree.command(name="ask", description="Ask the local AI a question")
@app_commands.describe(question="What do you want to ask?")
@app_commands.checks.cooldown(1, COOLDOWN_SECONDS, key=lambda i: (i.guild_id, i.user.id))
async def ask(interaction: discord.Interaction, question: str):
    if not channel_allowed(interaction.channel_id):
        await interaction.response.send_message("This command is not allowed in this channel.", ephemeral=True)
        return

    await interaction.response.defer(thinking=True)
    question = question.strip()
    if len(question) > MAX_INPUT_CHARS:
        await interaction.followup.send(
            f"Your message is too long. Maximum: {MAX_INPUT_CHARS} characters.",
            ephemeral=True
        )
        return

    async with user_locks[interaction.user.id]:
        try:
            answer = await ask_ollama(interaction.user.id, question)
            chunks = split_message(answer)
            await interaction.followup.send(chunks[0])
            for chunk in chunks[1:]:
                await interaction.channel.send(chunk)
        except Exception as exc:
            log.exception("Slash AI request failed")
            await interaction.followup.send(f"⚠️ AI error: `{str(exc)[:300]}`", ephemeral=True)


@bot.tree.command(name="reset", description="Clear your AI conversation memory")
async def reset(interaction: discord.Interaction):
    clear_history(interaction.user.id)
    await interaction.response.send_message("✅ Your AI memory has been cleared.", ephemeral=True)


@bot.tree.command(name="ping", description="Check whether the bot is online")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(
        f"🏓 Pong! `{latency} ms` • Model: `{OLLAMA_MODEL}`",
        ephemeral=True
    )


@bot.tree.command(name="model", description="Show the active local AI model")
async def model(interaction: discord.Interaction):
    await interaction.response.send_message(
        f"🤖 Active model: `{OLLAMA_MODEL}`\nAI runs locally through Ollama.",
        ephemeral=True
    )


@bot.tree.command(name="clearall", description="Owner only: clear every user's AI memory")
async def clearall(interaction: discord.Interaction):
    if OWNER_ID == 0 or interaction.user.id != OWNER_ID:
        await interaction.response.send_message("Owner-only command.", ephemeral=True)
        return
    with closing(sqlite3.connect(DATABASE_PATH)) as db:
        db.execute("DELETE FROM messages")
        db.commit()
    await interaction.response.send_message("✅ All AI memory has been cleared.", ephemeral=True)


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not bot.user:
        return
    if not channel_allowed(message.channel.id):
        return

    mentioned = bot.user in message.mentions
    replied_to_bot = False

    if message.reference and message.reference.message_id:
        try:
            referenced = await message.channel.fetch_message(message.reference.message_id)
            replied_to_bot = referenced.author.id == bot.user.id
        except discord.HTTPException:
            pass

    if mentioned or replied_to_bot:
        prompt = message.content
        prompt = prompt.replace(f"<@{bot.user.id}>", "").replace(f"<@!{bot.user.id}>", "").strip()
        await send_ai_reply(message.channel, message.author.id, prompt)

    await bot.process_commands(message)


@ask.error
async def ask_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CommandOnCooldown):
        await interaction.response.send_message(
            f"Slow down. Try again in `{error.retry_after:.1f}s`.",
            ephemeral=True
        )
    else:
        log.exception("Command error", exc_info=error)
        if interaction.response.is_done():
            await interaction.followup.send("An unexpected command error occurred.", ephemeral=True)
        else:
            await interaction.response.send_message("An unexpected command error occurred.", ephemeral=True)


if __name__ == "__main__":
    init_db()
    bot.run(TOKEN, log_handler=None)
